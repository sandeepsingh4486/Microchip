function OverPower(hObject,~)
handles=guidata(hObject);

OutputPower=str2double(handles.General_test.CommonSpecs.Pout.String);
PecentOverOutputPower=str2double(handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBox.String);
if ~isnan(OutputPower)&& ~isnan(PecentOverOutputPower)
    OverOutputPower=(OutputPower*PecentOverOutputPower)/100;
    handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBoxWatts.String=OverOutputPower;
    OverOutputPowerP=OverOutputPower+OutputPower;
    handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String=OverOutputPowerP;
else
    
    handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBoxWatts.String='';
    handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String='';
    
    
end