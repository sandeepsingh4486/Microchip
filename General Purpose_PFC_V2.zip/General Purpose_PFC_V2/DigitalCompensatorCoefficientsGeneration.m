function DigitalCompensatorCoefficientsGeneration(hObject)
handles=guidata(hObject);
if (handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable=="on")
    OLDigitalCompensator=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital;
    [OLN ,OLD]=tfdata(OLDigitalCompensator,'value');
    OLZerosNum=length(OLN);
    OLPolesNum=length(OLD);

    switch OLZerosNum
        case 1
            OLN=[OLN(1) 0 0 0 0];
            OLD=[OLD(1) 0 0 0 0];

        case 2
            OLN=[OLN(1) OLN(2) 0 0 0];
            OLD=[OLD(1) OLD(2) 0 0 0];

        case 3
            OLN=[OLN(1) OLN(2) OLN(3) 0 0];
            OLD=[OLD(1) OLD(2) OLD(3) 0 0];

        case 4
            OLN=[OLN(1) OLN(2) OLN(3) OLN(4) 0];
            OLD=[OLD(1) OLD(2) OLD(3) OLD(4) 0];

        case 5
            OLN=[OLN(1) OLN(2) OLN(3) OLN(4) OLN(5)];
            OLD=[OLD(1) OLD(2) OLD(3) OLD(4) OLD(5)];
    end

    OLAbsCoeff.B0=OLN(1);
    OLAbsCoeff.B1=OLN(2);
    OLAbsCoeff.B2=OLN(3);
    OLAbsCoeff.B3=OLN(4);
    OLAbsCoeff.B4=OLN(5);
    OLAbsCoeff.A0=OLD(1);
    OLAbsCoeff.A1=-1*OLD(2);
    OLAbsCoeff.A2=-1*OLD(3);
    OLAbsCoeff.A3=-1*OLD(4);
    OLAbsCoeff.A4=-1*OLD(5);

    [OLNormCoeff, OLQ15NormCoeff, OLQ15Param]=CoeffQ15Conversion(OLAbsCoeff);
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs=OLAbsCoeff;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm=OLNormCoeff;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Norm=OLQ15NormCoeff;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters=OLQ15Param;
    OLDigiCompCoeffDisplay(hObject,handles);
end
  if (handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable=="on") % Check for whether mode of contro is dual loop
 %    if (handles.SpecificationsTab.SelectionDropdowns.ControlMethodSelection.Value==2 && handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable=="on") % Check for whether mode of contro is dual loop
	ILDigitalCompensator=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital;   
    [ILN ,ILD]=tfdata(ILDigitalCompensator,'value');
    ILZerosNum=length(ILN);
    ILPolesNum=length(ILD);

    switch ILZerosNum
        case 1
            ILN=[ILN(1) 0 0 0 0];
            ILD=[ILD(1) 0 0 0 0];            
            
        case 2
            ILN=[ILN(1) ILN(2) 0 0 0];
            ILD=[ILD(1) ILD(2) 0 0 0];

        case 3
            ILN=[ILN(1) ILN(2) ILN(3) 0 0];
            ILD=[ILD(1) ILD(2) ILD(3) 0 0];
            
        case 4
            ILN=[ILN(1) ILN(2) ILN(3) ILN(4) 0];
            ILD=[ILD(1) ILD(2) ILD(3) ILD(4) 0];

        case 5
            ILN=[ILN(1) ILN(2) ILN(3) ILN(4) ILN(5)];
            ILD=[ILD(1) ILD(2) ILD(3) ILD(4) ILD(5)];
    end
    
    ILAbsCoeff.B0=ILN(1);
    ILAbsCoeff.B1=ILN(2);
    ILAbsCoeff.B2=ILN(3);
    ILAbsCoeff.B3=ILN(4);
    ILAbsCoeff.B4=ILN(5);
    ILAbsCoeff.A0=ILD(1);
    ILAbsCoeff.A1=-1*ILD(2);
    ILAbsCoeff.A2=-1*ILD(3);
    ILAbsCoeff.A3=-1*ILD(4);
    ILAbsCoeff.A4=-1*ILD(5);
    
    [ILNormCoeff, ILQ15NormCoeff, ILQ15Param]=CoeffQ15Conversion(ILAbsCoeff);
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs=ILAbsCoeff;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm=ILNormCoeff;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Norm=ILQ15NormCoeff;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters=ILQ15Param;
    ILDigiCompCoeffDisplay(hObject,handles)
end

guidata(hObject,handles);

function [NormCoeff , Q15NormCoeff, Q15Param]=CoeffQ15Conversion(AbsCoefficients)
format long
AbsoluteCoefficients=AbsCoefficients;
CoeffVec=[AbsoluteCoefficients.B0 AbsoluteCoefficients.B1 AbsoluteCoefficients.B2 ...
    AbsoluteCoefficients.B3 AbsoluteCoefficients.B4 AbsoluteCoefficients.A1 AbsoluteCoefficients.A2 ...
    AbsoluteCoefficients.A3 AbsoluteCoefficients.A4];
%if (max(CoeffVec)>1 || min(CoeffVec)<-1)
NormFactor=max(CoeffVec)/0.999900; % This is done because, max value in coefficients is 0.999900 after normalization which
% means, every coefficient is not divided by maximum of coefficients, but
% by slightly more than that to get 0.999900.
% else
%     NormFactor=1;
% end
normCoeffVec=CoeffVec/NormFactor;
CoeffVecQ15=round(normCoeffVec*2^15);
% CoeffVecQ15=double(int16(normCoeffVec*2^15));
for i=1:7
    if CoeffVecQ15(i)<0
        CoeffVecQ15(i)=(2^16+CoeffVecQ15(i));
    end
end

Q15Param.Normal=NormFactor;
Q15Param.PostShift=floor(log2(NormFactor))+1;
Q15Param.PostScalar=floor((NormFactor/(2^Q15Param.PostShift))*2^15);

NormCoeff.B0=normCoeffVec(1);
NormCoeff.B1=normCoeffVec(2);
NormCoeff.B2=normCoeffVec(3);
NormCoeff.B3=normCoeffVec(4);
NormCoeff.B4=normCoeffVec(5);
NormCoeff.A0=1;
NormCoeff.A1=normCoeffVec(6);
NormCoeff.A2=normCoeffVec(7);
NormCoeff.A3=normCoeffVec(8);
NormCoeff.A4=normCoeffVec(9);

Q15NormCoeff.B0=CoeffVecQ15(1);
Q15NormCoeff.B1=CoeffVecQ15(2);
Q15NormCoeff.B2=CoeffVecQ15(3);
Q15NormCoeff.B3=CoeffVecQ15(4);
Q15NormCoeff.B4=CoeffVecQ15(5);
Q15NormCoeff.A0=1;
Q15NormCoeff.A1=CoeffVecQ15(6);
Q15NormCoeff.A2=CoeffVecQ15(7);
Q15NormCoeff.A3=CoeffVecQ15(8);
Q15NormCoeff.A4=CoeffVecQ15(9);


function OLDigiCompCoeffDisplay(hObject,handles)
% AbsB0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0;
% AbsB1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1;
% AbsB2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2;
% AbsB3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3;
% AbsA0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0;
% AbsA1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1;
% AbsA2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2;
% AbsA3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3;
% NormB0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0;
% NormB1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1;
% NormB2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2;
% NormB3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3;
% NormA0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0;
% NormA1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1;
% NormA2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2;
% NormA3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3;

% Absolute Coefficients Display
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b0.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b1.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b2.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b3.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b4.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B4;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a0.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a2.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a3.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a4.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A4;

% Normalized Coefficients Display
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b0.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b1.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b2.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b3.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b4.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B4;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a0.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a1.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a2.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a3.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a4.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A4;

% % Normal, Prescalar,PostScalar display
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.Normal.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.Normal;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostShift.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostShift;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostScalar.String=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostScalar;

guidata(hObject,handles);

function ILDigiCompCoeffDisplay(hObject,handles)
% AbsB0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0;
% AbsB1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1;
% AbsB2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2;
% AbsB3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3;
% AbsA0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0;
% AbsA1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1;
% AbsA2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2;
% AbsA3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3;
% NormB0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0;
% NormB1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1;
% NormB2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2;
% NormB3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3;
% NormA0=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0;
% NormA1=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1;
% NormA2=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2;
% NormA3=handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3;

% Absolute Coefficients Display
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b0.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b1.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B1;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b2.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B2;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b3.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B3;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b4.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B4;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a0.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A0;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a1.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A1;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a2.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A2;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a3.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A3;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a4.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A4;

% Normalized Coefficients Display
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b0.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B0;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b1.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B1;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b2.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B2;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b3.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B3;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b4.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B4;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a0.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A0;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a1.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A1;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a2.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A2;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a3.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A3;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a4.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A4;

% % Normal, Prescalar,PostScalar display
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.Normal.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.Normal;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostShift.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostShift;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostScalar.String=handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostScalar;

guidata(hObject,handles);
