function [NUMER1,DENOM1]=Append_TF1(STRING)
str=evalc('STRING');
 splitted = strsplit(str,'\n'); % Splits the string
NUMER1 = splitted(4); % 4th line contains the numerator
NUMER1 = NUMER1{1}; % Converting cell to string
DENOM1 = splitted(6); % 6th line contains the denominator
DENOM1 = DENOM1{1}; % Converting cell to string
end