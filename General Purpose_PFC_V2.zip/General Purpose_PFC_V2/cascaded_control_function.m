function cascaded_fp_controller = cascaded_control_function(controller, rev_order, gainEnable, hFileVloopCloop, minclamp, maxclamp)

[z_K, p_K, k_K] = zpkdata(controller, 'v');
[num_controller, den_controller, Ts] = tfdata(controller);

mshift = 0;

if(gainEnable == 1)
    if k_K < 1
        minv = 1/k_K;
        mshift = (ceil(log(minv)/log(2)) - 1);
        k_K = k_K*2^mshift;
    end
end


if k_K > 1
    mshift = -ceil(log(k_K)/log(2));
    k_K = k_K/2^(-mshift);
end

z = tf('z');

order = length(p_K);

for ind = 1:order
    [theta_p, rho_p] = cart2pol(real(p_K(ind)), imag(p_K(ind)));
    p_K_theta(ind) = theta_p;
    p_K_rho(ind) = rho_p;
    p_K_polar([ind]) = rho_p*exp(i*theta_p);
   
    [theta_z, rho_z] = cart2pol(real(z_K(ind)), imag(z_K(ind)));
    z_K_theta(ind) = theta_z;
    z_K_rho(ind) = rho_z;
    z_K_polar([ind]) = rho_z*exp(i*theta_z);
end

Pc = sort(p_K_polar, 'descend');

for ind = 1:order
    pole = Pc(ind);
    zero = abs(z_K - pole);
    [pz_distance, zero_pairing_index] = min(zero);
    Zc(ind) = z_K(zero_pairing_index);
    z_K(z_K == Zc(ind)) = [];
end

if rev_order == 1
    Zc = fliplr(Zc);
    Pc = fliplr(Pc);
end
    
it_no = 1;
for it_no = 1:length(Pc)
    
    if it_no == 1
        Kd([it_no]) = k_K*(z-Zc(it_no))/(z-Pc(it_no));
        num_Q15 = round(k_K*[1 -Zc(it_no)].*32767);
    else
        Kd([it_no]) = (z-Zc(it_no))/(z-Pc(it_no));
        num_Q15 = round([1 -Zc(it_no)].*32767);
    end
    
    den_Q15 = round([1 -Pc(it_no)].*32767);
    Kd_fp([it_no]) = tf(num_Q15, den_Q15, Ts);

    it_no = it_no + 1;
end

cascaded_fp_controller = {Kd_fp mshift};


% if hFileVloopCloop == 1
% 
%     if order == 1
% 
%         fid = fopen('voltage_dcdt.h','w');
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B20 %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B21 %d\n',0);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_A21 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_B31 %d\n',0);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_COEFF_A31 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define VOLTAGE_COMP_1P1Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
%     end
% 
%     if order == 2
% 
%         fid = fopen('voltage_dcdt.h','w');
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B20 %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B21 %d\n',round(-Zc(2)*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_A21 %d\n',round(Pc(2)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_B31 %d\n',0);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_COEFF_A31 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define VOLTAGE_COMP_2P2Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
%     end
% 
% 
%     if order == 3
% 
%         fid = fopen('voltage_dcdt.h','w');
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B20 %d\n',round(32767));
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B21 %d\n',round(-Zc(2)*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_A21 %d\n',round(Pc(2)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_B31 %d\n',round(-Zc(3)*32767));
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_COEFF_A31 %d\n',round(Pc(3)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define VOLTAGE_COMP_3P3Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
%     end
%     
% end
% 
% 
% 
% if hFileVloopCloop == 0
% 
%     if order == 1
% 
%         fid = fopen('current_dcdt.h','w');
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B20 %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B21 %d\n',0);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_A21 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_B31 %d\n',0);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_COEFF_A31 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define CURRENT_COMP_1P1Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
%     end
% 
%     if order == 2
% 
%         fid = fopen('current_dcdt.h','w');
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B20 %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B21 %d\n',round(-Zc(2)*32767));
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_A21 %d\n',round(Pc(2)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_B31 %d\n',0);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_COEFF_A31 %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define CURRENT_COMP_2P2Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
%     end
% 
% 
%     if order == 3
% 
%         fid = fopen('current_dcdt.h','w');
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B10 %d\n',round(k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B11 %d\n',round(-Zc(1)*k_K*32767));
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_A11 %d\n',round(Pc(1)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B20 %d\n',round(32767));
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B21 %d\n',round(-Zc(2)*32767));
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_A21 %d\n',round(Pc(2)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B30 %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_B31 %d\n',round(-Zc(3)*32767));
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_COEFF_A31 %d\n',round(Pc(3)*32767));
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_POSTSCALER %d\n',32767);
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_POSTSHIFT %d\n',mshift);
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_PRESHIFT %d\n',0);
%         fprintf(fid,'\n');
% 
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_MIN_CLAMP %d\n',minclamp);
%         fprintf(fid,'#define CURRENT_COMP_3P3Z_MAX_CLAMP %d\n',maxclamp);
% 
%         fclose(fid);
% 
 %  end
    
end

