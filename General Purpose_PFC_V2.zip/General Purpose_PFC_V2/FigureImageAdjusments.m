function FigureImageAdjusments (hObject)
handles=guidata(hObject);
% hObject.Units='pixels';
% WidthInPixel=hObject.Position(3);
% hObject.Units='normalized';
GUIImageData=handles.GUIProcesses.GUIImageData;
ImAxes=handles.GUIProcesses.GUIImagesAxes;
% if (WidthInPixel>=handles.GUIProcesses.Figure_Max_Width_In_Pixels)
for i=1:length(GUIImageData)
    set(ImAxes(i),'Units','pixels');
    ImAxesPos=get(ImAxes(i),'Position');
    set(ImAxes(i),'Units','normalized');
    ResizedImage=imresize(GUIImageData{1,i},[ImAxesPos(4) ImAxesPos(3)]);
    imshow(ResizedImage,'Parent',ImAxes(i));
end
handles.GUIProcesses.ResizingDone=0;
% end
guidata(hObject,handles);