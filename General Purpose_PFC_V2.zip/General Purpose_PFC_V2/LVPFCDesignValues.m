 function LVPFCDesignValues(hObject,~)
handles=guidata(hObject);  


%% IPT1   LVPFC Design Values
handles.SpecificationsTab.CommonSpecs.VinMin.String='15';
%             handles.SpecificationsTab.CommonSpecs.VinMax.String='20';
handles.General_test.CommonSpecs.Vout.String='40';
handles.General_test.CommonSpecs.Pout.String='50';
handles.General_test.CommonSpecs.XCap.String='0.2';
handles.General_test.CommonSpecs.Inductor.Inductance.String='50';
handles.General_test.CommonSpecs.Inductor.DCR.String='1';
handles.General_test.CommonSpecs.Capacitor.Capacitance.String='3000';
handles.General_test.CommonSpecs.Capacitor.ESR.String='44';
%% IPT2   LVPFC Design Values
handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String='310';
handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String='30';
handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String='2.2';
handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String='0.22';
handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String='6800';
handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String='330';

handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String='30';
handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String='2.2';
handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String='0.01';
handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String='6800';
handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String='330';

handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String='0.06';
handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String='0.2';
handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String='330';
handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String='1';
handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String='100';
%% IPT3 LVPFC Design Values

handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String='100';
handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String='1';
handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String='100';
if handles.General_test.SelectionDropdowns.TopologySelection.Value == 4 && handles.General_test.MicrochipRefDesign.Radiobuttons.LVPFCOption.Value==1
    handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String='500';
    handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String='500';
else
    handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String='';
    handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String='';
end
handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String='300';
handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String='10000';
handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String='60';
%             handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String='1.04';
handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String='150';
handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String = '0';
handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String = '32767';

handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String = handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String;
handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String='16';
set(handles.ControllerDesignTab.PWMConfiguration.OL.PTPER,'String','6.25');
handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String='6.25';
handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String='300';
handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String='10';
handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String='60';
%             handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String='1.04';
handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String='150';
handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String = '0';
handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String = '32767';

%% IPT5 Default Values LVPFC Design Values

set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','on');
handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value = 1;
handles.IPT5.FeaturesConfig.IPUnderVoltageLimitTextBox.String ='12';
handles.IPT5.FeaturesConfig.IPUnderVoltageHysTextBox.String ='5';
handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultenableTextBox.String='1';
handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultdisableTextBox.String='2';

handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value = 1;
handles.IPT5.FeaturesConfig.IPOverVoltageLimitTextBox.String ='26';
handles.IPT5.FeaturesConfig.IPOverVoltageHysTextBox.String ='5';
handles.IPT5.FeaturesConfig.IPoverVoltage.FaultenableTextBox.String='3';
handles.IPT5.FeaturesConfig.IPoverVoltage.FaultdisableTextBox.String='4';

handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value = 1;
handles.IPT5.FeaturesConfig.OPUnderVoltageLimitTextBox.String ='30';
%             handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox.String ='';
handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultenableTextbox.String='5';
%             handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox.String='';
set(handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox,'Enable','off');
set(handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox,'Enable','off');


handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value = 1;
handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String ='42';
handles.IPT5.FeaturesConfig.OPOverVoltageHysTextBox.String ='5';
handles.IPT5.FeaturesConfig.OPOverVoltage.FaultenableTextbox.String='7';
handles.IPT5.FeaturesConfig.OPOverVoltage.FaultdisableTextbox.String='8';

handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value = 1;
handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String ='2';
handles.IPT5.FeaturesConfig.OPOverCurrentLimitHysTextBox.String ='0.2';
handles.IPT5.FeaturesConfig.OPOverCurrent.FaultEnableTextbox.String='9';
handles.IPT5.FeaturesConfig.OPOverCurrentLimitFaultDisableTextBox.String='10';

handles.IPT5.FeaturesConfig.OverTemperatureLimit.Value = 1;
handles.IPT5.FeaturesConfig.OverTemperatureLimitTextBox.String ='100';
handles.IPT5.FeaturesConfig.OverTemperatureLimitHysTextBox.String='10';
handles.IPT5.FeaturesConfig.OverTemperaturefaultenableTextbox.String='11';
handles.IPT5.FeaturesConfig.OverTemperatureLimitFaultdisableTextbox.String='12';

handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value = 1;
handles.IPT5.FeaturesConfig.LineUnderFrequencyLimitTextBox.String ='45';
handles.IPT5.FeaturesConfig.LineUnderFreqHysTextBox .String ='3';
handles.IPT5.FeaturesConfig.LineUnderFreqfaultenableTextbox.String='13';
handles.IPT5.FeaturesConfig.LineUnderFreqFaultdisableTextBox.String='14';

handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value = 1;
handles.IPT5.FeaturesConfig.LineOverFrequencyLimitTextBox.String ='65';
handles.IPT5.FeaturesConfig.LineOverFrequencyHysTextBox.String='3';
handles.IPT5.FeaturesConfig.LineOverFrequencyLimitFaultenableTextBox.String='15';
handles.IPT5.FeaturesConfig.LineOverFrequencyLimitfaultdisableTextBox.String='16';

handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value = 1;
handles.IPT5.FeaturesConfig.RelayTurnONLimitTextBox.String ='65';
handles.IPT5.FeaturesConfig.RelayTurnONLimitHysTextBox .String ='5';
handles.IPT5.FeaturesConfig.RelayTurnONLimitfaultenableTextBox.String='17';
handles.IPT5.FeaturesConfig.RelayTurnONLimitFaultdisableTextBox.String='18';

handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value=1;
handles.IPT5.FeaturesConfig.GenericParameter1LimitTextBox.String='19';
handles.IPT5.FeaturesConfig.GenericParameter1LimitHysTextBox.String='20';
handles.IPT5.FeaturesConfig.GenericParameter1FaultEnableTextBox.String='21';
handles.IPT5.FeaturesConfig.GenericParameter1FaultDisableTextBox.String='22';

handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value=1;
handles.IPT5.FeaturesConfig.GenericParameter2LimitTextBox.String='23';
handles.IPT5.FeaturesConfig.GenericParameter2LimitHysTextBox.String='24';
handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultEnableTextBox.String='25';
handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultDisableTextBox.String='26';


%% IPT4
%  handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String='3670'
%               OPOverVoltageLimit = handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String;
%               OPOverVoltageLimitC = str2double(OPOverVoltageLimit);
%
%               ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
%               Rfb4C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
%               Rfb5C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
%               ADCVoltC = str2double(ADCVolt);
%               VoutbaseC = (ADCVoltC / (Rfb5C / (Rfb5C+Rfb4C)));
%
%
%                ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
%                ADCResC = 2^str2double(ADCRes);
%                OPOVLimitCounts = round((ADCResC * OPOverVoltageLimitC / VoutbaseC),0);
%                handles.IPT5.DACCountValueCalculated=OPOVLimitCounts;
%                handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String=handles.IPT5.DACCountValueCalculated;

% DAC_Calculation_PFC(hObject);
% PTPERCalculation(hObject);
handles.dsPICDSCTab.IPCommonPanel.DeviceClock.String='70';

%% IPT6 Default Values LVPFC Design Values

set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','on');
handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value = 1;
handles.IPT6.FeaturesConfiguration.SoftStartDurationLimitTextBox.String ='100';
handles.IPT6.FeaturesConfiguration.SoftStartCallRate.Value = 1;
handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.String ='0.001';
handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value = 1;
handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String ='10';
%             handles.IPT6.FeaturesConfiguration.BurstModeDisableLimit.Value = 1;
handles.IPT6.FeaturesConfiguration.BurstModeDisableLimitTextBox.String ='20';
set(handles.IPT6.FeaturesConfiguration.BurstModeOffCyclesTextBox,'String','1');
handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value = 1;
handles.IPT6.FeaturesConfiguration.PWMDitheringLimitTextBox.String ='15';
handles.IPT6.FeaturesConfiguration.DCMCorrection.Value = 1;
handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox.String ='ENABLED';
set(handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox,'Style','edit','Enable','off');
if handles.General_test.SelectionDropdowns.TopologySelection.Value == 1
    
    handles.IPT6.FeaturesConfiguration.PhaseShedding.Enable='off';
    handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Enable='off';
    handles.IPT6.FeaturesConfiguration.PhaseShedding.Value =0;
    handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String ='';
    handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.Enable ='off';
    %                 handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value = 0;
    handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String ='';
    handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.Enable ='off';
    handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String='';
    handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String='';
    handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String='';
    handles.IPT6.FeaturesConfiguration.PFETControl.Value=1;
    handles.IPT6.FeaturesConfiguration.XCapCompensation.Value=1;
    set(handles.IPT6.FeaturesConfiguration.PFETControlTextBox,'String','ENABLED');
    set(handles.IPT6.FeaturesConfiguration.XCapCompensationTextBox,'String','ENABLED');
    
    
else
    handles.IPT6.FeaturesConfiguration.PhaseShedding.Value =1;
    handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String ='30';
    %                 handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value = 1;
    handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String ='5';
    handles.IPT6.FeaturesConfiguration.PFETControl.Value=1;
    handles.IPT6.FeaturesConfiguration.XCapCompensation.Value=1;
    set(handles.IPT6.FeaturesConfiguration.PFETControlTextBox,'String','ENABLED');
    set(handles.IPT6.FeaturesConfiguration.XCapCompensationTextBox,'String','ENABLED');
end

handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value = 1;

set(findobj(handles.General_test.PowerStageParametersPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);
set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);