function GPT4Design(GPT4,hObject)
handles=guidata(hObject);

GPT4MovablePanel = uipanel('Parent',GPT4,'Tag','GPT4MovablePanel');

DisplaySelectionPanel= uibuttongroup(...
    'Parent',GPT4MovablePanel,...
    'FontUnits',get(0,'defaultuipanelFontUnits'),...
    'Units',get(0,'defaultuipanelUnits'),...
    'FontSize',11,...
    'Tag','Display Check Box Selection Panel',...
    'Title','Display Selection',...
    'Position',[0.00001 0.9 1.0 0.1],...
    'CreateFcn', blanks(0) );

UserPlotPanel = uipanel(...
'Parent',GPT4MovablePanel,...
'FontUnits',get(0,'defaultuipanelFontUnits'),...
'Units',get(0,'defaultuipanelUnits'),...
'Tag','UserPlotPanel',...
'BorderType','none',...
'Position',[0.00001 0.004 1.0 0.89],...
'CreateFcn', blanks(0));

RadioGPT4.ILLoopGainDigPlot= uicontrol(...
'Parent',DisplaySelectionPanel,...
'FontUnits',get(0,'defaultuicontrolFontUnits'),...
'Units','normalized',...
'String','Inner Loop - Loop Gain (Digital)',...
'Style','radiobutton',...
'Value',get(0,'defaultuicontrolValue'),...
'Position',[0.0234 0.4 0.22 0.45],...
'Children',[],...
'Enable','on',...
'ButtonDownFcn',blanks(0),...
'CreateFcn', blanks(0),...
'DeleteFcn',blanks(0),...
'Callback',@UserBodePlot,...
'Tag','ILLoopGainCheckbox',...
'KeyPressFcn',blanks(0));

RadioGPT4.OLLoopGainDigPlot= uicontrol(...
'Parent',DisplaySelectionPanel,...
'FontUnits',get(0,'defaultuicontrolFontUnits'),...
'Units','normalized',...
'String','Outer Loop - Loop Gain (Digital)',...
'Style','radiobutton',...
'Value',get(0,'defaultuicontrolValue'),...
'Position',[0.5 0.4 0.22 0.45],...
'Children',[],...
'Enable','on',...
'ButtonDownFcn',blanks(0),...
'CreateFcn', blanks(0),...
'Callback',@UserBodePlot,...
'DeleteFcn',blanks(0),...
'Tag','OLLoopGainCheckbox',...
'KeyPressFcn',blanks(0));

RadioGPT4.Invisible= uicontrol(...
    'Parent',DisplaySelectionPanel,...
    'Units','normalized',...
    'String','Default',...
    'Enable','off',...
    'Visible','off',...
    'Style','radiobutton',...
    'Value',1,...
    'Position',[0.9 0.4 0.22 0.45]);

ax1 = subplot(2,1,1);
ax2 = subplot(2,1,2);

ax1.Parent = UserPlotPanel;
ax2.Parent = UserPlotPanel;

handles.UserBodeResponseTab.Subplot1.axis = ax1;
handles.UserBodeResponseTab.Subplot2.axis = ax2;

handles.UserBodeResponseTab.Pane = GPT4MovablePanel;
handles.GPT4.Userbode.Radio = RadioGPT4;
guidata(hObject,handles);

function UserBodePlot(hObject,~)
handles=guidata(hObject);

if hObject.Value == 1 && isempty(handles.SpecificationsTab.FilePath.BodeFilePath.String)
    % radiobuttons = handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons;
    errordlg('Please Select "Import User Bode Data"  file path','Error');
    handles.GPT4.Userbode.Radio.ILLoopGainDigPlot.Value = 0;
    handles.GPT4.Userbode.Radio.OLLoopGainDigPlot.Value = 0;
    cla(handles.UserBodeResponseTab.Subplot1.axis);
    cla(handles.UserBodeResponseTab.Subplot2.axis);
    return;
else
    
    if isempty(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1.String)
        
        errordlg('"Run" the application before choosing "Loop Gain (Digital)" Bode Plot ','Error');
        handles.GPT4.Userbode.Radio.ILLoopGainDigPlot.Value = 0;
        handles.GPT4.Userbode.Radio.OLLoopGainDigPlot.Value = 0;
        cla(handles.UserBodeResponseTab.Subplot1.axis);
        cla(handles.UserBodeResponseTab.Subplot2.axis);
    else
        switch hObject.String
            case 'Inner Loop - Loop Gain (Digital)'
                LoopGainDigital=handles.General_test.PlantInfo.IL.LoopGainDigitalTF;
            case 'Outer Loop - Loop Gain (Digital)'
                LoopGainDigital=handles.General_test.PlantInfo.OL.LoopGainDigitalTF;
        end
        
        cla(handles.UserBodeResponseTab.Subplot1.axis);
        cla(handles.UserBodeResponseTab.Subplot2.axis);
        
        ExpFile = xlsread(handles.General_test.FilePath.BodeFilePath.String);
        FreExp = ExpFile(:,1);
        GainExp = ExpFile(:,2);
        PhaseExp = ExpFile(:,3);
        
        FreRperS = 2*pi*FreExp;
        [SimG,SimP] = bode(LoopGainDigital,FreRperS);
        
        arrsize = size(SimG);
        arrlength = arrsize(3);
        
        for iplot = 1:arrlength
            SimGain(iplot) = 20*log10(SimG(1,1,iplot));
            SimPhase(iplot)= SimP(1,1,iplot)-180;
            %             SimPhase(iplot)= SimP(1,1,iplot)-360;
        end
        
        subplot(handles.UserBodeResponseTab.Subplot1.axis); %(subplot(row,column,Grid position for new axes)
        semilogx(FreExp, SimGain,'-.r', 'LineWidth', 1.5);  % Simulation
        hold on;
        semilogx(FreExp, GainExp, 'LineWidth', 1.5);        % Measured
        hold on;
        grid on;
        %     title('Outer Loop-Loop Gain Digital');
        legend('Simulated','Measured');
        ylabel('Magnitude (dB)');
        %     ylim([-10 60]);
        %     xlim([1 100]);
        subplot(handles.UserBodeResponseTab.Subplot2.axis);  %(subplot(row,column,Grid position for new axes)
        semilogx(FreExp, SimPhase,'-.r', 'LineWidth', 1.5);
        hold on;
        semilogx(FreExp, PhaseExp, 'LineWidth', 1.5);
        hold on;
        grid on;
        %     legend('Simulated','Measued');
        xlabel('Frequency (Hz)');
        ylabel('Phase (deg)');
        
        %     ylim([-180 180])
        %     xlim([1 100]);
        
end



    
end
    


% % if ~isempty(handles.General_test.FilePath.BodeFilePath.String)&&(radiobuttons.BLPFCOption.Value==1||radiobuttons.LVPFCOption.Value==1||radiobuttons.IPFCOption.Value==1||radiobuttons.PlatinumIPFCOption.Value==1)
%     ExpFile = xlsread('C:\Users\x00352\Desktop\BodePFC.xlsx');    
%     OuterLoopGainDigital=handles.General_test.PlantInfo.OL.LoopGainDigitalTF;
%     ExpFile = xlsread(handles.General_test.FilePath.BodeFilePath.String);
%     FreExp = ExpFile(:,1);
%     GainExp = ExpFile(:,2);
%     PhaseExp = ExpFile(:,3);
%     
%     FreRperS = 2*pi*FreExp;
%     [SimG,SimP] = bode(OuterLoopGainDigital,FreRperS);
%     
%     arrsize = size(SimG);
%     arrlength = arrsize(3);
%     
%     for iplot = 1:arrlength
%         SimGain(iplot) = 20*log10(SimG(1,1,iplot));
%         SimPhase(iplot)= SimP(1,1,iplot)-180;
%         %             SimPhase(iplot)= SimP(1,1,iplot)-360;
%     end
%     
%     h1=subplot(2,1,1); %(subplot(row,column,Grid position for new axes)
%     semilogx(FreExp, SimGain,'-.r', 'LineWidth', 1.5);  % Simulation
%     hold on;
%     semilogx(FreExp, GainExp, 'LineWidth', 1.5);        % Measured
%     hold on;
%     grid on;
%     legend('Simulated','Measured')
%     ylabel('Magnitude (dB)');
%     
%     h2=subplot(2,1,2);  %(subplot(row,column,Grid position for new axes)
%     semilogx(FreExp, SimPhase,'-.r', 'LineWidth', 1.5);
%     hold on;
%     semilogx(FreExp, PhaseExp, 'LineWidth', 1.5);
%     hold on;
%     grid on;
%     legend('Simulated','Measued')
%     xlabel('Frequency (Hz)');
%     ylabel('Phase (deg)');
%     
    
    