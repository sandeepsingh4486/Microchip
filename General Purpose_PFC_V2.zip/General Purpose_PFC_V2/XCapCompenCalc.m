function XCapCompenCalc(hObject,~) %X- capacitor cimpensation calculations
handles=guidata(hObject);

Xcap = str2double(handles.General_test.CommonSpecs.XCap.String)*1e-6;
PWMSamplingFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String)*1000;
Vinmin =  str2double(handles.General_test.CommonSpecs.VinMin.String);
LineUnderFreqLimit = str2double(handles.IPT5.FeaturesConfig.LineUnderFrequencyLimitTextBox.String);
OLPWMSampFreqC = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
Ibase = handles.FeedbackNetworkTab.Ibase;
Vinbase = (handles.FeedbackNetworkTab.FeedbackParameters.OL.Vinbase);

%% 2*pi*C_xcap/2*Vsample_rate  * (Rg/Rdiv)
   
XCapFreqGain = (2*pi*Xcap)/(2*PWMSamplingFreq)* (Ibase/Vinbase);
XCapFreqGainC=sprintf('%.3e',XCapFreqGain)
handles.IPT6.FeaturesConfiguration.XCapFreqGainTextBox.String =  XCapFreqGainC;

%% 2*pi*fmax*C*Vpk*Rg*1241
 
XCapCurrMaxCnts = 2 * pi * PWMSamplingFreq* Vinmin *Ibase;
XCapCurrMaxCntsC=sprintf('%.3e',XCapCurrMaxCnts)
handles.IPT6.FeaturesConfiguration.XCapCurrentMaxTextBox.String =  XCapCurrMaxCntsC;
%% XCAP_VAC_ARRAY   1/fmin / (Vsample_rate * 4)
XCapVacArray = (1/LineUnderFreqLimit)*(1/(OLPWMSampFreqC*4));
XCapVacArrayC=sprintf('%.3e',XCapVacArray)
handles.IPT6.FeaturesConfiguration.XCapVacArrayTextBox.String =  XCapVacArrayC;