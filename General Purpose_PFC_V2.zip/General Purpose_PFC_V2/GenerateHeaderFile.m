function GenerateHeaderFile(hObject,~)
handles=guidata(hObject);

%% IPT1 Handles
% tic; % to measure the timing
MinVoltage = handles.SpecificationsTab.CommonSpecs.VinMin.String;
MinVoltageP = str2double(handles.SpecificationsTab.CommonSpecs.VinMin.String);
OutputVoltage = handles.SpecificationsTab.CommonSpecs.Vout.String;
OutputVoltageP = str2double(handles.SpecificationsTab.CommonSpecs.Vout.String);
OutputPower = handles.SpecificationsTab.CommonSpecs.Pout.String;
EMIXCapacitor = handles.SpecificationsTab.CommonSpecs.XCap.String;
Inductance = handles.SpecificationsTab.CommonSpecs.Inductor.Inductance.String;
Inductor_DCR = handles.SpecificationsTab.CommonSpecs.Inductor.DCR.String;
Capacitance = handles.SpecificationsTab.CommonSpecs.Capacitor.Capacitance.String;
Capacitor_ESR = handles.SpecificationsTab.CommonSpecs.Capacitor.ESR.String;
% MaxVoltage = handles.SpecificationsTab.CommonSpecs.VinMax.String;
XC1 = str2double(handles.SpecificationsTab.CommonSpecs.XCap.String)*1e-6;                          % EMI Filter X capacitor
MaxLineFreq = 63;   % AC Line frequency 
OLSamplingFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String);
FilePath = handles.SpecificationsTab.FilePath.BodeFilePath.String;

TopologySel = handles.SpecificationsTab.SelectionDropdowns.TopologySelection.Value;
Topology = string(handles.SpecificationsTab.SelectionDropdowns.TopologySelection.String(TopologySel));

if(TopologySel == 1)
Topology = 'SINGLE_PHASE';
elseif(TopologySel == 2)
Topology = 'INTERLEAVED'; 
elseif(TopologySel == 3)
Topology = 'BRIDGELESS'; 
end
ControlMethodSel = handles.SpecificationsTab.SelectionDropdowns.ControlMethodSelection.Value;
ControlMethod = string(handles.SpecificationsTab.SelectionDropdowns.ControlMethodSelection.String(ControlMethodSel));
% a=toc; % to measure the timing

%% Parameters from IPT2

% ADCResValue = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.Value;
% ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String(ADCResValue);
ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
ADCLat = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String;

Rfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String;
Rfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String;
Rfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String;
Cfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String;
Cfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String;

Rfb13 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.String;
Rfb14 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.String;
Rfb15 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.String;
Cfb8 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.String;
Cfb9 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.String;

Rfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String;
Rfb5 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String;
Rfb6 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String;
Cfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String;
Cfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String;

CurrentMeas_sel=handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value;
Rfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String;
Rfb8 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String;
Cfb5 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String;
PrimaryTurnsRatioNp = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String;
SecondaryTurnsRatioNs = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String;

Rfb9 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String;
Rfb10 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String;
Rfb11 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String;
Cfb6 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String;
Rfb12 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String;
Cfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String;

%%
% FieldMat = ["Input Under Voltage Limit";"Input Over Voltage Limit";"Output Under Voltage Limit";"Output Over Voltage Limit"; ...
%     "Output Over Current Limit";"Over Temperature Limit";"Line under Freq Limit";"Line over Freq limit";"Relay Turn on limit"; ...
%     "Generic Parameter1 Limit";"Generic Parameter2 Limit";"Softtart Duration Limit";"Softstart Call Rate";"Burst Mode Enable Limit";...
%     "Burst Mode Disable Limit";"PWM Dithering %"];
% ValueMat = [FCP_IUVL;FCP_IOVL;FCP_OUVL;FCP_OOVL;FCP_OOCL;FCP_OTL;FCP_LUFL;FCP_LOFL;FCP_RTOL;FCP_GP1;FCP_GP2;FCP_SSDL;FCP_SSCR;FCP_BMEL;FCP_BMDL;FCP_PWMD];
% ValueMat(isnan(ValueMat))=0
% HysMat  = [FCP_IUVL_H;FCP_IOVL_H;FCP_OUVL_H;FCP_OOVL_H;FCP_OOCL_H;FCP_OTL_H;FCP_LUFL_H;FCP_LOFL_H;FCP_RTOL_H;FCP_GP1_H;FCP_GP2_H];
% 
% Fullfile = horzcat(FieldMat,ValueMat);
% Fullfile = {Fullfile}
% % FieldLength = length(FieldMat)
% % fid = fopen('data.h','wt')
% % for i = 1:FieldLength
% % fprintf(fid,'%s\n',FieldMat(1))
% % end 
% % fprintf(fid,'\n')
% % fclose(fid)
% % dlmwrite('data.h',ValueMat,'delimiter','\n','-append')
% 
% % T = table(FieldMat,ValueMat);
% dlmwrite('data2.h',cell2mat(Fullfile(:)))
% % writetable(T,'myData.txt','Delimiter','\t')
%% IPT3 handles

ILPWMFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String;
ILSampRatio = handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String;
ILSampRatioP = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String);
ILSampRatioP = (ILSampRatioP-1);
ILPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String;
% ILPWMSampFreqP = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String);
ILPTPER = handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String;
ILPTPERC = str2double(ILPTPER);
% ILPWMResolution = handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String;
ILComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String;
ILGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String;
ILCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String;
ILPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String;
ILMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String;
ILMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String;

OLPWMFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String;
OLSampRatio = handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String;
OLSampRatioP = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String);
OLSampRatioP = (OLSampRatioP-1);
OLPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String;
OLPWMSampFreqP = str2double(OLPWMSampFreq)*1000; %kHz to Hz
InputVoltageSampFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String;
OLPTPER = handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String; % this is input voltage sampling frequency
% OLPWMResolution = handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String;
OLComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String;
OLGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String;
OLCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String;
OLPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String;
OLMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String;
OLMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String;

ILCompensatorSel =handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
ILCompensator = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.String(ILCompensatorSel));
ILGain = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain.String;
ILGainh = floor(str2double(ILGain));  % used only for header file
ILPole1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1.String;
ILPole1h = floor(str2double(ILPole1));
ILPole2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2.String;
ILPole2h = floor(str2double(ILPole2));
% ILPole3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole3.String;
ILZero1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1.String;
ILZero1h = floor(str2double(ILZero1));
ILZero2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2.String;
ILZero2h = floor(str2double(ILZero2));
% ILZero3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero3.String;

ILP1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1.String;
% ILP1_cascaded = floor(str2double(ILP1_cascaded));
ILZ1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1.String;
% ILZ1_cascaded = floor(str2double(ILZ1_cascaded));
ILKdc1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1.String;
% ILKdc1_cascaded = floor(str2double(ILKdc1_cascaded));

ILP2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2.String;
% ILP2_cascaded = floor(str2double(ILP2_cascaded));
ILZ2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2.String;
% ILZ2_cascaded  = floor(str2double(ILZ2_cascaded ));
ILKdc2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2.String;
% ILKdc2_cascaded = floor(str2double(ILKdc2_cascaded));

ILP3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3.String;
% ILP3_cascaded = floor(str2double(ILP3_cascaded));
ILZ3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3.String;
% ILZ3_cascaded = floor(str2double(ILZ3_cascaded));
ILKdc3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3.String;
% ILKdc3_cascaded = floor(str2double(ILKdc3_cascaded));

OLCompensatorSel = handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;
OLCompensator = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.String(OLCompensatorSel));
OLGain = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain.String;
OLGainh = floor(str2double(OLGain));
OLPole1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1.String;
OLPole1h = floor(str2double(OLPole1));
OLPole2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2.String;
OLPole2h = floor(str2double(OLPole2));
% OLPole3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole3.String;
OLZero1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1.String;
OLZero1h = floor(str2double(OLZero1));
OLZero2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2.String;
OLZero2h = floor(str2double(OLZero2));
% OLZero3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero3.String;

OLP1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1.String;
% OLP1_cascaded = floor(str2double(OLP1_cascaded));
OLZ1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1.String;
% OLZ1_cascaded = floor(str2double(OLZ1_cascaded));
OLKdc1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1.String;
% OLKdc1_cascaded = floor(str2double(OLKdc1_cascaded));

OLP2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2.String;
% OLP2_cascaded = floor(str2double(OLP2_cascaded));
OLZ2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2.String;
% OLZ2_cascaded = floor(str2double(OLZ2_cascaded));
OLKdc2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2.String;
% OLKdc2_cascaded = floor(str2double(OLKdc2_cascaded));

OLP3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3.String;
% OLP3_cascaded = floor(str2double(OLP3_cascaded));
OLZ3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3.String;
% OLZ3_cascaded = floor(str2double(OLZ3_cascaded));
OLKdc3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3.String;
% OLKdc3_cascaded = floor(str2double(OLKdc3_cascaded));

%% IPT5 Start
%%
IPUnderVoltageLimit = handles.IPT5.FeaturesConfig.IPUnderVoltageLimitTextBox.String;
IPUnderVoltageHys = handles.IPT5.FeaturesConfig.IPUnderVoltageHysTextBox.String;
IPUnderVoltageFaultenable = handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultenableTextBox.String;
IPUnderVoltageFaultdisable = handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultdisableTextBox.String;
IPOverVoltageLimit = handles.IPT5.FeaturesConfig.IPOverVoltageLimitTextBox.String;
IPOverVoltageHys = handles.IPT5.FeaturesConfig.IPOverVoltageHysTextBox.String;
IPoverVoltageFaultenable = handles.IPT5.FeaturesConfig.IPoverVoltage.FaultenableTextBox.String;
IPoverVoltageFaultdisable = handles.IPT5.FeaturesConfig.IPoverVoltage.FaultdisableTextBox.String;
OPUnderVoltageLimit = handles.IPT5.FeaturesConfig.OPUnderVoltageLimitTextBox.String;
OPUnderVoltageHys = handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox.String;
OPUnderVoltageFaultenable = handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultenableTextbox.String;
OPUnderVoltageFaultdisable = handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox.String;
OPOverVoltageLimit = handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String;
OPOverVoltageHys = handles.IPT5.FeaturesConfig.OPOverVoltageHysTextBox.String;
OPOverVoltageFaultenable = handles.IPT5.FeaturesConfig.OPOverVoltage.FaultenableTextbox.String;
OPOverVoltageFaultdisable = handles.IPT5.FeaturesConfig.OPOverVoltage.FaultdisableTextbox.String;
OPOverPowerLimit = handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String;
OPOverPowerLimitHys = handles.IPT5.FeaturesConfig.OPOverCurrentLimitHysTextBox.String;
OPOverPowerFaultEnable = handles.IPT5.FeaturesConfig.OPOverCurrent.FaultEnableTextbox.String;
OPOverPowerLimitFaultDisable = handles.IPT5.FeaturesConfig.OPOverCurrentLimitFaultDisableTextBox.String;
% OverTemperatureLimit = handles.IPT5.FeaturesConfig.OverTemperatureLimitTextBox.String;
% OverTemperatureLimitHys = handles.IPT5.FeaturesConfig.OverTemperatureLimitHysTextBox.String;
% OverTemperatureLimitFaultEnable = handles.IPT5.FeaturesConfig.OverTemperaturefaultenableTextbox.String;
% OverTemperatureLimitFaultdisable = handles.IPT5.FeaturesConfig.OverTemperatureLimitFaultdisableTextbox.String;
LineUnderFrequencyLimit = handles.IPT5.FeaturesConfig.LineUnderFrequencyLimitTextBox.String;
LineUnderFreqHys = handles.IPT5.FeaturesConfig.LineUnderFreqHysTextBox.String; 
LineUnderFreqfaultenable = handles.IPT5.FeaturesConfig.LineUnderFreqfaultenableTextbox.String; 
LineUnderFreqFaultdisable = handles.IPT5.FeaturesConfig.LineUnderFreqFaultdisableTextBox.String; 
LineOverFrequencyLimit = handles.IPT5.FeaturesConfig.LineOverFrequencyLimitTextBox.String;
LineOverFrequencyHys = handles.IPT5.FeaturesConfig.LineOverFrequencyHysTextBox.String;
LineOverFrequencyLimitFaultenable = handles.IPT5.FeaturesConfig.LineOverFrequencyLimitFaultenableTextBox.String;
LineOverFrequencyLimitfaultdisable = handles.IPT5.FeaturesConfig.LineOverFrequencyLimitfaultdisableTextBox.String;

RelayTurnONLimit = handles.IPT5.FeaturesConfig.RelayTurnONLimitTextBox.String;
RelayTurnONLimitHys = handles.IPT5.FeaturesConfig.RelayTurnONLimitHysTextBox.String;
RelayTurnONLimitfaultenable = handles.IPT5.FeaturesConfig.RelayTurnONLimitfaultenableTextBox.String;
RelayTurnONLimitFaultdisable = handles.IPT5.FeaturesConfig.RelayTurnONLimitFaultdisableTextBox.String;
GenericParameter1Limit = handles.IPT5.FeaturesConfig.GenericParameter1LimitTextBox.String;
GenericParameter1LimitHys = handles.IPT5.FeaturesConfig.GenericParameter1LimitHysTextBox.String;
GenericParameter1FaultEnable = handles.IPT5.FeaturesConfig.GenericParameter1FaultEnableTextBox.String; 
GenericParameter1FaultDisable = handles.IPT5.FeaturesConfig.GenericParameter1FaultDisableTextBox.String; 
GenericParameter2Limit = handles.IPT5.FeaturesConfig.GenericParameter2LimitTextBox.String; 
GenericParameter2LimitHys = handles.IPT5.FeaturesConfig.GenericParameter2LimitHysTextBox.String; 
GenericParameter2LimitFaultEnable = handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultEnableTextBox.String; 
GenericParameter2LimitFaultDisable = handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultDisableTextBox.String;

%% IPT5 handles end
%% Date stamping
%%
date = datestr(now, 'dd/mm/yy-HH:MM');

%% IPT6 Start
%%
SoftStartDurationLimit = handles.IPT6.FeaturesConfiguration.SoftStartDurationLimitTextBox.String;
SoftStartDurationLimitP = (str2num(SoftStartDurationLimit))*1e6;
SoftStartCallRate = handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.String;
SoftStartCallRateP = (str2num(SoftStartCallRate))*1e6;
BurstModeEnableLimit = handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String;
BurstModeEnableLimitWatts = handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String;
BurstModeDisableLimit = handles.IPT6.FeaturesConfiguration.BurstModeOffCyclesTextBox.String;
BurstModeOffCycles = handles.IPT6.FeaturesConfiguration.BurstModeDisableLimitTextBox.String;
PWMDitheringLimit = handles.IPT6.FeaturesConfiguration.PWMDitheringLimitTextBox.String;
DCMCorrectionTextBox = handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox.String;
PhaseSheddingIPFCTextBox = handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String;
PhaseSheddingIPFCTextBoxWatts = handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String;
HysPhaseSheddingIPFCTextBox = handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String;
HysPhaseSheddingIPFCTextBoxWatts = handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String

XCapFreqGain = handles.IPT6.FeaturesConfiguration.XCapFreqGainTextBox.String;
XCapCurrMaxCnts = handles.IPT6.FeaturesConfiguration.XCapCurrentMaxTextBox.String;
XCapVacArray = handles.IPT6.FeaturesConfiguration.XCapVacArrayTextBox.String;

 MaxRestartAttempts =  handles.IPT6.FeaturesConfiguration.MaxRestartAttemptsTextBox.String;
 SystemOperational =   handles.IPT6.FeaturesConfiguration.SystemOperationalTextBox.String;
 SystemRestartTime =   handles.IPT6.FeaturesConfiguration.SystemRestartTimeTextBox.String;
%%IPT6 handles end
%%
ProjName=handles.ProjectInformation.ProjName;

%% IPT4
% DeviceSelVal = handles.dsPICDSCTab.DeviceSelection.Value;
DeviceSelVal = handles.dsPICDSCTab.DeviceSelection.DeviceSelectionDropdown.Value;
DeviceSel = handles.dsPICDSCTab.DeviceSelection.DeviceSelectionDropdown.String{DeviceSelVal,1};

DeviceClock=handles.dsPICDSCTab.IPCommonPanel.DeviceClock.String;

PWM_GENx_Val =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratorxText.Value;
PWM_GENx =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratorxText.String{PWM_GENx_Val,1};
% 
% PWM_GENx_H_Val =  handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratorxTextPWMH.Value;
% PWM_GENx_L_Val =  handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratorxTextPWML.Value;
% 
PWM_GENy_Val =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratoryText.Value;
PWM_GENy =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratoryText.String{PWM_GENy_Val,1};

% PWM_GENy_H_Val =  handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratoryTextPWMH.Value;
% PWM_GENy_L_Val =  handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratoryTextPWML.Value;

PWM_Enable_Val = handles.dsPICDSCTab.Peripheralselection.EnableText.Value;
PWM_Enable     = handles.dsPICDSCTab.Peripheralselection.EnableText.String{PWM_Enable_Val,1};

PWM_Enable_PinName_Val = handles.dsPICDSCTab.Peripheralselection.Enable_drive.Value;
PWM_Enable_PinName   = handles.dsPICDSCTab.Peripheralselection.Enable_drive.String{PWM_Enable_PinName_Val,1};

PWM_Res_Val1 =  handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1.Value;
PWM_Res1 =  handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1.String{PWM_Res_Val1,1};

% PWM_Res_Val2 =  handles.dsPICDSCTab.Peripheralselection.PWMResolutionText2.Value;
% PWM_Res2 =  handles.dsPICDSCTab.Peripheralselection.PWMResolutionText2.String{PWM_Res_Val2,1};

ADC_PFC_I_Val =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrentText.Value;
ADC_PFC_I =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrentText.String{ADC_PFC_I_Val,1};

ADC_PFC_I1_Val =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent1Text.Value;
ADC_PFC_I1 =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent1Text.String{ADC_PFC_I1_Val,1};

ADC_PFC_I2_Val =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent2Text.Value;
ADC_PFC_I2 =  handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent2Text.String{ADC_PFC_I2_Val,1};

ADC_Line_Voltage_Val =  handles.dsPICDSCTab.Peripheralselection.ADCLineVoltageText.Value;
ADC_Line_Voltage =  handles.dsPICDSCTab.Peripheralselection.ADCLineVoltageText.String{ADC_Line_Voltage_Val,1};

ADC_Neutral_Voltage_Val =  handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.Value;
ADC_Neutral_Voltage =  handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.String{ADC_Neutral_Voltage_Val,1};

ADC_Output_Voltage_Val =  handles.dsPICDSCTab.Peripheralselection.ADCOutputVoltageText.Value;
ADC_Output_Voltage =  handles.dsPICDSCTab.Peripheralselection.ADCOutputVoltageText.String{ADC_Output_Voltage_Val,1};

Output_Over_V_prot_Val =  handles.dsPICDSCTab.Peripheralselection.ACMPOutputVoltageProtectionText.Value;
Output_Over_V_prot =  handles.dsPICDSCTab.Peripheralselection.ACMPOutputVoltageProtectionText.String{Output_Over_V_prot_Val,1};

ZCD1_Val =  handles.dsPICDSCTab.Peripheralselection.ACMPZeroCurrentDetection1Text.Value;
ZCD1 =  handles.dsPICDSCTab.Peripheralselection.ACMPZeroCurrentDetection1Text.String{ZCD1_Val,1};

ZCD2_Val =  handles.dsPICDSCTab.Peripheralselection.ACMPZeroCurrentDetection2Text.Value;
ZCD2 =  handles.dsPICDSCTab.Peripheralselection.ACMPZeroCurrentDetection2Text.String{ZCD2_Val,1};

Relay_Drive_Val =  handles.dsPICDSCTab.Peripheralselection.RelayDriveText.Value;
Relay_Drive =  handles.dsPICDSCTab.Peripheralselection.RelayDriveText.String{Relay_Drive_Val,1};

Relay_Drive_Port_Val =  handles.dsPICDSCTab.Peripheralselection.RelayDrivePort.Value;
Relay_Drive_Port =  handles.dsPICDSCTab.Peripheralselection.RelayDrivePort.String{Relay_Drive_Port_Val,1};

GPIO1_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO1Text.Value;
GPIO1 =  handles.dsPICDSCTab.Peripheralselection.GPIO1Text.String{GPIO1_Val,1};

GPIO1_Port_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO1Port.Value;
GPIO1_Port =  handles.dsPICDSCTab.Peripheralselection.GPIO1Port.String{GPIO1_Port_Val,1};

GPIO2_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO2Text.Value;
GPIO2 =  handles.dsPICDSCTab.Peripheralselection.GPIO2Text.String{GPIO2_Val,1};

GPIO2_Port_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO2Port.Value;
GPIO2_Port =  handles.dsPICDSCTab.Peripheralselection.GPIO2Port.String{GPIO2_Port_Val,1};

GPIO3_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO3Text.Value;
GPIO3 =  handles.dsPICDSCTab.Peripheralselection.GPIO3Text.String{GPIO3_Val,1};

GPIO3_Port_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO3Port.Value;
GPIO3_Port =  handles.dsPICDSCTab.Peripheralselection.GPIO3Port.String{GPIO3_Port_Val,1};

% GPIO4_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO4Text.Value;
% GPIO4 =  handles.dsPICDSCTab.Peripheralselection.GPIO4Text.String{GPIO4_Val,1};
% 
% GPIO4_Port_Val =  handles.dsPICDSCTab.Peripheralselection.GPIO4Port.Value;
% GPIO4_Port =  handles.dsPICDSCTab.Peripheralselection.GPIO4Port.String{GPIO4_Port_Val,1};

DAC_Data = handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String;




%%
%%
%% GPT3
% if empty(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0)
if isempty(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1.String)
    
    errordlg('"Run" the application before chosing "Generate Header File" ','Error');
    
    return;
    
end
% Absolute Coefficients IL
B0_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0);
B1_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B1);
B2_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B2);
B3_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B3);
B4_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B4);

%A0_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A0);
A1_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A1);
A2_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A2);
A3_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A3);
A4_Abs_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A4);

% Normalized Coefficients IL
B0_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B0);
B1_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B1);
B2_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B2);
B3_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B3);
B4_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B4);

%A0_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A0);
A1_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A1);
A2_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A2);
A3_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A3);
A4_Norm_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A4);

%IL Normalized Q15 Parameters
IL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.Normal);
IL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostShift);
IL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostScalar);

% Cascaded Coefficients IL
B10_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B11);
A10_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A10);
A11_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A11);
PS_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostShift);

B20_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B21);
A20_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A20);
A21_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A21);

B30_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B31);
A30_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A30);
A31_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A31);
% Absolute Coefficients OL
B0_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0);
B1_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1);
B2_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2);
B3_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3);
B4_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B4);

%A0_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0);
A1_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1);
A2_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2);
A3_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3);
A4_Abs_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A4);

% Normalized Coefficients OL
B0_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0);
B1_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1);
B2_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2);
B3_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3);
B4_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B4);

%A0_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0);
A1_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1);
A2_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2);
A3_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3);
A4_Norm_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A4);

%OL Normalized Q15 Parameters
OL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.Normal);
OL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostShift);
OL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostScalar);

% Cascaded Coefficients OL
B10_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B11);
% A10_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A10);
A11_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A11);
PS_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostShift);

B20_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B21);
% A20_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A20);
A21_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A21);

B30_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B31);
% A30_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A30);
A31_OL = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A31);

%% handles for GPT3

% Absolute Coefficients IL
B0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0);
B1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B1);
B2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B2);
B3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B3);
B4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A0);
A1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A1);
A2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A2);
A3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A3);
A4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A4);
% 
% % Normalized Coefficients IL
B0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B0);
B1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B1);
B2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B2);
B3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B3);
B4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B4);

% A0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A0);
A1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A1);
A2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A2);
A3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A3);
A4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A4);
% 
%% Cascaded Coefficients IL
%% the following handles are create for header file genaration
%%
% A10_IL_C = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_IL_C =  string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostShift);
% 
% A20_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A20);
A21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A30);
A31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B31);

%%
% % Absolute Coefficients OL
B0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0);
B1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1);
B2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2);
B3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3);
B4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0);
A1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1);
A2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2);
A3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3);
A4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A4);
 
%% Normalized Coefficients OL
B0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0);
B1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1);
B2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2);
B3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3);
B4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B4);

A0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0);
A1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1);
A2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2);
A3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3);
A4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A4);


%% Cascaded Coefficients OL
%%
% A10_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_OL_C  = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostShift);

% A20_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A20;
A21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A30;
A31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B31);

%% Counts computation
ADCVoltC = str2double(ADCVolt);
ADCResC = 2^str2double(ADCRes);
Rfb1C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String)*1e3;
Rfb2C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String)*1e3;
% Rfb3C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String)*1e3;
% Cfb1C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String)*1e-12;
% Cfb2C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String)*1e-12;

Rfb4C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
Rfb5C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
% Rfb6C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String)*1e3;
% Cfb3C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String)*1e-12;
% Cfb4C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String)*1e-12;

Rfb7C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String)*1e3;
% Rfb8C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String)*1e3;
% Cfb5C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String)*1e-12;
NpC = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String);
NsC = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String);

Rfb9C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String)*1e3;
Rfb10C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String)*1e3;
Rfb11C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String)*1e3;
% Cfb6C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String)*1e-12;
% Rfb12C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String)*1e3;
% Cfb7C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String)*1e-12;

%%
%% Calculations
%%
VinbaseC = (ADCVoltC / (Rfb2C / (Rfb2C+Rfb1C)));
VoutbaseC = (ADCVoltC / (Rfb5C / (Rfb5C+Rfb4C)));
IinbaseC = (ADCVoltC / (Rfb7C / (NsC/NpC)));

ILPWMSampFreqC = str2double(ILPWMSampFreq);
IPUnderVoltageLimitC = str2double(IPUnderVoltageLimit);
IPUnderVoltageHysC = str2double(IPUnderVoltageHys);
IPOverVoltageLimitC = str2double(IPOverVoltageLimit);
IPOverVoltageHysC = str2double(IPOverVoltageHys);
OPUnderVoltageLimitC = str2double(OPUnderVoltageLimit);
% OPUnderVoltageHysC = str2double(OPUnderVoltageHys);
OPOverVoltageLimitC = str2double(OPOverVoltageLimit);
OPOverVoltageHysC = str2double(OPOverVoltageHys);

OPOverPowerLimitC = str2double(OPOverPowerLimit);
OPOverPowerHysC = str2double(OPOverPowerLimitHys);
OLPTPERC = str2double(OLPTPER);
PWMBits = ceil(log2(ILPTPERC));
LineUnderFrequencyLimitC = str2double(LineUnderFrequencyLimit);
LineUnderFreqHysC = str2double(LineUnderFreqHys);
LineOverFrequencyLimitC = str2double(LineOverFrequencyLimit);
LineOverFreqHysC = str2double(LineOverFrequencyHys);

% OverTemperatureLimitC = str2double(OverTemperatureLimit);
% OverTemperatureLimitHysC = str2double(OverTemperatureLimitHys);
% protection limits in counts
IPUVLimitCounts  = ceil(ADCResC * IPUnderVoltageLimitC / VinbaseC) ;
IPUVHysCounts = ceil(ADCResC * IPUnderVoltageHysC / VinbaseC) ;
IPOVLimitCounts  = ceil(ADCResC * IPOverVoltageLimitC / VinbaseC) ;
IPOVHysCounts = ceil(ADCResC * IPOverVoltageHysC / VinbaseC) ;
OPUVLimitCounts = ceil(ADCResC * OPUnderVoltageLimitC / VoutbaseC) ;
% OPUVHysCounts = ADCResC * OPUnderVoltageHysC / VoutbaseC ;
OPOVLimitCounts = ceil(ADCResC * OPOverVoltageLimitC / VoutbaseC) ;
OPOVHysCounts = ceil(ADCResC * OPOverVoltageHysC / VoutbaseC) ;
% OPOCLimitCounts =  ceil(ADCResC * OPOverCurrentLimitC/ IinbaseC) ;
% OPOCHysCounts = ceil(ADCResC * OPOverCurrentHysC / IinbaseC) ;
OPOPLimitCounts =  ceil(ADCResC * OPOverPowerLimitC/ IinbaseC); % output over power, this number to be computed.
OPOPHysCounts = ceil(ADCResC * OPOverPowerHysC / IinbaseC);

% Sensor part No: MCP9700;  TA = Ambient Temperature
% VOUT = Sensor Output Voltage; TC = Temperature Coefficient
% V0�C = Sensor Output Voltage at 0�C 500mV
% Temp Sensor VOUT = TC * TA + V0�C;10mV/�C * TA + 500mV
% Ex: 100�C ---> 1V + 500mV = 1.5Volts
% OverTempLimitCounts = (((OverTemperatureLimitC * 0.01) + 0.5) * ADCResC / ADCVoltC);
% OverTempLimitHysCounts = (((OverTemperatureLimitHysC * 0.01) + 0.5) * ADCResC / ADCVoltC);

%% Line frequency calculations
% MinLineFreqCounts = VacSampling/(MinLine Freq*2)
% Min_Thresh_CNTS = (MinLineFreqCounts * PWM Period)/ (2^no of PWM bits)
IPUFLimitCounts = ceil(((ILPWMSampFreqC*1e3)/(LineUnderFrequencyLimitC*2))*(ILPTPERC/(2^PWMBits))); % Input Under frequency Counts
IPUFLimitHysCounts = ceil(((ILPWMSampFreqC*1e3)/((LineUnderFrequencyLimitC+LineUnderFreqHysC)*2))*(ILPTPERC/(2^PWMBits)));

IPOFLimitCounts = ceil(((ILPWMSampFreqC*1e3)/(LineOverFrequencyLimitC*2))*(ILPTPERC/(2^PWMBits))); % Input Overer frequency Counts
IPOFLimitHysCounts = ceil(((ILPWMSampFreqC*1e3)/((LineOverFrequencyLimitC+LineOverFreqHysC)*2))*(ILPTPERC/(2^PWMBits)));

%%
XCAPFREQGAIN = ceil(((2*pi*MaxLineFreq*XC1)*(MinVoltageP*IinbaseC/VinbaseC))*32767);


%%
% Converter Reference Voltage calculation
OutPutVoltRefC = ceil(((ADCResC * OutputVoltageP / VoutbaseC))) ;
%% PWM Dithering Calcs
%% 
PWMDitheringLimitP = str2double(PWMDitheringLimit);
Fdither = 125;
MaxDitherFactor = round((32767 + (PWMDitheringLimitP * 32767) /100),0) ;
MinDitherFactor = round((32767 - (PWMDitheringLimitP * 32767) /100),0) ;
DitherScaleFactor = round((2*(MaxDitherFactor  - MinDitherFactor) / (ILPWMSampFreqC *1e3/Fdither)),0);

%% VCOMPSCALER clculations
Vcompscaler = round(( VinbaseC * IinbaseC) / (VoutbaseC * ADCVoltC),0)+1;
vcompscaler=num2str(Vcompscaler);

%% ZERO CROSS SCALER ....Scaler = roundup (log2(PWM_PERIOD),0) 
ZeroCrossScaler = ceil(log2(ILPTPERC));
ZerocrossScaler=num2str(ZeroCrossScaler);
%% Calculations end
%% .h file creation command
%% Parameters
% pathName = cd;
% fileName = 'Parameters.h';
[fileName,pathName] = uiputfile2('Parameters.h');
file_path = fullfile(pathName,fileName);
fid3 = fopen(file_path, 'wt');


%% IPT1
fprintf(fid3,'/*********************************************************************************************************');
fprintf(fid3,'\n� 2018 Microchip Technology Inc and its subsidiaries.\n\nSubject to your compliance with these terms, you may use Microchip software and any \nderivatives exclusively with Microchip products. It is your responsibility to comply with third party \nlicense terms applicable to your use of third party software (including open source software) that \nmay accompany Microchip software.\n\n');
fprintf(fid3,'THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER \nEXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY \nIMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS \nFOR A PARTICULAR PURPOSE. \n\n');
fprintf(fid3,'IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,\nINCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND \nWHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP \nHAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO \nTHE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP`S TOTAL LIABILITY ON ALL \nCLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT \nOF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.\n\n ');       
fprintf(fid3,'*********************************************************************************************************/');

fprintf(fid3,'\n\n\n/* Comment: Specifications */\n\n#define CHOSEN_TOPOLOGY\t\t %s\n\n#define CONTROL_METHOD\t\t %s\n\n\n/*Comment: User Entered Specifications*/\n\n#define NOMINAL_AC_INPUT_VOLTAGE_MIN\t\t\t %s \n\n#define EMI_FILTER_X_CAPACITOR\t\t\t\t\t %s\n\n#define DC_OUTPUT_VOLTAGE\t\t\t\t\t\t %s \n\n#define OUTPUT_POWER\t\t\t\t\t\t\t %s\n\n#define INDUCTANCE\t\t\t\t\t\t\t\t %s \n\n#define INDUCTOR_DCR\t\t\t\t\t\t\t %s \n\n#define CAPACITANCE\t\t\t\t\t\t\t\t %s \n\n#define CAPACITOR_ESR\t\t\t\t\t\t\t %s',Topology,ControlMethod,MinVoltage,EMIXCapacitor,OutputVoltage,OutputPower,Inductance,Inductor_DCR,Capacitance,Capacitor_ESR);
%%
%% IPT2
fprintf(fid3,'\n\n\n/* Comment: User Entered Feedback Network Specifications*/\n\n#define ADC_RESOLUTION\t\t%s\n\n#define ADC_VOLT \t\t\t%s\n\n#define ADC_LATENCY \t\t%s',ADCRes,ADCVolt,ADCLat);
fprintf(fid3,'\n\n\n/* INPUT VOLTAGE MEASUREMENTS */\n\n#define Rfb1\t\t\t\t\t\t %s\n\n#define Rfb2\t\t\t\t\t\t %s\n\n#define Rfb3\t\t\t\t\t\t %s \n\n#define Cfb1\t\t\t\t\t\t %s\n\n#define Cfb2\t\t\t\t\t\t %s',Rfb1,Rfb2,Rfb3,Cfb1,Cfb2);
fprintf(fid3,'\n\n\n/* OUTPUT VOLTAGE MEASUREMENTS */\n\n#define Rfb4\t\t %s\n\n#define Rfb5\t\t %s\n\n#define Rfb6\t\t %s \n\n#define Cfb3\t\t %s\n\n#define Cfb4\t\t %s',Rfb4,Rfb5,Rfb6,Cfb3,Cfb4);
if  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value==1
    fprintf(fid3,'\n\n\n/* CUREENT MEASUREMNT (CURRENT TRANSFORMER) */\n\n#define Rfb7\t\t\t\t\t\t %s\n\n#define Rfb8\t\t\t\t\t\t %s\n\n#define Cfb5\t\t\t\t\t\t %s \n\n#define PRIMARY_TURNS_RATIO_Np\t\t %s\n\n#define SECONDARY_TURNS_RATIO_Ns\t %s*/',Rfb7,Rfb8,Cfb5,PrimaryTurnsRatioNp,SecondaryTurnsRatioNs);
elseif  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value==1
    fprintf(fid3,'\n\n\n/* CURRENT MEASUREMNT(SHUNT RESISTOR) */\n\n #define Rfb9\t\t %s\n\n#define Rfb10\t\t %s\n\n#define Rfb11\t\t %s \n\n#define Cfb6\t\t %s\n\n#define Rfb12\t\t %s\n\n#define Cfb7\t\t %s\n*/',Rfb9,Rfb10,Rfb11,Cfb6,Rfb12,Cfb7);
end

%% IPT3
fprintf(fid3,'\n\n\n/* Comment: Control Loop Parameters*/\n\n/* INNER LOOP */\n\n#define VOLTAGE_REFERENCE\t\t\t\t%s\n\n#define PWM_SW_FREQUENCY\t\t\t\t%s\n\n#define IL_SAMPLING_RATIO\t\t\t\t %s\n\n#define IL_PWM_SAMPLING_FREQUENCY\t\t %s\n\n#define PWM_SW_PERIOD\t\t %s \n\n#define IL_COMPUTATIONAL_DELAY\t\t\t %s\n\n#define GATE_DRV_DELAY\t\t\t\t %s \n\n#define IL_CROSSOVER_FREQUENCY\t\t\t %s \n\n#define IL_PHASE_MARGIN\t\t\t\t\t %s \n\n#define IL_MIN_CONTROL_OUTPUT\t\t\t %s \n\n#define IL_MAX_CONTROL_OUTPUT\t\t\t %s',num2str(OutPutVoltRefC),ILPWMFreq,ILSampRatio,ILPWMSampFreq,ILPTPER,ILComputationalDelay,ILGateDriveDelay,ILCrossOverFreq,ILPhaseMargin,ILMinControlOutput,ILMaxControlOutput);

fprintf(fid3,'\n\n/* OUTER LOOP */\n\n#define OL_SAMPLING_RATIO\t\t\t\t %s\n\n#define OL_PWM_SAMPLING_FREQUENCY\t\t %s \n\n#define OL_COMPUTATIONAL_DELAY\t\t\t %s\n\n#define OL_CROSSOVER_FREQUENCY\t\t\t %s \n\n#define OL_PHASE_MARGIN\t\t\t\t\t %s \n\n#define OL_MIN_CONTROL_OUTPUT\t\t\t %s \n\n#define OL_MAX_CONTROL_OUTPUT\t\t\t %s',OLSampRatio,OLPWMSampFreq,OLComputationalDelay,OLCrossOverFreq,OLPhaseMargin,OLMinControlOutput,OLMaxControlOutput);
%% IPT4
% tic;
% fprintf(fid3,'\n\n\n/* Comment: dsPIC DSC Configuration Parameters */\n\n#define Device Selection\t\t\t\t %s\n\n#define PWM_GENERATOR_Q1/Q2 \t\t\t\t %s\n\n#define PWM_GENERATOR_Q3/Q4 \t\t\t\t %s \n\n#define PWM_RESOLUTION\t\t\t\t\t %s\n\n#define ADC_PFC_CURRENT\t\t\t\t\t %s \n\n#define ADC_PFC_CURRENT1\t\t\t\t %s\n\n#define ADC_PFC_CURRENT2\t\t\t\t %s \n\n#define ADC_LINE_VOLTAGE\t\t\t\t %s \n\n#define ADC_NEUTRAL_VOLTAGE\t\t\t\t %s \n\n#define ADC_OUTPUT_VOLTAGE\t\t\t\t %s \n\n#define ADC_OUTPUT_OVER_VOLTAGE\t\t\t %s\n\n#define CMP_DAC_DATA\t\t\t\t\t\t %s\n\n#define CMP_ZCD1\t\t\t\t\t\t %s\n\n#define CMP_ZCD2\t\t\t\t\t\t %s',DeviceSel,PWM_GENx,PWM_GENy,PWM_Res1,ADC_PFC_I,ADC_PFC_I1,ADC_PFC_I2,ADC_Line_Voltage,ADC_Neutral_Voltage,ADC_Output_Voltage,Output_Over_V_prot,DAC_Data,ZCD1,ZCD2);
% fprintf(fid3,'\n\n#define RELAY_GPIO_PORT\t\t\t\t\t\t %s\n\n#define RELAY_GPIO_PORTNUM\t\t\t\t %s\n\n#define GPIO 1\t\t\t\t\t\t\t %s \n\n#define GPIO1_PORT\t\t\t\t\t\t %s \n\n#define GPIO 2\t\t\t\t\t\t\t %s\n\n#define GPIO2_PORT\t\t\t\t\t\t %s \n\n#define GPIO 3\t\t\t\t\t\t\t %s \n\n#define GPIO3_PORT\t\t\t\t\t\t %s',Relay_Drive,Relay_Drive_Port,GPIO1,GPIO1_Port,GPIO2,GPIO2_Port,GPIO3,GPIO3_Port);
% wholeTime = toc;
fprintf(fid3,'\n\n\n/* Comment: dsPIC DSC Configuration Parameters */\n\n#define Device Selection\t\t\t\t %s',DeviceSel);
fprintf(fid3,'\n\n#define DEVICE_CLOCK\t\t\t\t %s MHz',DeviceClock);
fprintf(fid3,'\n\n#define PWM_GENERATOR_Q1/Q2\t\t\t\t %s',PWM_GENx);
fprintf(fid3,'\n\n#define PWM_GENERATOR_Q3/Q4\t\t\t\t %s',PWM_GENy);
fprintf(fid3,'\n\n#define PFET_GPIO_PORT\t\t\t\t %s',PWM_Enable);
fprintf(fid3,'\n\n#define PFET_GPIO_PORTNUM\t\t\t\t %s',PWM_Enable_PinName);
fprintf(fid3,'\n\n#define PWM_RESOLUTION\t\t\t\t %s',PWM_Res1);
if handles.dsPICDSCTab.ADC_PFCCurrentEnable.BLPFCCurrent.Value==1
    fprintf(fid3,'\n\n#define IND_CURR_SENSE \t\t DISABLED\n\n #define ADC_PFC_CURRENT\t\t\t\t %s',ADC_PFC_I);
else
fprintf(fid3,'\n\n#define IND_CURR_SENSE \t\t ENABLED\n\n #define ADC_PFC_CURRENT1\t\t\t\t %s',ADC_PFC_I1);
fprintf(fid3,'\n\n#define ADC_PFC_CURRENT2\t\t\t\t %s',ADC_PFC_I2);
end
fprintf(fid3,'\n\n#define ADC_LINE_VOLTAGE\t\t\t\t %s',ADC_Line_Voltage);
% if handles.dsPICDSCTab.ADC_PFCCurrentEnable.ADCNeutralVoltageRadio.Value==1
% fprintf(fid3,'\n\n/*ADC_Neutral_Voltage \t\t ENABLED*/\n\n #define ADC_NEUTRAL_VOLTAGE\t\t\t\t %s',ADC_Neutral_Voltage);
% else
%   fprintf(fid3,'\n\n/*ADC_Neutral_Voltage \t\t DISABLED*/');  
% end
fprintf(fid3,'\n\n#define ADC_OUTPUT_VOLTAGE\t\t\t\t %s',ADC_Output_Voltage);
fprintf(fid3,'\n\n#define ADC_OUTPUT_OVER_VOLTAGE\t\t\t\t %s',Output_Over_V_prot);
fprintf(fid3,'\n\n#define CMP_DAC_DATA\t\t\t\t %s',DAC_Data);
% fprintf(fid3,'\n\n#define CMP_ZCD1\t\t\t\t %s',ZCD1);
% fprintf(fid3,'\n\n#define CMP_ZCD2\t\t\t\t %s',ZCD2);
fprintf(fid3,'\n\n#define RELAY_GPIO_PORT\t\t\t\t %s',Relay_Drive);
fprintf(fid3,'\n\n#define RELAY_GPIO_PORTNUM\t\t\t\t %s',Relay_Drive_Port);
fprintf(fid3,'\n\n#define GPIO 1\t\t\t\t %s',GPIO1);
fprintf(fid3,'\n\n#define GPIO1_PORT\t\t\t\t %s',GPIO1_Port);
fprintf(fid3,'\n\n#define GPIO 2\t\t\t\t %s',GPIO2);
fprintf(fid3,'\n\n#define GPIO2_PORT\t\t\t\t %s',GPIO2_Port);
fprintf(fid3,'\n\n#define GPIO 3\t\t\t\t %s',GPIO3);
fprintf(fid3,'\n\n#define GPIO3_PORT\t\t\t\t %s',GPIO3_Port);

%% IPT5
if handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value ==1
    fprintf(fid3,'\n\n\n/*Comment: Protections Configuration Parameters */\n\n\n #define MAINS_UNDERVOLTAGE_FAULT\t\t ENABLED');
    fprintf(fid3,'\n\n#define MAINS_UV_FLT_THRESHOLD_CNTS\t\t %s \n\n#define MAINS_UV_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define MAINS_UV_FLT_CNT_THRESHOLD\t\t %s\n\n#define MAINS_UV_FLT_CNT_HYSLIMIT\t\t %s',IPUnderVoltageLimit,IPUnderVoltageHys,IPUnderVoltageFaultenable,IPUnderVoltageFaultdisable);
end

if handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value==1
fprintf(fid3,'\n\n\n #define MAINS_OVERVOLTAGE_FAULT\t\t ENABLED');
fprintf(fid3,'\n#define MAINS_OV_FLT_THRESHOLD_CNTS\t\t %s \n\n#define MAINS_OV_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define MAINS_OV_FLT_CNT_THRESHOLD\t\t %s\n\n#define MAINS_OV_FLT_CNT_HYSLIMIT\t\t %s',IPOverVoltageLimit,IPOverVoltageHys,IPoverVoltageFaultenable,IPoverVoltageFaultdisable);
end

if handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value==1
fprintf(fid3,'\n\n\n #define OUTPUT_UNDERVOLTAGE_FAULT\t\t ENABLED');
fprintf(fid3,'\n #define OUTPUT_UV_FLT_THRESHOLD_CNTS\t %s \n\n#define OUTPUT_UV_FLT_HYSLIMIT_CNTS\t\t %s',OPUnderVoltageLimit,OPUnderVoltageFaultenable);
end

if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value==1
    fprintf(fid3,'\n\n\n #define OUTPUT_OVERVOLTAGE_FAULT\t\t ENABLED');
fprintf(fid3,'\n#define OUTPUT_OV_FLT_THRESHOLD_CNTS\t %s \n\n#define OUTPUT_OV_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define OUTPUT_OV_FLT_CNT_THRESHOLD\t\t %s\n\n#define OUTPUT_OV_FLT_CNT_HYSLIMIT\t\t %s',OPOverVoltageLimit,OPOverVoltageHys,OPOverVoltageFaultenable,OPOverVoltageFaultdisable);
end

if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
    fprintf(fid3,'\n\n\n #define OVER_CURRENT_FAULT\t\t ENABLED');
fprintf(fid3,'\n#define OUTPUT_OC_FLT_THRESHOLD_CNTS\t %s \n\n#define OUTPUT_OC_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define OUTPUT_OC_FLT_CNT_THRESHOLD\t\t %s\n\n#define OUTPUT_OC_FLT_CNT_HYSLIMIT\t\t %s',OPOverPowerLimit,OPOverPowerLimitHys,OPOverPowerFaultEnable,OPOverPowerLimitFaultDisable);
end

% if handles.IPT5.FeaturesConfig.OverTemperatureLimit.Value==1
%     fprintf(fid3,'\n\n #define OVER_TEMP_FAULT\t\t ENABLED');
% fprintf(fid3,'\n\n\n#define OVERTEMP_FLT_THRESHOLD_CNTS\t\t %s \n\n#define OVERTEMP_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define OVERTEMP_FLT_CNT_THRESHOLD\t\t %s\n\n#define OVERTEMP_FLT_CNT_HYSLIMIT\t\t %s',OverTemperatureLimit,OverTemperatureLimitHys,OverTemperatureLimitFaultEnable,OverTemperatureLimitFaultdisable);
% end

if handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value==1
    fprintf(fid3,'\n\n\n #define UNDER_FREQ_FAULT\t\t ENABLED');
fprintf(fid3,'\n#define UNDER_FREQ_FLT_THRESHOLD_CNTS\t\t %s \n\n#define UNDER_FREQ_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define UNDER_FREQ_FLT_CNT_THRESHOLD\t\t %s\n\n#define UNDER_FREQ_FLT_CNT_HYSLIMIT\t\t %s',LineUnderFrequencyLimit,LineUnderFreqHys,LineUnderFreqfaultenable,LineUnderFreqFaultdisable);
end

if handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value==1
    fprintf(fid3,'\n\n\n #define OVER_FREQ_FAULT\t\t ENABLED');
fprintf(fid3,'\n#define OVR_FREQ_FLT_THRESHOLD_CNTS\t\t %s \n\n#define OVR_FREQ_FLT_HYSLIMIT_CNTS\t\t %s\n\n#define OVR_FREQ_FLT_CNT_THRESHOLD\t\t %s\n\n#define OVR_FREQ_FLT_CNT_HYSLIMIT\t\t %s',LineOverFrequencyLimit,LineOverFrequencyHys,LineOverFrequencyLimitFaultenable,LineOverFrequencyLimitfaultdisable);
end
if handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value==1
fprintf(fid3,'\n\n\n#define RELAY_TURNON_THRESHOLD_CNTS\t\t %s \n\n#define RELAY_HYSLIMIT_CNTS\t\t\t\t %s\n\n#define RELAY_FLT_CNT_THRESHOLD\t\t\t %s\n\n#define RELAY_FLT_CNT_HYSLIMIT\t\t\t %s',RelayTurnONLimit,RelayTurnONLimitHys,RelayTurnONLimitfaultenable,RelayTurnONLimitFaultdisable);
end
if handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value==1
    fprintf(fid3,'\n\n #define GENERIC_FLT1_THRESHOLD_CNTS\t\t ENABLED');
fprintf(fid3,'\n\n\n#define GENERIC_FLT1_THRESHOLD_CNTS\t\t %s \n\n#define GENERIC_FLT1_HYSLIMIT_CNTS\t\t %s\n\n#define GENERIC_FLT1_CNT_THRESHOLD\t\t %s\n\n#define GENERIC_FLT1_CNT_HYSLIMIT\t\t %s',GenericParameter1Limit,GenericParameter1LimitHys,GenericParameter1FaultEnable,GenericParameter1FaultDisable);
end
if handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value==1
    fprintf(fid3,'\n\n #define GENERIC_FLT2_THRESHOLD_CNTS\t\t ENABLED');
fprintf(fid3,'\n\n\n#define GENERIC_FLT2_THRESHOLD_CNTS\t\t %s \n\n#define GENERIC_FLT2_HYSLIMIT_CNTS\t\t %s\n\n#define GENERIC_FLT2_CNT_THRESHOLD\t\t %s\n\n#define GENERIC_FLT2_CNT_HYSLIMIT\t\t %s',GenericParameter2Limit,GenericParameter2LimitHys,GenericParameter2LimitFaultEnable,GenericParameter2LimitFaultDisable);
end
%% IPT6
% fprintf(fid3,'\n\n\n\n/*Comment: Features Configuration */\n\n#define SOFT_START_DURATION_LIMIT\t\t %s \n\n#define SOFT_START_CALLRATE\t\t\t\t %s\n\n#define BURST_MODE_ENABLE_LIMIT\t\t\t %s\n\n#define BURST_MODE_DISABLE_LIMIT\t\t %s\n\n#define PWM_DITHERING_LIMIT\t\t\t\t %s',SoftStartDurationLimit,SoftStartCallRate,BurstModeEnableLimit,BurstModeDisableLimit,PWMDitheringLimit);
if handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value ==1
    fprintf(fid3,'\n\n#define SOFT_START_DURATION\t\t %s',SoftStartDurationLimit);
% end
% if handles.IPT6.FeaturesConfiguration.SoftStartCallRate.Value ==1
fprintf(fid3,'\n\n#define SOFT_START_CALLRATE\t\t %s',SoftStartCallRate);
end

if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
fprintf(fid3,'\n\n #define BURST_MODE\t\t ENABLED');
fprintf(fid3,'\n\n#define BURST_MODE_EN_THRESHOLD\t\t %s',BurstModeEnableLimit);
fprintf(fid3,'\n\n BURSTMODE_ENABLE_WATTS \t\t %s',BurstModeEnableLimitWatts);

% if handles.IPT6.FeaturesConfiguration.BurstModeDisableLimit.Value==1
fprintf(fid3,'\n\n#define BURST_MODE_DIS_THRESHOLD\t\t %s',BurstModeDisableLimit);
end
if handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value==1
fprintf(fid3,'\n\n #define PWM_DITHERING\t\t ENABLED');
fprintf(fid3,'\n\n#define MAX_DITHER_FACTOR\t\t %s',num2str(MaxDitherFactor));
fprintf(fid3,'\n\n#define MIN_DITHER_FACTOR\t\t %s',num2str(MinDitherFactor));
fprintf(fid3,'\n\n#define DITHER_SCALEFACTOR\t\t %s',num2str(DitherScaleFactor));
end
fprintf(fid3,'\n\n#define DCM_CORRECTION_FACTOR\t\t %s',DCMCorrectionTextBox);
if handles.IPT6.FeaturesConfiguration.PhaseShedding.Value==1
fprintf(fid3,'\n\n #define PHASE_SHEDDING\t\t ENABLED');
fprintf(fid3,'\n\n#define PHASE_SHEDDING\t\t %s',PhaseSheddingIPFCTextBox);
fprintf(fid3,'\n\n#define PHASE_SHEDDING_WATTS\t\t %s',PhaseSheddingIPFCTextBoxWatts);
% if handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value==1
fprintf(fid3,'\n\n#define HYS_PHASE_SHEDDING\t\t %s',HysPhaseSheddingIPFCTextBox);
fprintf(fid3,'\n\n#define HYS_PHASE_SHEDDING_WATTS\t\t %s',HysPhaseSheddingIPFCTextBoxWatts);
end
%% closing of Protections header file
fclose(fid3);
%%
%%  Coefficients header file
%%
% pathName = cd;
% fileName = 'Coefficients.h';
% file_path = fullfile(pathName,fileName);
% fid1 = fopen(file_path, 'wt');

[fileName,pathName] = uiputfile2('Coefficients.h');
file_path = fullfile(pathName,fileName);
fid1 = fopen(file_path, 'wt');


%% GPT3
fprintf(fid1,'/*********************************************************************************************************');
fprintf(fid1,'\n� 2018 Microchip Technology Inc and its subsidiaries.\n\nSubject to your compliance with these terms, you may use Microchip software and any \nderivatives exclusively with Microchip products. It is your responsibility to comply with third party \nlicense terms applicable to your use of third party software (including open source software) that \nmay accompany Microchip software.\n\n');
fprintf(fid1,'THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER \nEXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY \nIMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS \nFOR A PARTICULAR PURPOSE. \n\n');
fprintf(fid1,'IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,\nINCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND \nWHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP \nHAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO \nTHE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP`S TOTAL LIABILITY ON ALL \nCLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT \nOF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.\n\n ');       
fprintf(fid1,'*********************************************************************************************************/\n');

if ILCompensatorSel==2
    fprintf(fid1,'\n\n/*********************************************************************************************************');
    fprintf(fid1,'\n\n*****Comment: Continious Time Domain Inner Loop Controller Parameters *****\n\n#define INNER_LOOP_COMPENSATOR\t\t%s\n\n#define IL_GAIN_Kdc   \t\t\t\t%d\n\n#define IL_POLE1\t\t\t\t\t%d \n\n#define IL_POLE2\t\t\t\t\t%d\n\n#define IL_ZERO1\t\t\t\t\t%d \n\n#define IL_ZERO2\t\t\t\t\t%d\n\n\n*****Comment: Continious Time Domain Inner Loop Cascaded Controller Parameters*****\n\n#define IL_CASCADED_POLE1\t\t\t %s \n\n#define IL_CASCADED_ZERO1\t\t\t %s\n\n#define IL_CASCADED_Kdc1\t\t\t %s\n\n#define IL_CASCADED_POLE2\t\t\t %s\n\n#define IL_CASCADED_ZERO2\t\t\t %s\n\n#define IL_CASCADED_Kdc2\t\t\t %s\n\n#define IL_CASCADED_POLE3\t\t\t %s\n\n#define IL_CASCADED_ZERO3\t\t\t %s\n\n#define IL_CASCADED_Kdc3\t\t\t %s\n',ILCompensator,ILGainh,ILPole1h,ILPole2h,ILZero1h,ILZero2h,ILP1_cascaded,ILZ1_cascaded,ILKdc1_cascaded,ILP2_cascaded,ILZ2_cascaded,ILKdc2_cascaded,ILP3_cascaded,ILZ3_cascaded,ILKdc3_cascaded);
    
elseif ILCompensatorSel==1
    fprintf(fid1,'\n\n/*********************************************************************************************************');
    fprintf(fid1,'\n\n*****Comment: Continious Time Domain Inner Loop Controller Parameters *****\n\n#define INNER_LOOP_COMPENSATOR\t\t%s\n\n#define IL_GAIN_Kdc   \t\t\t\t%d\n\n#define IL_POLE1\t\t\t\t\t%d \n\n#define IL_ZERO1\t\t\t\t\t%d \n\n\n*****Comment: Continious Time Domain Inner Loop Cascaded Controller Parameters*****\n\n#define IL_CASCADED_POLE1\t\t\t %s \n\n#define IL_CASCADED_ZERO1\t\t\t %s\n\n#define IL_CASCADED_Kdc1\t\t\t %s\n\n#define IL_CASCADED_POLE2\t\t\t %s\n\n#define IL_CASCADED_ZERO2\t\t\t %s\n\n#define IL_CASCADED_Kdc2\t\t\t %s\n\n#define IL_CASCADED_POLE3\t\t\t %s\n\n#define IL_CASCADED_ZERO3\t\t\t %s\n\n#define IL_CASCADED_Kdc3\t\t\t %s\n',ILCompensator,ILGainh,ILPole1h,ILZero1h,ILP1_cascaded,ILZ1_cascaded,ILKdc1_cascaded,ILP2_cascaded,ILZ2_cascaded,ILKdc2_cascaded,ILP3_cascaded,ILZ3_cascaded,ILKdc3_cascaded);
end
% % fprintf(fid1,'\n*********************************************************************************************************/');
% 
% fprintf(fid1,'/*********************************************************************************************************');

if OLCompensatorSel==2
    fprintf(fid1,'\n\n\n\n*****Comment: Continious Time Domain Outer Loop Controller Parameters*****\n\n\n#define OUTER_LOOP_COMPENSATOR\t\t %s\n\n#define OL_GAIN_Kdc\t\t\t\t\t %d\n\n#define OL_POLE1\t\t\t\t\t %d \n\n#define OL_POLE2\t\t\t %d \n\n#define OL_ZERO1\t\t\t\t\t %d \n\n#define OL_ZERO2\t\t\t %d\n\n\n*****Comment: Continious Time Domain Outer Loop Cascaded Controller Parameters*****\n\n#define OL_CASCADED_POLE1\t\t\t %s \n\n#define OL_CASCADED_ZERO1\t\t\t %s\n\n#define OL_CASCADED_Kdc1\t\t\t %s\n\n#define OL_CASCADED_POLE2\t\t\t %s\n\n#define OL_CASCADED_ZERO2\t\t\t %s\n\n#define OL_CASCADED_Kdc2\t\t\t %s\n\n#define OL_CASCADED_POLE3\t\t\t %s\n\n#define OL_CASCADED_ZERO3\t\t\t %s\n\n#define OL_CASCADED_Kdc3\t\t\t %s\n',OLCompensator,OLGainh,OLPole1h,OLPole2h,OLZero1h,OLZero2h,OLP1_cascaded,OLZ1_cascaded,OLKdc1_cascaded,OLP2_cascaded,OLZ2_cascaded,OLKdc2_cascaded,OLP3_cascaded,OLZ3_cascaded,OLKdc3_cascaded);
    fprintf(fid1,'********************************************************************************************************/');
elseif OLCompensatorSel==1
    fprintf(fid1,'\n\n\n\n*****Comment: Continious Time Domain Outer Loop Controller Parameters*****\n\n\n#define OUTER_LOOP_COMPENSATOR\t\t %s\n\n#define OL_GAIN_Kdc\t\t\t\t\t %d\n\n#define OL_POLE1\t\t\t\t\t %d \n\n#define OL_ZERO1\t\t\t\t\t %d\n\n\n*****Comment: Continious Time Domain Outer Loop Cascaded Controller Parameters*****\n\n#define OL_CASCADED_POLE1\t\t\t %s \n\n#define OL_CASCADED_ZERO1\t\t\t %s\n\n#define OL_CASCADED_Kdc1\t\t\t %s\n\n#define OL_CASCADED_POLE2\t\t\t %s\n\n#define OL_CASCADED_ZERO2\t\t\t %s\n\n#define OL_CASCADED_Kdc2\t\t\t %s\n\n#define OL_CASCADED_POLE3\t\t\t %s\n\n#define OL_CASCADED_ZERO3\t\t\t %s\n\n#define OL_CASCADED_Kdc3\t\t\t %s\n',OLCompensator,OLGainh,OLPole1h,OLZero1h,OLP1_cascaded,OLZ1_cascaded,OLKdc1_cascaded,OLP2_cascaded,OLZ2_cascaded,OLKdc2_cascaded,OLP3_cascaded,OLZ3_cascaded,OLKdc3_cascaded);
    fprintf(fid1,'*********************************************************************************************************/');
end

fprintf(fid1,'\n\n/*********************************************************************************************************');
fprintf(fid1,'\n\n\n\n*****Comment: Inner Loop Digital Absolute coefficients*****\n\n#define IL_ABSOLUTE_COEFFICIENT_A1\t\t %s \n\n#define IL_ABSOLUTE_COEFFICIENT_A2\t\t %s\n\n#define IL_ABSOLUTE_COEFFICIENT_A3\t\t %s\n\n#define IL_ABSOLUTE_COEFFICIENT_A4\t\t %s',A1_Abs_IL_H,A2_Abs_IL_H,A3_Abs_IL_H,A4_Abs_IL_H);
fprintf(fid1,'\n\n#define IL_ABSOLUTE_COEFFICIENT_B0\t\t %s \n\n#define IL_ABSOLUTE_COEFFICIENT_B1\t\t %s\n\n#define IL_ABSOLUTE_COEFFICIENT_B2\t\t %s\n\n#define IL_ABSOLUTE_COEFFICIENT_B3\t\t %s\n\n#define IL_ABSOLUTE_COEFFICIENT_B4\t\t %s',B0_Abs_IL_H,B1_Abs_IL_H,B2_Abs_IL_H,B3_Abs_IL_H,B4_Abs_IL_H);
fprintf(fid1,'\n\n\n*****Comment: Inner Loop Digital Normalized coefficients*****\n\n#define IL_NORMALIZED_COEFFICIENT_A1\t\t %s \n\n#define IL_NORMALIZED_COEFFICIENT_A2\t\t %s\n\n#define IL_NORMALIZED_COEFFICIENT_A3\t\t %s \n\n#define IL_NORMALIZED_COEFFICIENT_A4\t\t %s',A1_Norm_IL_H,A2_Norm_IL_H,A3_Norm_IL_H,A4_Norm_IL_H);
fprintf(fid1,'\n\n#define IL_NORMALIZED_COEFFICIENT_B0\t\t %s \n\n#define IL_NORMALIZED_COEFFICIENT_B1\t\t %s\n\n#define IL_NORMALIZED_COEFFICIENT_B2\t\t %s\n\n#define IL_NORMALIZED_COEFFICIENT_B3\t\t %s\n\n#define IL_NORMALIZED_COEFFICIENT_B4\t\t %s',B0_Norm_IL_H,B1_Norm_IL_H,B2_Norm_IL_H,B3_Norm_IL_H,B4_Norm_IL_H);
fprintf(fid1,'\n\n#define IL_NORMALIZED_NORMAL\t\t\t\t %s \n\n#define IL_NORMALIZED_POSTSHIFT\t\t\t\t %s\n\n#define IL_NORMALIZED_POSTSCALAR\t\t\t %s',IL_Norm_Normal,IL_Norm_PostShift,IL_Norm_PostScalar);
fprintf(fid1,'\n\n*********************************************************************************************************/');

fprintf(fid1,'\n\n\n/*Comment: Inner Loop Digital Cascaded coefficients*/\n\n#define IL_CASCADED_COEFFICIENT_A11\t\t\t %s \n\n#define IL_CASCADED_COEFFICIENT_B10\t\t\t %s\n\n#define IL_CASCADED_COEFFICIENT_B11\t\t\t %s\n\n#define IL_CASCADED_COEFFICIENT_POSTSHIFT\t %s',A11_IL_C,B10_IL_C,B11_IL_C,PS_IL_C);
fprintf(fid1,'\n\n\n#define IL_CASCADED_COEFFICIENT_A21\t\t\t %s \n\n#define IL_CASCADED_COEFFICIENT_B20\t\t\t %s\n\n#define IL_CASCADED_COEFFICIENT_B21\t\t\t %s',A21_IL_C,B20_IL_C,B21_IL_C);
fprintf(fid1,'\n\n\n#define IL_CASCADED_COEFFICIENT_A31\t\t\t %s \n\n#define IL_CASCADED_COEFFICIENT_B30\t\t\t %s\n\n#define IL_CASCADED_COEFFICIENT_B31\t\t\t %s',A31_IL_C,B30_IL_C,B31_IL_C);

fprintf(fid1,'\n\n\n\n/*********************************************************************************************************');
fprintf(fid1,'\n\n*****Comment: Outer Loop Digital Absolute Coefficients*****\n\n#define OL_ABSOLUTE_COEFFICIENT_A1\t\t %s \n\n#define OL_ABSOLUTE_COEFFICIENT_A2\t\t %s\n\n#define OL_ABSOLUTE_COEFFICIENT_A3\t\t %s\n\n#define OL_ABSOLUTE_COEFFICIENT_A4\t\t %s',A1_Abs_OL_H,A2_Abs_OL_H,A3_Abs_OL_H,A4_Abs_OL_H);
fprintf(fid1,'\n\n#define OL_ABSOLUTE_COEFFICIENT_B0\t\t %s \n\n#define OL_ABSOLUTE_COEFFICIENT_B1\t\t %s\n\n#define OL_ABSOLUTE_COEFFICIENT_B2\t\t %s\n\n#define OL_ABSOLUTE_COEFFICIENT_B3\t\t %s\n\n#define OL_ABSOLUTE_COEFFICIENT_B4\t\t %s',B0_Abs_OL_H,B1_Abs_OL_H,B2_Abs_OL_H,B3_Abs_OL_H,B4_Abs_OL_H);
fprintf(fid1,'\n\n\n\n*****Comment: Outer Loop Digital Normalized Coefficients*****\n\n#define OL_NORMALIZED_COEFFICIENT_A1\t\t %s \n\n#define OL_NORMALIZED_COEFFICIENT_A2\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_A3\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_A3\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_A4\t\t %s',A1_Norm_OL_H,A2_Norm_OL_H,A3_Norm_OL_H,A4_Norm_OL_H,B4_Abs_OL_H);
fprintf(fid1,'\n\n#define OL_NORMALIZED_COEFFICIENT_B0\t\t %s \n\n#define OL_NORMALIZED_COEFFICIENT_B1\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_B2\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_B3\t\t %s\n\n#define OL_NORMALIZED_COEFFICIENT_B4\t\t %s',B0_Norm_OL_H,B1_Norm_OL_H,B2_Norm_OL_H,B3_Norm_OL_H,B4_Norm_OL_H);
fprintf(fid1,'\n\n#define OL_NORMALIZED_NORMAL\t\t\t\t %s \n\n#define OL_NORMALIZED_POSTSHIFT\t\t\t\t %s\n\n#define OL_NORMALIZED_POSTSCALAR\t\t\t %s',OL_Norm_Normal,OL_Norm_PostShift,OL_Norm_PostScalar);
fprintf(fid1,'\n\n*********************************************************************************************************/');

fprintf(fid1,'\n\n\n/*Comment: Outer Loop Digital Cascaded Coefficients*/\n\n#define OL_CASCADED_COEFFICIENT_A11\t\t\t %s \n\n#define OL_CASCADED_COEFFICIENT_B10\t\t\t %s\n\n#define OL_CASCADED_COEFFICIENT_B11\t\t\t %s\n\n#define OL_CASCADED_COEFFICIENT_POSTSHIFT\t %s',A11_OL_C,B10_OL_C,B11_OL_C,PS_OL_C);
fprintf(fid1,'\n\n\n#define OL_CASCADED_COEFFICIENT_A21\t\t\t %s \n\n#define OL_CASCADED_COEFFICIENT_B20\t\t\t %s\n\n#define OL_CASCADED_COEFFICIENT_B21\t\t\t %s',A21_OL_C,B20_OL_C,B21_OL_C);
fprintf(fid1,'\n\n\n#define OL_CASCADED_COEFFICIENT_A31\t\t\t %s \n\n#define OL_CASCADED_COEFFICIENT_B30\t\t\t %s\n\n#define OL_CASCADED_COEFFICIENT_B31\t\t\t %s',A31_OL_C,B30_OL_C,B31_OL_C);

%% Closing of Coefficients header file

fclose(fid1);

%% Saving Multiple files
% coln = size(fileName,2);
% numberfile = coln;
% for i = 1:numberfile
%     fileName(i);
%    file_path = fullfile(pathName,fileName{i});
%     fid = fopen(file_path,'wt');
%     fclose(fid);
% 
% end
% coln = size(fileName,2);
% numberfile = coln;
% for i = 1:numberfile
%     if i == 1;
%     file_path = fullfile(pathName,fileName);
%     fid1 = fopen(file_path,'wt');
%     fclose(fid1);
%     if i ==2;
%         fid3 = fopen(file_path,'wt');
%     fclose(fid3);    
%     end
%     end
% 
% end

%%
%%
%% *.xml file generation
%%
% weblink: https://in.mathworks.com/help/matlab/ref/xmlwrite.html
% Creating an XML File--- https://in.mathworks.com/help/matlab/import_export/exporting-to-xml-documents.html#bsmnj5u
%%
docNode = com.mathworks.xml.XMLUtils.createDocument('PowerSmart_Project_Details');
docRootNode = docNode.getDocumentElement;
% https://in.mathworks.com/help/matlab/ref/xmlwrite.html
% new_comment = docNode.createComment('This is a comment inserted by ramesh');
% docNode.appendChild(new_comment);
% docNode.appendChild(docNode.createComment('this is a comment'));

nodeRev = docNode.createElement('key'); 
docRootNode.appendChild(nodeRev);
nodeRev.setAttribute('name','VERSION');
nodeRev.setAttribute('value','0.1');

% nodeComment1 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment1);
% nodeComment1.setAttribute('name','Comment: Specifications');

nodeProject = docNode.createElement('key'); 
docRootNode.appendChild(nodeProject);
nodeProject.setAttribute('name','PROJECT_NAME');
nodeProject.setAttribute('value',ProjName);

nodedate = docNode.createElement('key'); 
docRootNode.appendChild(nodedate );
nodedate.setAttribute('name','DATE-TIME');
nodedate.setAttribute('value',strcat(date) );

% nodePowerStage = docNode.createElement('key'); 
% docRootNode.appendChild(nodePowerStage);
% nodePowerStage.setAttribute('name','Comment: Selected Topology and Control Method');
%% IPT4 device and clock selection
nodeDeviceSelection = docNode.createElement('key'); 
docRootNode.appendChild(nodeDeviceSelection );
nodeDeviceSelection.setAttribute('name','Device Selection');
nodeDeviceSelection.setAttribute('value',DeviceSel );

nodeDeviceClock = docNode.createElement('key'); 
docRootNode.appendChild(nodeDeviceClock );
nodeDeviceClock.setAttribute('name','DEVICE_CLOCK');
nodeDeviceClock.setAttribute('value',strcat(DeviceClock,' MHz') );

%% IPT1
if(TopologySel == 1)
    nodeTopology = docNode.createElement('key');
    docRootNode.appendChild(nodeTopology);
    nodeTopology.setAttribute('name','CHOSEN TOPOLOGY');
    nodeTopology.setAttribute('value','SINGLE_PHASE');
elseif (TopologySel == 2)
    nodeTopology = docNode.createElement('key');
    docRootNode.appendChild(nodeTopology);
    nodeTopology.setAttribute('name','CHOSEN TOPOLOGY');
    nodeTopology.setAttribute('value','INTERLEAVED');
    
elseif (TopologySel == 3)
    nodeTopology = docNode.createElement('key');
    docRootNode.appendChild(nodeTopology);
    nodeTopology.setAttribute('name','CHOSEN TOPOLOGY');
    nodeTopology.setAttribute('value','BRIDGELESS');
end

nodeControlMethod = docNode.createElement('key');
docRootNode.appendChild(nodeControlMethod);
nodeControlMethod.setAttribute('name','CONTROL METHOD');
nodeControlMethod.setAttribute('value','CONT_COND_MODE');

if handles.dsPICDSCTab.ADC_PFCCurrentEnable.BLPFCCurrent.Value==1
    nodeADC_PFC_IndCurrSense  = docNode.createElement('key');
    docRootNode.appendChild(nodeADC_PFC_IndCurrSense );
    nodeADC_PFC_IndCurrSense.setAttribute('name','IND_CURR_SENSE');
    nodeADC_PFC_IndCurrSense.setAttribute('value','DISABLED');
else
    nodeADC_PFC_IndCurrSense  = docNode.createElement('key');
    docRootNode.appendChild(nodeADC_PFC_IndCurrSense );
    nodeADC_PFC_IndCurrSense.setAttribute('name','IND_CURR_SENSE');
    nodeADC_PFC_IndCurrSense.setAttribute('value','ENABLED');
end

%% IPT2 Current measurement network selection
if CurrentMeas_sel==1    % Current measurement Current Transformer
    
    nodeCurrentMeasNWSelec  = docNode.createElement('key');
    docRootNode.appendChild(nodeCurrentMeasNWSelec);
    nodeCurrentMeasNWSelec.setAttribute('name','CURR_MEAS_NETWORK');
    nodeCurrentMeasNWSelec.setAttribute('value','CURRENT_TRANSFORMER');
else
    nodeCurrentMeasNWSelec  = docNode.createElement('key');
    docRootNode.appendChild(nodeCurrentMeasNWSelec);
    nodeCurrentMeasNWSelec.setAttribute('name','CURR_MEAS_NETWORK');
    nodeCurrentMeasNWSelec.setAttribute('value','SHUNT_RESISTOR');
end


% 
% if handles.dsPICDSCTab.ADC_PFCCurrentEnable.ADCNeutralVoltageRadio.Value==1    
%     nodeADC_Neutral_Voltage  = docNode.createElement('key'); 
%     docRootNode.appendChild(nodeADC_Neutral_Voltage );
%     nodeADC_Neutral_Voltage.setAttribute('name','IND_VOLT_SENSE');
%     nodeADC_Neutral_Voltage.setAttribute('value','ENABLED');
% else    
%     nodeADC_Neutral_Voltage  = docNode.createElement('key'); 
%     docRootNode.appendChild(nodeADC_Neutral_Voltage );
%     nodeADC_Neutral_Voltage.setAttribute('name','ADC_Neutral_Voltage');
%     nodeADC_Neutral_Voltage.setAttribute('value','DISABLED');
% end
%% PWM Parallel FET Enable
 if handles.IPT6.FeaturesConfiguration.PFETControl.Value == 1;
     nodePWM_Enable = docNode.createElement('key');
     docRootNode.appendChild(nodePWM_Enable );
     nodePWM_Enable.setAttribute('name','PFET_GPIO');
     nodePWM_Enable.setAttribute('value','ENABLED');     
 else 
     nodePWM_Enable = docNode.createElement('key');
     docRootNode.appendChild(nodePWM_Enable );
     nodePWM_Enable.setAttribute('name','PFET_GPIO');
     nodePWM_Enable.setAttribute('value','DISABLED');
 end
%% AutomaticRestartEnable 
if handles.IPT6.FeaturesConfiguration.AutomaticRestartEnable.Value == 1;

    nodeAutomaticRestartE = docNode.createElement('key'); % AutomaticRestart Enable
    docRootNode.appendChild(nodeAutomaticRestartE );
    nodeAutomaticRestartE.setAttribute('name','AUTOMATIC_RESTART');
    nodeAutomaticRestartE.setAttribute('value','ENABLED');

else
    nodeAutomaticRestartE = docNode.createElement('key'); % AutomaticRestart Disable
    docRootNode.appendChild(nodeAutomaticRestartE );
    nodeAutomaticRestartE.setAttribute('name','AUTOMATIC_RESTART');
    nodeAutomaticRestartE.setAttribute('value','DISABLED');
end

%% If different Line/Neutral Voltage sense Feedback, this option can be enabled to properly balance the two legs
% if handles.dsPICDSCTab.ADC_PFCCurrentEnable.ADCNeutralVoltageRadio.Value==1    
nodeMainsLineScaling  = docNode.createElement('key'); 
docRootNode.appendChild(nodeMainsLineScaling );
nodeMainsLineScaling.setAttribute('name','MAINSLINESCALING');
nodeMainsLineScaling.setAttribute('value','ENABLED');
% end

%% Mains UV Fault enable 
if handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value == 1
    nodeIPUnderVoltageLimitE = docNode.createElement('key'); % nodeIPUnderVoltageLimitE, here 'E' - fault radio butom selected.
    docRootNode.appendChild(nodeIPUnderVoltageLimitE );
    nodeIPUnderVoltageLimitE.setAttribute('name','MAINS_UNDERVOLTAGE_FAULT');
    nodeIPUnderVoltageLimitE.setAttribute('value','ENABLED');
else
    nodeIPUnderVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeIPUnderVoltageLimitE );
    nodeIPUnderVoltageLimitE.setAttribute('name','MAINS_UNDERVOLTAGE_FAULT');
    nodeIPUnderVoltageLimitE.setAttribute('value','DISABLED');
end
%% mains Over Voltage protection
if handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value==1
    nodeIPOverVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeIPOverVoltageLimitE );
    nodeIPOverVoltageLimitE.setAttribute('name','MAINS_OVERVOLTAGE_FAULT');
    nodeIPOverVoltageLimitE.setAttribute('value','ENABLED');
else
    nodeIPOverVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeIPOverVoltageLimitE );
    nodeIPOverVoltageLimitE.setAttribute('name','MAINS_OVERVOLTAGE_FAULT');
    nodeIPOverVoltageLimitE.setAttribute('value','DISABLED');
end
%% O/P U/V Fault
if handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value==1
    nodeOPUnderVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPUnderVoltageLimitE );
    nodeOPUnderVoltageLimitE.setAttribute('name','OUTPUT_UNDERVOLTAGE_FAULT');
    nodeOPUnderVoltageLimitE.setAttribute('value','ENABLED');
else
    nodeOPUnderVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPUnderVoltageLimitE );
    nodeOPUnderVoltageLimitE.setAttribute('name','OUTPUT_UNDERVOLTAGE_FAULT');
    nodeOPUnderVoltageLimitE.setAttribute('value','DISABLED');
end
%% O/P O/V Fault
if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value==1
    nodeOPOverVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPOverVoltageLimitE);
    nodeOPOverVoltageLimitE.setAttribute('name','OUTPUT_OVERVOLTAGE_FAULT');
    nodeOPOverVoltageLimitE.setAttribute('value','ENABLED');
else
    nodeOPOverVoltageLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPOverVoltageLimitE);
    nodeOPOverVoltageLimitE.setAttribute('name','OUTPUT_OVERVOLTAGE_FAULT');
    nodeOPOverVoltageLimitE.setAttribute('value','DISABLED');
end

%% Over Power Fault  ,  this point of time the text in the 
if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
    nodeOPOverPowerLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPOverPowerLimitE);
    nodeOPOverPowerLimitE.setAttribute('name','OVER_POWER_FAULT');
    nodeOPOverPowerLimitE.setAttribute('value','ENABLED');
else
    nodeOPOverPowerLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeOPOverPowerLimitE);
    nodeOPOverPowerLimitE.setAttribute('name','OVER_POWER_FAULT');
    nodeOPOverPowerLimitE.setAttribute('value','DISABLED');
end

%% Line Under Frequency Limit
if handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value==1
    nodeLineUnderFrequencyLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeLineUnderFrequencyLimitE);
    nodeLineUnderFrequencyLimitE.setAttribute('name','UNDER_FREQ_FAULT');
    nodeLineUnderFrequencyLimitE.setAttribute('value','ENABLED');
else
    nodeLineUnderFrequencyLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeLineUnderFrequencyLimitE);
    nodeLineUnderFrequencyLimitE.setAttribute('name','UNDER_FREQ_FAULT');
    nodeLineUnderFrequencyLimitE.setAttribute('value','DISABLED');
end
%% Line Over Frequency Limit
if handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value==1
    nodeLineOverFrequencyLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeLineOverFrequencyLimitE);
    nodeLineOverFrequencyLimitE.setAttribute('name','OVER_FREQ_FAULT');
    nodeLineOverFrequencyLimitE.setAttribute('value','ENABLED');
else
    nodeLineOverFrequencyLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeLineOverFrequencyLimitE);
    nodeLineOverFrequencyLimitE.setAttribute('name','OVER_FREQ_FAULT');
    nodeLineOverFrequencyLimitE.setAttribute('value','DISABLED');
end

%% Debug GPIO feature Enable

nodeGPIO_Debug_Enable = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO_Debug_Enable );
nodeGPIO_Debug_Enable.setAttribute('name','DEBUG_GPIO');
nodeGPIO_Debug_Enable.setAttribute('value','ENABLED');

%% Generic fault1 enable
if handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value==1
    nodeGenericParameter1LimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeGenericParameter1LimitE);
    nodeGenericParameter1LimitE.setAttribute('name','GENERIC_FLT1');
    nodeGenericParameter1LimitE.setAttribute('value','ENABLED');    
else
    nodeGenericParameter1LimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeGenericParameter1LimitE);
    nodeGenericParameter1LimitE.setAttribute('name','GENERIC_FLT1');
    nodeGenericParameter1LimitE.setAttribute('value','DISABLED');
end

if handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value==1

    nodeGenericParameter2LimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeGenericParameter2LimitE);
    nodeGenericParameter2LimitE.setAttribute('name','GENERIC_FLT2');
    nodeGenericParameter2LimitE.setAttribute('value','ENABLED');
else
    nodeGenericParameter2LimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeGenericParameter2LimitE);
    nodeGenericParameter2LimitE.setAttribute('name','GENERIC_FLT2');
    nodeGenericParameter2LimitE.setAttribute('value','DISABLED');
end

%% PWM Dithering
if handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value==1
    nodePWMDitheringLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodePWMDitheringLimitE );
    nodePWMDitheringLimitE.setAttribute('name','PWM_DITHERING');
    nodePWMDitheringLimitE.setAttribute('value','ENABLED');
else
    nodePWMDitheringLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodePWMDitheringLimitE );
    nodePWMDitheringLimitE.setAttribute('name','PWM_DITHERING');
    nodePWMDitheringLimitE.setAttribute('value','DISABLED');
end

%% Burst Mode Enable Limit
if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
    nodeBurstModeDisableLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeBurstModeDisableLimitE);
    nodeBurstModeDisableLimitE.setAttribute('name','BURST_MODE');
    nodeBurstModeDisableLimitE.setAttribute('value','ENABLED');
else
    nodeBurstModeDisableLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeBurstModeDisableLimitE);
    nodeBurstModeDisableLimitE.setAttribute('name','BURST_MODE');
    nodeBurstModeDisableLimitE.setAttribute('value','DISABLED');
end

%% DCM Correction factor
if handles.IPT6.FeaturesConfiguration.DCMCorrection.Value == 1;
    nodeDCMCorrectionTextBox = docNode.createElement('key');
    docRootNode.appendChild(nodeDCMCorrectionTextBox );
    nodeDCMCorrectionTextBox.setAttribute('name','DCM_CORRECTION_FACTOR');
    nodeDCMCorrectionTextBox.setAttribute('value','ENABLED');
else
    nodeDCMCorrectionTextBox = docNode.createElement('key');
    docRootNode.appendChild(nodeDCMCorrectionTextBox );
    nodeDCMCorrectionTextBox.setAttribute('name','DCM_CORRECTION_FACTOR');
    nodeDCMCorrectionTextBox.setAttribute('value','DISABLED');
end

%% Phase shedding
if handles.IPT6.FeaturesConfiguration.PhaseShedding.Value==1
    nodePhaseSheddingIPFCTextBoxE = docNode.createElement('key');
    docRootNode.appendChild(nodePhaseSheddingIPFCTextBoxE );
    nodePhaseSheddingIPFCTextBoxE.setAttribute('name','PHASE_SHEDDING');
    nodePhaseSheddingIPFCTextBoxE.setAttribute('value','ENABLED');
else
    nodePhaseSheddingIPFCTextBoxE = docNode.createElement('key');
    docRootNode.appendChild(nodePhaseSheddingIPFCTextBoxE );
    nodePhaseSheddingIPFCTextBoxE.setAttribute('name','PHASE_SHEDDING');
    nodePhaseSheddingIPFCTextBoxE.setAttribute('value','DISABLED');
end
%% X capacitor compensation
if handles.IPT6.FeaturesConfiguration.XCapCompensation.Value == 1;
    nodeBurstModeDisableLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeBurstModeDisableLimitE);
    nodeBurstModeDisableLimitE.setAttribute('name','XCAP_COMPENSATION');
    nodeBurstModeDisableLimitE.setAttribute('value','ENABLED');
else
    nodeBurstModeDisableLimitE = docNode.createElement('key');
    docRootNode.appendChild(nodeBurstModeDisableLimitE);
    nodeBurstModeDisableLimitE.setAttribute('name','XCAP_COMPENSATION');
    nodeBurstModeDisableLimitE.setAttribute('value','DISABLED');
end

%% Scaler based on K6 derivation, depending on final control system design (Vpk2 or Vrms2), this term may need to add 1 (x2). This left shift
% scaler is calculated as rounddown(log2(KADC*Kvin*Kiin/Kvout)) + 1
nodeVcompScaler = docNode.createElement('key'); 
docRootNode.appendChild(nodeVcompScaler );
nodeVcompScaler.setAttribute('name','VCOMPSCALER');
nodeVcompScaler.setAttribute('value',num2str(Vcompscaler));
%% Part of frequency fault , Scaler = roundup (log2(PWM_PERIOD),0) , Period should be taken as lowest switching frequency
nodeZcrossScaler = docNode.createElement('key'); 
docRootNode.appendChild(nodeZcrossScaler );
nodeZcrossScaler.setAttribute('name','ZEROCROSSSCALER');
nodeZcrossScaler.setAttribute('value',num2str(ZeroCrossScaler));

%% PWM selection Implementation 1

% if PWM_GENx_H_Val==1 && PWM_GENx_L_Val==1
%     
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWM_GENERATOR_X');
% nodePWMGeneratorx.setAttribute('value',PWM_GENx );
%     
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxH');
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxL');
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% end
% 
% if PWM_GENx_H_Val==1 && PWM_GENy_H_Val==1
%   
switch PWM_GENx_Val
    case 1
        nodePWMGeneratorx = docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratorx );
        nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
        nodePWMGeneratorx.setAttribute('value','PWM Channel Not Selected');
    
    case 2      %PWM1H
        nodePWMGeneratorx = docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratorx );
        nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
        nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-1));
    
        nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
        docRootNode.appendChild(nodePWMGeneratorxHL );
        nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
        nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
    case 3      %PWM1L
        nodePWMGeneratorx = docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratorx );
        nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
        nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-2));
        
        nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
        docRootNode.appendChild(nodePWMGeneratorxHL );
        nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
        nodePWMGeneratorxHL.setAttribute('value','ENABLED');
    
   case 4       %PWM2H
       nodePWMGeneratorx = docNode.createElement('key');
       docRootNode.appendChild(nodePWMGeneratorx );
       nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
       nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-2));
       
       nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
       docRootNode.appendChild(nodePWMGeneratorxHL );
       nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
       nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
  case 5       %PWM2L     
      nodePWMGeneratorx = docNode.createElement('key');
      docRootNode.appendChild(nodePWMGeneratorx );
      nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
      nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-3));
      
      nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
      docRootNode.appendChild(nodePWMGeneratorxHL );
      nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
      nodePWMGeneratorxHL.setAttribute('value','ENABLED');
    
     case 6         %PWM3H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-3));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 7         %PWM3L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-4)); 
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED');
         
    case 8          %PWM4H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-4));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 9         %PWM4L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-5));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED');
         
    case 10             %PWM5H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-5));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 11            %PWM5L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-6));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED');
         
    case 12         %PWM6H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-6));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 13        %PWM6L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-7));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED');     
         
    case 14         %PWM7H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-7));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 15        %PWM7L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-8));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED'); 
         
    case 16         %PWM8H
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-8));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','DISABLED');
    
     case 17        %PWM8L
         nodePWMGeneratorx = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratorx );
         nodePWMGeneratorx.setAttribute('name','PWM_PH1_DRV_CH');
         nodePWMGeneratorx.setAttribute('value',num2str(PWM_GENx_Val-9));
         
         nodePWMGeneratorxHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratorxHL );
         nodePWMGeneratorxHL.setAttribute('name','PWM_PH1_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratorxHL.setAttribute('value','ENABLED');      
end  

%% PWMy choces

switch PWM_GENy_Val
    case 1
        nodePWMGeneratory= docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratory );
        node PWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
        node PWMGeneratory.setAttribute('value','PWM Channel Not Selected');
    
    case 2      %PWM1H
        nodePWMGeneratory = docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratory );
        nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
        nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-1));
    
        nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
        docRootNode.appendChild(nodePWMGeneratoryHL );
        nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
        nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
    case 3      %PWM1L
        nodePWMGeneratory = docNode.createElement('key');
        docRootNode.appendChild(nodePWMGeneratory );
        nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
        nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-2));
        
        nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
        docRootNode.appendChild(nodePWMGeneratoryHL );
        nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
        nodePWMGeneratoryHL.setAttribute('value','ENABLED');
    
   case 4       %PWM2H
       nodePWMGeneratory = docNode.createElement('key');
       docRootNode.appendChild(nodePWMGeneratory );
       nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
       nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-2));
       
       nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
       docRootNode.appendChild(nodePWMGeneratoryHL );
       nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
       nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
  case 5       %PWM2L     
      nodePWMGeneratory = docNode.createElement('key');
      docRootNode.appendChild(nodePWMGeneratory );
      nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
      nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-3));
      
      nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
      docRootNode.appendChild(nodePWMGeneratoryHL );
      nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
      nodePWMGeneratoryHL.setAttribute('value','ENABLED');
    
     case 6         %PWM3H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-3));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 7         %PWM3L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-4)); 
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED');
         
    case 8          %PWM4H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-4));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 9         %PWM4L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-5));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED');
         
    case 10             %PWM5H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-5));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 11            %PWM5L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-6));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED');
         
    case 12         %PWM6H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-6));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 13        %PWM6L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-7));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED');     
         
    case 14         %PWM7H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-7));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 15        %PWM7L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-8));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED'); 
         
    case 16         %PWM8H
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-8));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','DISABLED');
    
     case 17        %PWM8L
         nodePWMGeneratory = docNode.createElement('key');
         docRootNode.appendChild(nodePWMGeneratory );
         nodePWMGeneratory.setAttribute('name','PWM_PH2_DRV_CH');
         nodePWMGeneratory.setAttribute('value',num2str(PWM_GENy_Val-9));
         
         nodePWMGeneratoryHL = docNode.createElement('key');  % HL, High / Low side selection
         docRootNode.appendChild(nodePWMGeneratoryHL );
         nodePWMGeneratoryHL.setAttribute('name','PWM_PH2_CH_LOW'); % PWM Channel selection Disable - high side drive
         nodePWMGeneratoryHL.setAttribute('value','ENABLED');      
end  

% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWM_GENERATOR_Q1/Q2');
% nodePWMGeneratorx.setAttribute('value',PWM_GENx );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxH');
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxL');
% nodePWMGeneratorx.setAttribute('value','UNSET' );
%    
% nodePWMGeneratory = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratory );
% nodePWMGeneratory.setAttribute('name','PWM_GENERATOR_Q3/Q4');
% nodePWMGeneratory.setAttribute('value',PWM_GENy);
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxH');
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name','PWMxL');
% nodePWMGeneratorx.setAttribute('value','UNSET' );
%     
% end



%% Implementation 2

% if PWM_GENx_H_Val==1 && PWM_GENx_L_Val==1
%     
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name',strcat(PWM_GENx,'H'));
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name',strcat(PWM_GENx,'L'));
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% end
% 
% if PWM_GENx_H_Val==1 && PWM_GENy_H_Val==1
%     
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name',strcat(PWM_GENx,'H'));
% nodePWMGeneratorx.setAttribute('value','SET' );
% 
% nodePWMGeneratorx = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratorx );
% nodePWMGeneratorx.setAttribute('name',strcat(PWM_GENx,'L'));
% nodePWMGeneratorx.setAttribute('value','UNSET' );
% 
% nodePWMGeneratory = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMGeneratory );
% nodePWMGeneratory.setAttribute('name',strcat(PWM_GENy,'H'));
% nodePWMGeneratory.setAttribute('value','SET' );
% 
% % nodePWMGeneratory = docNode.createElement('key'); 
% % docRootNode.appendChild(nodePWMGeneratory );
% % nodePWMGeneratory.setAttribute('name',strcat(PWM_GENy,'H'));
% % nodePWMGeneratory.setAttribute('value','UNSET' );  
%     
% end

%% Current Sense channel selection
if handles.dsPICDSCTab.ADC_PFCCurrentEnable.BLPFCCurrent.Value==1

% nodeADC_PFC_IndCurrSense  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeADC_PFC_IndCurrSense );
% nodeADC_PFC_IndCurrSense.setAttribute('name','IND_CURR_SENSE');
% nodeADC_PFC_IndCurrSense.setAttribute('value','DISABLED');    
    
nodeADC_PFC_current = docNode.createElement('key'); 
docRootNode.appendChild(nodeADC_PFC_current );
nodeADC_PFC_current.setAttribute('name','IPH1_SENSE_CH');
nodeADC_PFC_current.setAttribute('value',ADC_PFC_I );

else    
% nodeADC_PFC_IndCurrSense  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeADC_PFC_IndCurrSense );
% nodeADC_PFC_IndCurrSense.setAttribute('name','IND_CURR_SENSE');
% nodeADC_PFC_IndCurrSense.setAttribute('value','ENABLED');
    
nodeADC_PFC_current1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeADC_PFC_current1 );
nodeADC_PFC_current1.setAttribute('name','IPH1_SENSE_CH');
nodeADC_PFC_current1.setAttribute('value',ADC_PFC_I1 );

nodeADC_PFC_current2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeADC_PFC_current2 );
nodeADC_PFC_current2.setAttribute('name','IPH2_SENSE_CH');
nodeADC_PFC_current2.setAttribute('value',ADC_PFC_I2 );
end
%% Line Voltage Sensing channel selection
nodeADCLineVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCLineVoltage );
nodeADCLineVoltage.setAttribute('name','VAC_LINE_SENSE_CH');
nodeADCLineVoltage.setAttribute('value',ADC_Line_Voltage );

%% NeutralVoltage Sensing channel selection
% if handles.dsPICDSCTab.ADC_PFCCurrentEnable.ADCNeutralVoltageRadio.Value==1
    
% nodeADC_Neutral_Voltage  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeADC_Neutral_Voltage );
% nodeADC_Neutral_Voltage.setAttribute('name','IND_VOLT_SENSE');
% nodeADC_Neutral_Voltage.setAttribute('value','ENABLED');
    
nodeADCNeutralVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCNeutralVoltage );
nodeADCNeutralVoltage.setAttribute('name','VAC_NEUTRAL_SENSE_CH');
nodeADCNeutralVoltage.setAttribute('value',ADC_Neutral_Voltage );

% else     
    % nodeADC_Neutral_Voltage  = docNode.createElement('key'); 
    % docRootNode.appendChild(nodeADC_Neutral_Voltage );
    % nodeADC_Neutral_Voltage.setAttribute('name','ADC_Neutral_Voltage');
    % nodeADC_Neutral_Voltage.setAttribute('value','DISABLED');

% end
%% Output Voltage Channel selection
nodeADCOutputVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCOutputVoltage );
nodeADCOutputVoltage.setAttribute('name','VOUT_SENSE_CH');
nodeADCOutputVoltage.setAttribute('value',ADC_Output_Voltage );

%% Output Over Voltage Latched fault channel selection (A-D -> 0-3) ,CMPx (1-4)
if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value == 1
 
    switch Output_Over_V_prot_Val
        case 1
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','OutputOVP ACMP not selected');
            
        case 2
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-1));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','0' );
            
        case 3
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-2));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','1' );
            
        case 4
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-3));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','2' );
        case 5
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-4));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','3' );            
          
        case 6
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-4));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','0' );
            
        case 7
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-5));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','1' );
            
        case 8
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-6));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','2' );
        case 9
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-7));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','3' );
            
            
            
        case 10
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-7));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','0' );
            
        case 11
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-8));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','1' );
            
        case 12
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-9));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','2' );
        case 13
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-10));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','3' );
            
         case 14
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-10));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','0' );
            
        case 15
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-11));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','1' );
            
        case 16
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-12));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','2' );
        case 17
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_CH');
            nodeOutputOverVoltProtection.setAttribute('value',num2str(Output_Over_V_prot_Val-13));
            
            nodeOutputOverVoltProtection = docNode.createElement('key');
            docRootNode.appendChild(nodeOutputOverVoltProtection );
            nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
            nodeOutputOverVoltProtection.setAttribute('value','3' );           
            
    end           
            
    
%     nodeOutputOverVoltProtection = docNode.createElement('key');
%     docRootNode.appendChild(nodeOutputOverVoltProtection );
%     nodeOutputOverVoltProtection.setAttribute('name','LATCH_FLT_CMP_INSEL');
%     nodeOutputOverVoltProtection.setAttribute('value',Output_Over_V_prot_Val );
    
    nodeDACdata = docNode.createElement('key');
    docRootNode.appendChild(nodeDACdata );
    nodeDACdata.setAttribute('name','LATCH_FLT_DAC_THRESHOLD_CNTS');
    nodeDACdata.setAttribute('value',strcat(DAC_Data) );
end

%% PWM Parallel FET Enable
if handles.IPT6.FeaturesConfiguration.PFETControl.Value == 1;
% nodePWM_Enable = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWM_Enable );
% nodePWM_Enable.setAttribute('name','PFET_GPIO');
% nodePWM_Enable.setAttribute('value','ENABLED');

nodePWM_Enable_Port = docNode.createElement('key'); 
docRootNode.appendChild(nodePWM_Enable_Port );
nodePWM_Enable_Port.setAttribute('name','PFET_GPIO_PORT');
nodePWM_Enable_Port.setAttribute('value',PWM_Enable);

nodePWM_Enable_PinName = docNode.createElement('key'); 
docRootNode.appendChild(nodePWM_Enable_PinName);
nodePWM_Enable_PinName.setAttribute('name','PFET_GPIO_PORTNUM');
nodePWM_Enable_PinName.setAttribute('value',PWM_Enable_PinName);
end
%% Relay GPIO Selection
nodeRelayDrive = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayDrive );
nodeRelayDrive.setAttribute('name','RELAY_GPIO_PORT');
nodeRelayDrive.setAttribute('value',Relay_Drive );

nodeRelayDrivePort = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayDrivePort );
nodeRelayDrivePort.setAttribute('name','RELAY_GPIO_PORTNUM');
nodeRelayDrivePort.setAttribute('value',Relay_Drive_Port );

%% GPIO1 referenced as POWER_ON_GPIO
nodeGPIO1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO1 );
nodeGPIO1.setAttribute('name','POWER_ON_GPIO_PORT');
nodeGPIO1.setAttribute('value',GPIO1 );

nodeGPIO1Port = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO1Port );
nodeGPIO1Port.setAttribute('name','POWER_ON_GPIO_PORTNUM');
nodeGPIO1Port.setAttribute('value',GPIO1_Port );

%% GPIO2 referenced as FAULT_GPIO_GPIO
nodeGPIO2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO2 );
nodeGPIO2.setAttribute('name','FAULT_GPIO_PORT');
nodeGPIO2.setAttribute('value',GPIO2 );

nodeGPIO2Port = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO2Port );
nodeGPIO2Port.setAttribute('name','FAULT_GPIO_PORTNUM');
nodeGPIO2Port.setAttribute('value',GPIO2_Port );

%% GPIO3 referenced as DEBUG_GPIO_PORT 

nodeGPIO3 = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO3 );
nodeGPIO3.setAttribute('name','DEBUG_GPIO_PORT ');
nodeGPIO3.setAttribute('value',GPIO3 );

nodeGPIO3Port = docNode.createElement('key'); 
docRootNode.appendChild(nodeGPIO3Port );
nodeGPIO3Port.setAttribute('name','DEBUG_GPIO_PORTNUM');
nodeGPIO3Port.setAttribute('value',GPIO3_Port );
%%  PWM Switching period counts
nodeILPTPER = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPTPER);
nodeILPTPER.setAttribute('name','PWM_SW_PERIOD');
nodeILPTPER.setAttribute('value',strcat(ILPTPER,'u'));

%% PWM resolution based on the device
if (DeviceSelVal==0)||(DeviceSelVal==1)||(DeviceSelVal==2)||(DeviceSelVal==3)||(DeviceSelVal==4)||(DeviceSelVal==5)||(DeviceSelVal==6)||(DeviceSelVal==7)||(DeviceSelVal==8)||(DeviceSelVal==9)||(DeviceSelVal==10)||(DeviceSelVal==11)||(DeviceSelVal==12)||(DeviceSelVal==13)||(DeviceSelVal==14)

    nodePWM_Res1 = docNode.createElement('key'); 
    docRootNode.appendChild(nodePWM_Res1 );
    nodePWM_Res1.setAttribute('name','PWM_RESOLUTION');
    nodePWM_Res1.setAttribute('value',strcat(PWM_Res1,'u'));
%     nodePWM_Res1.setAttribute('value',strcat(PWM_Res1,' nsec'));

% else
    % nodePWM_Res2 = docNode.createElement('key'); 
    % docRootNode.appendChild(nodePWM_Res2 );
    % nodePWM_Res2.setAttribute('name','PWM_RESOLUTION');
    % nodePWM_Res2.setAttribute('value',PWM_Res2);
end

%% Inner Loop Sampling ration and Frequency
nodeILPWMSamplingRatio = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPWMSamplingRatio);
nodeILPWMSamplingRatio.setAttribute('name','I_SAMPLERATE');
nodeILPWMSamplingRatio.setAttribute('value',strcat(num2str(ILSampRatioP),'u'));

% nodeILPWMSamplingFreq = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILPWMSamplingFreq);
% nodeILPWMSamplingFreq.setAttribute('name','I_SAMPLERATE');
% nodeILPWMSamplingFreq.setAttribute('value',strcat(ILPWMSampFreq, ' kHz'));

%% Outer Loop Sampling Frequency
nodeOLPWMSamplingFreq = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPWMSamplingFreq);
nodeOLPWMSamplingFreq.setAttribute('name','V_SAMPLERATE');
nodeOLPWMSamplingFreq.setAttribute('value',strcat(num2str(OLPWMSampFreqP),'u')); % freq in Hz

%% Input Voltage measurement sampling ratio and frequency 
nodeInputVoltageSampRatio = docNode.createElement('key'); 
docRootNode.appendChild(nodeInputVoltageSampRatio);
nodeInputVoltageSampRatio.setAttribute('name','CURR_REF_ISR_TRGCNT');
nodeInputVoltageSampRatio.setAttribute('value',strcat(num2str(OLSampRatioP),'u'));

% nodeInputVoltageSampFreq = docNode.createElement('key'); 
% docRootNode.appendChild(nodeInputVoltageSampFreq);
% nodeInputVoltageSampFreq.setAttribute('name','CURR_REF_ISR_TRGCNT');
% nodeInputVoltageSampFreq.setAttribute('value',strcat(InputVoltageSampFreq, ' kHz'));

%% output voltage reference 
nodeOutPutVoltRefC = docNode.createElement('key'); 
docRootNode.appendChild(nodeOutPutVoltRefC);
nodeOutPutVoltRefC.setAttribute('name','VOLTAGE_REFERENCE');
nodeOutPutVoltRefC.setAttribute('value',strcat(num2str(OutPutVoltRefC),'u'));

%% Phanthom trigger reference 
offset = 400;
PWM_Res1C = round(str2double(PWM_Res1));
PhanthomTrigOffset = offset / 2^(PWM_Res1C);
nodeOutPutVoltRefC = docNode.createElement('key'); 
docRootNode.appendChild(nodeOutPutVoltRefC);
nodeOutPutVoltRefC.setAttribute('name','PHANTHOM_TRIG_OFFSET');
nodeOutPutVoltRefC.setAttribute('value',num2str(PhanthomTrigOffset));
% nodeOutPutVoltRefC.setAttribute('value',strcat(num2str(OutPutVoltRefC)));

%% Gate driver delay
nodeILGateDriveDelay = docNode.createElement('key'); 
docRootNode.appendChild(nodeILGateDriveDelay);
nodeILGateDriveDelay.setAttribute('name','GATE_DRV_DELAY');
nodeILGateDriveDelay.setAttribute('value',strcat(ILGateDriveDelay,'u'));
% nodeILGateDriveDelay.setAttribute('value',strcat(ILGateDriveDelay, ' nsec'));

%% AUTOMATIC_RESTART config print
if handles.IPT6.FeaturesConfiguration.AutomaticRestartEnable.Value == 1;

% nodeAutomaticRestartE = docNode.createElement('key'); % AutomaticRestart Enable
% docRootNode.appendChild(nodeAutomaticRestartE );
% nodeAutomaticRestartE.setAttribute('name','AUTOMATIC_RESTART');
% nodeAutomaticRestartE.setAttribute('value','ENABLED');   

nodeMaxRestartAttempts = docNode.createElement('key'); 
docRootNode.appendChild(nodeMaxRestartAttempts);
nodeMaxRestartAttempts.setAttribute('name','MAX_RESTART_ATTEMPTS');
nodeMaxRestartAttempts.setAttribute('value',strcat(MaxRestartAttempts, 'u'));

nodeSystemOperational = docNode.createElement('key'); 
docRootNode.appendChild(nodeSystemOperational);
nodeSystemOperational.setAttribute('name','SYSTEM_OPERATIONAL');
nodeSystemOperational.setAttribute('value',strcat(SystemOperational, 'u'));

nodeSystemRestartTime = docNode.createElement('key'); 
docRootNode.appendChild(nodeSystemRestartTime);
nodeSystemRestartTime.setAttribute('name','SYSTEM_RESTART_TIME');
nodeSystemRestartTime.setAttribute('value',strcat(SystemRestartTime, 'ul'));

end
%% Input U/V Fault configuration
if handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value == 1    
% nodeIPUnderVoltageLimitE = docNode.createElement('key'); % nodeIPUnderVoltageLimitE, here 'E' - fault radio butom selected.
% docRootNode.appendChild(nodeIPUnderVoltageLimitE );
% nodeIPUnderVoltageLimitE.setAttribute('name','MAINS_UNDERVOLTAGE_FAULT');
% nodeIPUnderVoltageLimitE.setAttribute('value','ENABLED');    

nodeIPUnderVoltageLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPUnderVoltageLimit );
nodeIPUnderVoltageLimit.setAttribute('name','MAINS_UV_FLT_THRESHOLD_CNTS');
nodeIPUnderVoltageLimit.setAttribute('value',num2str(IPUVLimitCounts));

nodeIPUnderVoltageHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPUnderVoltageHys );
nodeIPUnderVoltageHys.setAttribute('name','MAINS_UV_FLT_HYSLIMIT_CNTS');
nodeIPUnderVoltageHys.setAttribute('value',num2str(IPUVHysCounts));

nodeIPUnderVoltageFaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPUnderVoltageFaultenable );
nodeIPUnderVoltageFaultenable.setAttribute('name','MAINS_UV_FLT_CNT_THRESHOLD');
nodeIPUnderVoltageFaultenable.setAttribute('value',strcat(IPUnderVoltageFaultenable));

nodeIPUnderVoltageFaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPUnderVoltageFaultdisable );
nodeIPUnderVoltageFaultdisable.setAttribute('name','MAINS_UV_FLT_CNT_HYSLIMIT');
nodeIPUnderVoltageFaultdisable.setAttribute('value',strcat(IPUnderVoltageFaultdisable));
end

%% mains Over Voltage protection
if handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value==1
    
% nodeIPOverVoltageLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeIPOverVoltageLimitE );
% nodeIPOverVoltageLimitE.setAttribute('name','MAINS_OVERVOLTAGE_FAULT');
% nodeIPOverVoltageLimitE.setAttribute('value','ENABLED');    

nodeIPOverVoltageLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPOverVoltageLimit );
nodeIPOverVoltageLimit.setAttribute('name','MAINS_OV_FLT_THRESHOLD_CNTS');
nodeIPOverVoltageLimit.setAttribute('value',num2str(IPOVLimitCounts));
    
nodeIPOverVoltageHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPOverVoltageHys );
nodeIPOverVoltageHys.setAttribute('name','MAINS_OV_FLT_HYSLIMIT_CNTS');
nodeIPOverVoltageHys.setAttribute('value',num2str(IPOVHysCounts));

nodeIPoverVoltageFaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPoverVoltageFaultenable );
nodeIPoverVoltageFaultenable.setAttribute('name','MAINS_OV_FLT_CNT_THRESHOLD');
nodeIPoverVoltageFaultenable.setAttribute('value',strcat(IPoverVoltageFaultenable));

nodeIPoverVoltageFaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeIPoverVoltageFaultdisable );
nodeIPoverVoltageFaultdisable.setAttribute('name','MAINS_OV_FLT_CNT_HYSLIMIT');
nodeIPoverVoltageFaultdisable.setAttribute('value',strcat(IPoverVoltageFaultdisable));
end

%% O/P U/V Fault
if handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value==1

% nodeOPUnderVoltageLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPUnderVoltageLimitE );
% nodeOPUnderVoltageLimitE.setAttribute('name','OUTPUT_UNDERVOLTAGE_FAULT');
% nodeOPUnderVoltageLimitE.setAttribute('value','ENABLED');
    
nodeOPUnderVoltageLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPUnderVoltageLimit );
nodeOPUnderVoltageLimit.setAttribute('name','OUTPUT_UV_FLT_THRESHOLD_CNTS');
nodeOPUnderVoltageLimit.setAttribute('value',num2str(OPUVLimitCounts));

% nodeOPUnderVoltageHys = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPUnderVoltageHys );
% nodeOPUnderVoltageHys.setAttribute('name','OUTPUT_UV_FLT_HYSLIMIT_CNTS');
% nodeOPUnderVoltageHys.setAttribute('value',num2str(OPUVHysCounts));

nodeOPUnderVoltageFaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPUnderVoltageFaultenable );
nodeOPUnderVoltageFaultenable.setAttribute('name','OUTPUT_UV_FLT_CNT_THRESHOLD');
nodeOPUnderVoltageFaultenable.setAttribute('value',strcat(OPUnderVoltageFaultenable));
% 
% nodeOPUnderVoltageFaultdisable = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPUnderVoltageFaultdisable);
% nodeOPUnderVoltageFaultdisable.setAttribute('name','OUTPUT_UV_FLT_CNT_HYSLIMIT');
% nodeOPUnderVoltageFaultdisable.setAttribute('value',strcat(OPUnderVoltageFaultdisable));
end

%% O/P O/V Fault
if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value==1
% nodeOPOverVoltageLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverVoltageLimitE);
% nodeOPOverVoltageLimitE.setAttribute('name','OUTPUT_OVERVOLTAGE_FAULT');
% nodeOPOverVoltageLimitE.setAttribute('value','ENABLED');
    
nodeOPOverVoltageLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverVoltageLimit);
nodeOPOverVoltageLimit.setAttribute('name','OUTPUT_OV_FLT_THRESHOLD_CNTS');
nodeOPOverVoltageLimit.setAttribute('value',num2str(OPOVLimitCounts));

nodeOPOverVoltageHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverVoltageHys);
nodeOPOverVoltageHys.setAttribute('name','OUTPUT_OV_FLT_HYSLIMIT_CNTS');
nodeOPOverVoltageHys.setAttribute('value',num2str(OPOVHysCounts));

nodeOPOverVoltageFaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverVoltageFaultenable);
nodeOPOverVoltageFaultenable.setAttribute('name','OUTPUT_OV_FLT_CNT_THRESHOLD');
nodeOPOverVoltageFaultenable.setAttribute('value',strcat(OPOverVoltageFaultenable));

nodeOPOverVoltageFaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverVoltageFaultdisable);
nodeOPOverVoltageFaultdisable.setAttribute('name','OUTPUT_OV_FLT_CNT_HYSLIMIT');
nodeOPOverVoltageFaultdisable.setAttribute('value',strcat(OPOverVoltageFaultdisable));
end

%% Over Power Fault  ,  this point of time the text in the 
if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
    
% nodeOPOverPowerLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverPowerLimitE);
% nodeOPOverPowerLimitE.setAttribute('name','OVER_POWER_FAULT');
% nodeOPOverPowerLimitE.setAttribute('value','ENABLED');    
    
nodeOPOverPowerLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverPowerLimit);
nodeOPOverPowerLimit.setAttribute('name','OVR_POWER_FLT_THRESHOLD_CNTS');
nodeOPOverPowerLimit.setAttribute('value',strcat(num2str(OPOPLimitCounts),'d'));

nodeOPOverPowerLimitHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverPowerLimitHys);
nodeOPOverPowerLimitHys.setAttribute('name','OVR_POWER_FLT_HYSLIMIT_CNTS');
nodeOPOverPowerLimitHys.setAttribute('value',strcat(num2str(OPOPHysCounts),'d'));

nodeOPOverPowerFaultEnable  = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverPowerFaultEnable );
nodeOPOverPowerFaultEnable.setAttribute('name','OVR_POWER_FLT_CNT_THRESHOLD');
nodeOPOverPowerFaultEnable.setAttribute('value',strcat(OPOverPowerFaultEnable,'u'));

nodeOPOverPowerLimitFaultDisable  = docNode.createElement('key'); 
docRootNode.appendChild(nodeOPOverPowerLimitFaultDisable  );
nodeOPOverPowerLimitFaultDisable.setAttribute('name','OVR_POWER_FLT_CNT_HYSLIMIT');
nodeOPOverPowerLimitFaultDisable.setAttribute('value',strcat(OPOverPowerLimitFaultDisable,'u'));

end

%% Line Under Frequency Limit
if handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value==1
    
% nodeLineUnderFrequencyLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeLineUnderFrequencyLimitE);
% nodeLineUnderFrequencyLimitE.setAttribute('name','UNDER_FREQ_FAULT');
% nodeLineUnderFrequencyLimitE.setAttribute('value','ENABLED');
    
nodeLineUnderFrequencyLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineUnderFrequencyLimit);
nodeLineUnderFrequencyLimit.setAttribute('name','UNDER_FREQ_FLT_THRESHOLD_CNTS');
nodeLineUnderFrequencyLimit.setAttribute('value',num2str(IPUFLimitCounts));

nodeLineUnderFreqHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineUnderFreqHys);
nodeLineUnderFreqHys.setAttribute('name','UNDER_FREQ_FLT_HYSLIMIT_CNTS');
nodeLineUnderFreqHys.setAttribute('value',num2str(IPUFLimitHysCounts));

nodeLineUnderFreqfaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineUnderFreqfaultenable);
nodeLineUnderFreqfaultenable.setAttribute('name','UNDER_FREQ_FLT_CNT_THRESHOLD');
nodeLineUnderFreqfaultenable.setAttribute('value',strcat(LineUnderFreqfaultenable));

nodeLineUnderFreqFaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineUnderFreqFaultdisable);
nodeLineUnderFreqFaultdisable.setAttribute('name','UNDER_FREQ_FLT_CNT_HYSLIMIT');
nodeLineUnderFreqFaultdisable.setAttribute('value',strcat(LineUnderFreqFaultdisable));
end

%% Line Over Frequency Limit
if handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value==1
% nodeLineOverFrequencyLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeLineOverFrequencyLimitE);
% nodeLineOverFrequencyLimitE.setAttribute('name','OVER_FREQ_FAULT');
% nodeLineOverFrequencyLimitE.setAttribute('value','ENABLED');

nodeLineOverFrequencyLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineOverFrequencyLimit);
nodeLineOverFrequencyLimit.setAttribute('name','OVR_FREQ_FLT_THRESHOLD_CNTS');
nodeLineOverFrequencyLimit.setAttribute('value',num2str(IPOFLimitCounts));

nodeLineOverFrequencyHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineOverFrequencyHys);
nodeLineOverFrequencyHys.setAttribute('name','OVR_FREQ_FLT_HYSLIMIT_CNTS');
nodeLineOverFrequencyHys.setAttribute('value',num2str(IPOFLimitHysCounts));

nodeLineOverFrequencyLimitFaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineOverFrequencyLimitFaultenable);
nodeLineOverFrequencyLimitFaultenable.setAttribute('name','OVR_FREQ_FLT_CNT_THRESHOLD');
nodeLineOverFrequencyLimitFaultenable.setAttribute('value',strcat(LineOverFrequencyLimitFaultenable));

nodeLineOverFrequencyLimitfaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeLineOverFrequencyLimitfaultdisable);
nodeLineOverFrequencyLimitfaultdisable.setAttribute('name','OVR_FREQ_FLT_CNT_HYSLIMIT');
nodeLineOverFrequencyLimitfaultdisable.setAttribute('value',strcat(LineOverFrequencyLimitfaultdisable));
end

%% Relay Turn ON/OFF 
if handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value==1
nodeRelayTurnONLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayTurnONLimit);
nodeRelayTurnONLimit.setAttribute('name','RELAY_TURNON_THRESHOLD_CNTS');
nodeRelayTurnONLimit.setAttribute('value',strcat(RelayTurnONLimit));

nodeRelayTurnONLimitHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayTurnONLimitHys);
nodeRelayTurnONLimitHys.setAttribute('name','RELAY_HYSLIMIT_CNTS');
nodeRelayTurnONLimitHys.setAttribute('value',strcat(RelayTurnONLimitHys));

nodeRelayTurnONLimitfaultenable = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayTurnONLimitfaultenable);
nodeRelayTurnONLimitfaultenable.setAttribute('name','RELAY_FLT_CNT_THRESHOLD');
nodeRelayTurnONLimitfaultenable.setAttribute('value',strcat(RelayTurnONLimitfaultenable));

nodeRelayTurnONLimitFaultdisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeRelayTurnONLimitFaultdisable);
nodeRelayTurnONLimitFaultdisable.setAttribute('name','RELAY_FLT_CNT_HYSLIMIT');
nodeRelayTurnONLimitFaultdisable.setAttribute('value',strcat(RelayTurnONLimitFaultdisable));
end

%% Generic fault1 enable
if handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value==1
    
% nodeGenericParameter1LimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeGenericParameter1LimitE);
% nodeGenericParameter1LimitE.setAttribute('name','GENERIC_FLT1');
% nodeGenericParameter1LimitE.setAttribute('value','ENABLED');

nodeGenericParameter1Limit = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter1Limit);
nodeGenericParameter1Limit.setAttribute('name','GENERIC_FLT1_THRESHOLD_CNTS');
nodeGenericParameter1Limit.setAttribute('value',strcat(GenericParameter1Limit));

nodeGenericParameter1LimitHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter1LimitHys);
nodeGenericParameter1LimitHys.setAttribute('name','GENERIC_FLT1_HYSLIMIT_CNTS');
nodeGenericParameter1LimitHys.setAttribute('value',strcat(GenericParameter1LimitHys));

nodeGenericParameter1FaultEnable = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter1FaultEnable);
nodeGenericParameter1FaultEnable.setAttribute('name','GENERIC_FLT1_CNT_THRESHOLD');
nodeGenericParameter1FaultEnable.setAttribute('value',strcat(GenericParameter1FaultEnable));

nodeGenericParameter1FaultDisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter1FaultDisable);
nodeGenericParameter1FaultDisable.setAttribute('name','GENERIC_FLT1_CNT_HYSLIMIT');
nodeGenericParameter1FaultDisable.setAttribute('value',strcat(GenericParameter1FaultDisable));
end
%% Generic fault2 enable
if handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value==1

% nodeGenericParameter2LimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeGenericParameter2LimitE);
% nodeGenericParameter2LimitE.setAttribute('name','GENERIC_FLT2');
% nodeGenericParameter2LimitE.setAttribute('value','ENABLED');

nodeGenericParameter2Limit = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter2Limit);
nodeGenericParameter2Limit.setAttribute('name','GENERIC_FLT2_THRESHOLD_CNTS');
nodeGenericParameter2Limit.setAttribute('value',strcat(GenericParameter2Limit));

nodeGenericParameter2LimitHys = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter2LimitHys);
nodeGenericParameter2LimitHys.setAttribute('name','GENERIC_FLT2_HYSLIMIT_CNTS');
nodeGenericParameter2LimitHys.setAttribute('value',strcat(GenericParameter2LimitHys));

nodeGenericParameter2LimitFaultEnable = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter2LimitFaultEnable);
nodeGenericParameter2LimitFaultEnable.setAttribute('name','GENERIC_FLT2_CNT_THRESHOLD');
nodeGenericParameter2LimitFaultEnable.setAttribute('value',strcat(GenericParameter2LimitFaultEnable));

nodeGenericParameter2LimitFaultDisable = docNode.createElement('key'); 
docRootNode.appendChild(nodeGenericParameter2LimitFaultDisable);
nodeGenericParameter2LimitFaultDisable.setAttribute('name','GENERIC_FLT2_CNT_HYSLIMIT');
nodeGenericParameter2LimitFaultDisable.setAttribute('value',strcat(GenericParameter2LimitFaultDisable));
end

%% IPT6   Soft Start config

if handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value ==1 

nodeSoftStartDurationLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeSoftStartDurationLimit);
nodeSoftStartDurationLimit.setAttribute('name','SOFT_START_DURATION');
nodeSoftStartDurationLimit.setAttribute('value',strcat(num2str(SoftStartDurationLimitP),'ul')); % in mSec
% nodeSoftStartDurationLimit.setAttribute('value',strcat(SoftStartDurationLimit,' mSec'));
% end
% 
% if handles.IPT6.FeaturesConfiguration.SoftStartCallRate.Value ==1
nodeSoftStartCallRate = docNode.createElement('key'); 
docRootNode.appendChild(nodeSoftStartCallRate);
nodeSoftStartCallRate.setAttribute('name','SOFT_START_CALLRATE');
nodeSoftStartCallRate.setAttribute('value',strcat(num2str(SoftStartCallRateP),'ul'));
% nodeSoftStartCallRate.setAttribute('value',strcat(SoftStartCallRate,' msec'));%in mSec
end

%% Burst Mode Enable Limit
if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
    
% nodeBurstModeDisableLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeBurstModeDisableLimitE);
% nodeBurstModeDisableLimitE.setAttribute('name','BURST_MODE');
% nodeBurstModeDisableLimitE.setAttribute('value','ENABLED');    
    
nodeBurstModeDisableLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeBurstModeDisableLimit);
nodeBurstModeDisableLimit.setAttribute('name','BURST_MODE_EN_THRESHOLD');
nodeBurstModeDisableLimit.setAttribute('value',strcat(BurstModeEnableLimit));

nodeBurstModeEnableLimitWatts = docNode.createElement('key'); 
docRootNode.appendChild(nodeBurstModeEnableLimitWatts);
nodeBurstModeEnableLimitWatts.setAttribute('name','BURSTMODE_ENABLE_WATTS');
nodeBurstModeEnableLimitWatts.setAttribute('value',strcat(BurstModeEnableLimitWatts));

% if handles.IPT6.FeaturesConfiguration.BurstModeDisableLimit.Value==1
nodeBurstModeDisableLimit = docNode.createElement('key'); 
docRootNode.appendChild(nodeBurstModeDisableLimit);
nodeBurstModeDisableLimit.setAttribute('name','BURST_MODE_DIS_THRESHOLD');
nodeBurstModeDisableLimit.setAttribute('value',strcat(BurstModeDisableLimit));

nodeBurstModeOffCycles = docNode.createElement('key'); 
docRootNode.appendChild(nodeBurstModeOffCycles);
nodeBurstModeOffCycles.setAttribute('name','BURST_MODE_OFF_CYCLES');
nodeBurstModeOffCycles.setAttribute('value',strcat(BurstModeOffCycles));
end


%% PWM Dithering
if handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value==1
% nodePWMDitheringLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMDitheringLimitE );
% nodePWMDitheringLimitE.setAttribute('name','PWM_DITHERING');
% nodePWMDitheringLimitE.setAttribute('value','ENABLED');
    
nodePWMDitheringLimitMax = docNode.createElement('key'); 
docRootNode.appendChild(nodePWMDitheringLimitMax);
nodePWMDitheringLimitMax.setAttribute('name','MAX_DITHER_FACTOR');
nodePWMDitheringLimitMax.setAttribute('value',strcat(num2str(MaxDitherFactor),'u'));

nodePWMDitheringLimitMin = docNode.createElement('key'); 
docRootNode.appendChild(nodePWMDitheringLimitMin );
nodePWMDitheringLimitMin.setAttribute('name','MIN_DITHER_FACTOR');
nodePWMDitheringLimitMin.setAttribute('value',strcat(num2str(MinDitherFactor),'u'));

nodePWMDitherScaleFactor = docNode.createElement('key'); 
docRootNode.appendChild(nodePWMDitherScaleFactor );
nodePWMDitherScaleFactor.setAttribute('name','DITHER_SCALEFACTOR');
nodePWMDitherScaleFactor.setAttribute('value',strcat(num2str(DitherScaleFactor),'u'));
end

%%  X capacitor compensation
if handles.IPT6.FeaturesConfiguration.XCapCompensation.Value == 1;    
% nodeBurstModeDisableLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeBurstModeDisableLimitE);
% nodeBurstModeDisableLimitE.setAttribute('name','XCAP_COMPENSATION');
% nodeBurstModeDisableLimitE.setAttribute('value','ENABLED');    
    
nodeXcapFreqGain = docNode.createElement('key'); 
docRootNode.appendChild(nodeXcapFreqGain);
nodeXcapFreqGain.setAttribute('name','XCAP_FREQ_GAIN');
nodeXcapFreqGain.setAttribute('value',strcat(XCapFreqGain,'u'));

nodeXcapCurrentMaxCounts= docNode.createElement('key'); 
docRootNode.appendChild(nodeXcapCurrentMaxCounts);
nodeXcapCurrentMaxCounts.setAttribute('name','XCAP_CURR_MAX_CNTS');
nodeXcapCurrentMaxCounts.setAttribute('value',strcat(XCapCurrMaxCnts,'u'));

nodeXcapVacArray = docNode.createElement('key'); 
docRootNode.appendChild(nodeXcapVacArray);
nodeXcapVacArray.setAttribute('name','XCAP_VAC_ARRAY ');
nodeXcapVacArray.setAttribute('value',strcat(XCapVacArray,'u'));
end
%%
% nodeComment1 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment1);
% nodeComment1.setAttribute('name','Comment: User Entered Specifications');

nodeMinVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeMinVoltage );
nodeMinVoltage.setAttribute('name','INPUT_AC_VOLTAGE (Vin)');
nodeMinVoltage.setAttribute('value',strcat(MinVoltage, ' Vrms') );

nodeOutputVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeOutputVoltage );
nodeOutputVoltage.setAttribute('name','OUTPUT_DC_VOLTAGE (V0)');
nodeOutputVoltage.setAttribute('value',strcat(OutputVoltage, ' Vdc') );

nodeOutputPower = docNode.createElement('key'); 
docRootNode.appendChild(nodeOutputPower );
nodeOutputPower.setAttribute('name','OUTPUT_POWER (P0)');
nodeOutputPower.setAttribute('value',strcat(OutputPower, ' Watts') );

nodeInductance = docNode.createElement('key'); 
docRootNode.appendChild(nodeInductance );
nodeInductance.setAttribute('name','INDUCTANCE (L1=L2)');
nodeInductance.setAttribute('value',strcat(Inductance, ' uH') );

nodeDCR = docNode.createElement('key'); 
docRootNode.appendChild(nodeDCR );
nodeDCR.setAttribute('name','INDUCTOR_DCR');
nodeDCR.setAttribute('value',strcat(Inductor_DCR,' mOhm') );

nodeCapacitance = docNode.createElement('key'); 
docRootNode.appendChild(nodeCapacitance );
nodeCapacitance.setAttribute('name','CAPACITANCE (C0)');
nodeCapacitance.setAttribute('value',strcat(Capacitance, ' uF') );

nodeESR = docNode.createElement('key'); 
docRootNode.appendChild(nodeESR );
nodeESR.setAttribute('name','CAPACITOR_ESR');
nodeESR.setAttribute('value',strcat(Capacitor_ESR, ' mOhm') );

% nodeMaxVoltage = docNode.createElement('key'); 
% docRootNode.appendChild(nodeMaxVoltage );
% nodeMaxVoltage.setAttribute('name','MAX_INPUT_VOLTAGE');
% nodeMaxVoltage.setAttribute('value',strcat(MaxVoltage, ' Vrms') );

nodeEMIXCapacitor = docNode.createElement('key'); 
docRootNode.appendChild(nodeEMIXCapacitor );
nodeEMIXCapacitor.setAttribute('name','EMI_FILTER_X_CAPACITOR (XC1)');
nodeEMIXCapacitor.setAttribute('value',strcat(EMIXCapacitor, ' uF') );

if ~isempty(handles.SpecificationsTab.FilePath.BodeFilePath.String)

nodeFilePath = docNode.createElement('key'); 
docRootNode.appendChild(nodeFilePath );
nodeFilePath.setAttribute('name','IMPORT_USER_BODE_FILE_PATH');
nodeFilePath.setAttribute('value',strcat(FilePath) );

end

%% IPT2

% nodeComment2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment2);
% nodeComment2.setAttribute('name','Comment: User Entered Feedback Network Specifications');
% nodeFeedbackNetwork = docNode.createElement('key'); 
% docRootNode.appendChild(nodeFeedbackNetwork);
% nodeFeedbackNetwork.setAttribute('name','FEEDBACK_NETWORKK_VALUES');

nodeADCRes = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCRes );
nodeADCRes.setAttribute('name','ADC_RESOLUTION');
nodeADCRes.setAttribute('value',strcat(ADCRes, ' Bits' ) );

nodeADCVoltage = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCVoltage );
nodeADCVoltage.setAttribute('name','ADC_REF_VOLTAGE');
nodeADCVoltage.setAttribute('value',strcat(ADCVolt, ' Vdc' ));

nodeADCLatency = docNode.createElement('key'); 
docRootNode.appendChild(nodeADCLatency );
nodeADCLatency.setAttribute('name','ADC_CONVERSION_LATENCY');
nodeADCLatency.setAttribute('value',strcat(ADCLat, ' nsec') );
%% AC line voltage
nodeRfb1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb1 );
nodeRfb1.setAttribute('name','Rfb1');
nodeRfb1.setAttribute('value',strcat(Rfb1, ' kOhm') );

nodeRfb2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb2 );
nodeRfb2.setAttribute('name','Rfb2');
nodeRfb2.setAttribute('value',strcat(Rfb2, ' kOhm') );

nodeRfb3 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb3 );
nodeRfb3.setAttribute('name','Rfb3');
nodeRfb3.setAttribute('value',strcat(Rfb3, ' kOhm') );

nodeCfb1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb1);
nodeCfb1.setAttribute('name','Cfb1');
nodeCfb1.setAttribute('value',strcat(Cfb1, ' pF') );

nodeCfb2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb2 );
nodeCfb2.setAttribute('name','Cfb2');
nodeCfb2.setAttribute('value',strcat(Cfb2, ' pF') );

%% AC line voltage
nodeRfb1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb1 );
nodeRfb1.setAttribute('name','Rfb13');
nodeRfb1.setAttribute('value',strcat(Rfb13, ' kOhm') );

nodeRfb2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb2 );
nodeRfb2.setAttribute('name','Rfb14');
nodeRfb2.setAttribute('value',strcat(Rfb14, ' kOhm') );

nodeRfb3 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb3 );
nodeRfb3.setAttribute('name','Rfb15');
nodeRfb3.setAttribute('value',strcat(Rfb15, ' kOhm') );

nodeCfb1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb1);
nodeCfb1.setAttribute('name','Cfb8');
nodeCfb1.setAttribute('value',strcat(Cfb8, ' pF') );

nodeCfb2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb2 );
nodeCfb2.setAttribute('name','Cfb9');
nodeCfb2.setAttribute('value',strcat(Cfb9, ' pF') );

%% Output Voltage Measurement
nodeRfb4 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb4 );
nodeRfb4.setAttribute('name','Rfb4');
nodeRfb4.setAttribute('value',strcat(Rfb4, ' kOhm') );

nodeRfb5 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb5 );
nodeRfb5.setAttribute('name','Rfb5');
nodeRfb5.setAttribute('value',strcat(Rfb5, ' kOhm') );

nodeRfb6 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb6 );
nodeRfb6.setAttribute('name','Rfb6');
nodeRfb6.setAttribute('value',strcat(Rfb6, ' kOhm') );

nodeCfb3 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb3 );
nodeCfb3.setAttribute('name','Cfb3');
nodeCfb3.setAttribute('value',strcat(Cfb3, ' pF') );

nodeCfb4 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb4 );
nodeCfb4.setAttribute('name','Cfb4');
nodeCfb4.setAttribute('value',strcat(Cfb4, ' pF') );

if CurrentMeas_sel==1    % Current measurement Current Transformer

nodeRfb7 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb7 );
nodeRfb7.setAttribute('name','Rfb7');
nodeRfb7.setAttribute('value',strcat(Rfb7, ' kOhm') );

nodeRfb8 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb8 );
nodeRfb8.setAttribute('name','Rfb8');
nodeRfb8.setAttribute('value',strcat(Rfb8, ' kOhm') );

nodeCfb5 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb5 );
nodeCfb5.setAttribute('name','Cfb5');
nodeCfb5.setAttribute('value',strcat(Cfb5, ' pF') );

nodePrimaryTurnsRatioNp = docNode.createElement('key'); 
docRootNode.appendChild(nodePrimaryTurnsRatioNp );
nodePrimaryTurnsRatioNp.setAttribute('name','Npri');
nodePrimaryTurnsRatioNp.setAttribute('value',strcat(PrimaryTurnsRatioNp) );

nodeSecondaryTurnsRatioNs = docNode.createElement('key'); 
docRootNode.appendChild(nodeSecondaryTurnsRatioNs );
nodeSecondaryTurnsRatioNs.setAttribute('name','Nsec');
nodeSecondaryTurnsRatioNs.setAttribute('value',strcat(SecondaryTurnsRatioNs) );

else                      % Current measurement Shunt measurement

nodeRfb9 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb9 );
nodeRfb9.setAttribute('name','Rfb9');
nodeRfb9.setAttribute('value',strcat(Rfb9, ' kOhm') );

nodeRfb10 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb10 );
nodeRfb10.setAttribute('name','Rfb10');
nodeRfb10.setAttribute('value',strcat(Rfb10, ' kOhm') );

nodeRfb11 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb11 );
nodeRfb11.setAttribute('name','Rfb11');
nodeRfb11.setAttribute('value',strcat(Rfb11, ' kOhm') );

nodeCfb6 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb6 );
nodeCfb6.setAttribute('name','Cfb6');
nodeCfb6.setAttribute('value',strcat(Cfb6, ' pF') );

nodeRfb12 = docNode.createElement('key'); 
docRootNode.appendChild(nodeRfb12 );
nodeRfb12.setAttribute('name','Rfb12');
nodeRfb12.setAttribute('value',strcat(Rfb12, ' kOhm') );

nodeCfb7 = docNode.createElement('key'); 
docRootNode.appendChild(nodeCfb7 );
nodeCfb7.setAttribute('name','Cfb7');
nodeCfb7.setAttribute('value',strcat(Cfb7, ' pF' ) );

end
%% IPT3
% nodeControlLoopParameters = docNode.createElement('key'); 
% docRootNode.appendChild(nodeControlLoopParameters);
% nodeControlLoopParameters.setAttribute('name','Control Loop Parameters');

% nodeComment3 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment3);
% nodeComment3.setAttribute('name','Comment: Control Loop Parameters');


nodeILPWMFreq = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPWMFreq);
nodeILPWMFreq.setAttribute('name','PWM_SW_FREQUENCY');
nodeILPWMFreq.setAttribute('value',strcat(ILPWMFreq, ' kHz'));

nodeILSampRatio = docNode.createElement('key'); 
docRootNode.appendChild(nodeILSampRatio);
nodeILSampRatio.setAttribute('name','IL_SAMPLING_RATIO');
nodeILSampRatio.setAttribute('value',strcat(ILSampRatio, ''));

% nodeILPWMResolution = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILPWMResolution);
% nodeILPWMResolution.setAttribute('name','PWM_RESOLUTION');
% nodeILPWMResolution.setAttribute('value',strcat(ILPWMResolution, ' nsec'));

nodeILComputationalDelay = docNode.createElement('key'); 
docRootNode.appendChild(nodeILComputationalDelay);
nodeILComputationalDelay.setAttribute('name','IL_COMPUTATIONAL_DELAY');
nodeILComputationalDelay.setAttribute('value',strcat(ILComputationalDelay, ' nsec'));

if (handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value == 1)
nodeILCrossOverFreq = docNode.createElement('key'); 
docRootNode.appendChild(nodeILCrossOverFreq);
nodeILCrossOverFreq.setAttribute('name','IL_CROSSOVER_FREQUENCY');
nodeILCrossOverFreq.setAttribute('value',strcat(ILCrossOverFreq, ' Hz'));

nodeILPhaseMargin = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPhaseMargin);
nodeILPhaseMargin.setAttribute('name','IL_PHASE_MARGIN');
nodeILPhaseMargin.setAttribute('value',strcat(ILPhaseMargin, ' Deg'));
end

nodeILMinControlOutput = docNode.createElement('key'); 
docRootNode.appendChild(nodeILMinControlOutput);
nodeILMinControlOutput.setAttribute('name','IL_MIN_CONTROL_OUTPUT');
nodeILMinControlOutput.setAttribute('value',strcat(ILMinControlOutput));

nodeILMaxControlOutput = docNode.createElement('key'); 
docRootNode.appendChild(nodeILMaxControlOutput);
nodeILMaxControlOutput.setAttribute('name','IL_MAX_CONTROL_OUTPUT');
nodeILMaxControlOutput.setAttribute('value',strcat(ILMaxControlOutput));

% nodeOLPWMFreq = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLPWMFreq);
% nodeOLPWMFreq.setAttribute('name','OL_PWM_FREQUENCY');
% nodeOLPWMFreq.setAttribute('value',strcat(OLPWMFreq, ' kHz'));

% nodeOLPWMResolution = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLPWMResolution);
% nodeOLPWMResolution.setAttribute('name','Outer Loop PWM Resolution');
% nodeOLPWMResolution.setAttribute('value',strcat(OLPWMResolution, '  nsec'));

nodeOLComputationalDelay = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLComputationalDelay);
nodeOLComputationalDelay.setAttribute('name','OL_COMPUTATIONAL_DELAY');
nodeOLComputationalDelay.setAttribute('value',strcat(OLComputationalDelay, ' nsec'));

% nodeOLGateDriveDelay = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLGateDriveDelay);
% nodeOLGateDriveDelay.setAttribute('name','OL_GATEDRIVER_DELAY');
% nodeOLGateDriveDelay.setAttribute('value',strcat(OLGateDriveDelay, ' nsec'));
if (handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value == 1)
nodeOLCrossOverFreq = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLCrossOverFreq);
nodeOLCrossOverFreq.setAttribute('name','OL_CROSSOVER_FREQUENCY');
nodeOLCrossOverFreq.setAttribute('value',strcat(OLCrossOverFreq, ' Hz'));

nodeOLPhaseMargin = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPhaseMargin);
nodeOLPhaseMargin.setAttribute('name','OL_PHASE_MARGIN');
nodeOLPhaseMargin.setAttribute('value',strcat(OLPhaseMargin, ' Deg'));

end

nodeOLMinControlOutput = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLMinControlOutput);
nodeOLMinControlOutput.setAttribute('name','OL_MIN_CONTROL_OUTPUT');
nodeOLMinControlOutput.setAttribute('value',strcat(OLMinControlOutput));

nodeOLMaxControlOutput = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLMaxControlOutput);
nodeOLMaxControlOutput.setAttribute('name','OL_MAX_CONTROL_OUTPUT');
nodeOLMaxControlOutput.setAttribute('value',strcat(OLMaxControlOutput));

% nodeComment4 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment4);
% nodeComment4.setAttribute('name','Comment: Continious Time Domain Inner Loop Controller Parameters');
%% IPT3 S- Domain Compensator Design Values
if (handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value == 1)
    nodeCompDesignChoice = docNode.createElement('key');
    docRootNode.appendChild(nodeCompDesignChoice );
    nodeCompDesignChoice.setAttribute('name','AUTO_COMPENSATOR_DESIGN');
    nodeCompDesignChoice.setAttribute('value','ENABLED' );
    
else
    nodeCompDesignChoice = docNode.createElement('key');
    docRootNode.appendChild(nodeCompDesignChoice );
    nodeCompDesignChoice.setAttribute('name','MANUAL_COMPENSATOR_DESIGN');
    nodeCompDesignChoice.setAttribute('value','ENABLED' );
    
end

%% Inner Loop COmpensator Design values
nodeILCompensator = docNode.createElement('key'); 
docRootNode.appendChild(nodeILCompensator );
nodeILCompensator.setAttribute('name','INNER_LOOP_COMPENSATOR');
nodeILCompensator.setAttribute('value',ILCompensator );

if ILCompensatorSel==2
nodeILGain = docNode.createElement('key'); 
docRootNode.appendChild(nodeILGain);
nodeILGain.setAttribute('name','IL_GAIN_Kdc');
nodeILGain.setAttribute('value',strcat(ILGain));

nodeILPole1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPole1);
nodeILPole1.setAttribute('name','IL_POLE1');
nodeILPole1.setAttribute('value',strcat(ILPole1));

nodeILPole2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPole2);
nodeILPole2.setAttribute('name','IL_POLE2');
nodeILPole2.setAttribute('value',strcat(ILPole2));

% nodeILPole3 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILPole3);
% nodeILPole3.setAttribute('name','IL_POLE3');
% nodeILPole3.setAttribute('value',strcat(ILPole3));

nodeILZero1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZero1);
nodeILZero1.setAttribute('name','IL_ZERO1');
nodeILZero1.setAttribute('value',strcat(ILZero1));

nodeILZero2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZero2);
nodeILZero2.setAttribute('name','IL_ZERO2');
nodeILZero2.setAttribute('value',strcat(ILZero2));

% nodeILZero3 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILZero3);
% nodeILZero3.setAttribute('name','IL_ZERO3');
% nodeILZero3.setAttribute('value',strcat(ILZero3));

elseif ILCompensatorSel==1
    
nodeILGain = docNode.createElement('key'); 
docRootNode.appendChild(nodeILGain);
nodeILGain.setAttribute('name','IL_GAIN_Kdc');
nodeILGain.setAttribute('value',strcat(ILGain));

nodeILPole1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPole1);
nodeILPole1.setAttribute('name','IL_POLE1');
nodeILPole1.setAttribute('value',strcat(ILPole1));

% nodeILPole2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILPole2);
% nodeILPole2.setAttribute('name','IL_POLE2');
% nodeILPole2.setAttribute('value',strcat(ILPole2));

% nodeILPole3 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILPole3);
% nodeILPole3.setAttribute('name','IL_POLE3');
% nodeILPole3.setAttribute('value',strcat(ILPole3));

nodeILZero1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZero1);
nodeILZero1.setAttribute('name','IL_ZERO1');
nodeILZero1.setAttribute('value',strcat(ILZero1));

% nodeILZero2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILZero2);
% nodeILZero2.setAttribute('name','IL_ZERO2');
% nodeILZero2.setAttribute('value',strcat(ILZero2));

% nodeILZero3 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILZero3);
% nodeILZero3.setAttribute('name','IL_ZERO3');
% nodeILZero3.setAttribute('value',strcat(ILZero3));
    
end    

%% Continious Domain Cascaded
% nodeComment5 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment5);
% nodeComment5.setAttribute('name','Comment: Continious Time Domain Inner Loop Cascaded Controller Parameters');

nodeILP1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILP1_cascaded );
nodeILP1_cascaded.setAttribute('name','IL_CASCADED_POLE1');
nodeILP1_cascaded.setAttribute('value',ILP1_cascaded );

nodeILZ1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZ1_cascaded);
nodeILZ1_cascaded.setAttribute('name','IL_CASCADED_ZERO1');
nodeILZ1_cascaded.setAttribute('value',strcat(ILZ1_cascaded));

nodeILKdc1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILKdc1_cascaded);
nodeILKdc1_cascaded.setAttribute('name','IL_CASCADED_Kdc1');
nodeILKdc1_cascaded.setAttribute('value',strcat(ILKdc1_cascaded));
 
nodeILP2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILP2_cascaded );
nodeILP2_cascaded.setAttribute('name','IL_CASCADED_POLE2');
nodeILP2_cascaded.setAttribute('value',ILP2_cascaded );

nodeILZ2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZ2_cascaded);
nodeILZ2_cascaded.setAttribute('name','IL_CASCADED_ZERO2');
nodeILZ2_cascaded.setAttribute('value',strcat(ILZ2_cascaded));

nodeILKdc2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILKdc2_cascaded);
nodeILKdc2_cascaded.setAttribute('name','IL_CASCADED_Kdc2');
nodeILKdc2_cascaded.setAttribute('value',strcat(ILKdc2_cascaded));

nodeILP3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILP3_cascaded );
nodeILP3_cascaded.setAttribute('name','IL_CASCADED_POLE3');
nodeILP3_cascaded.setAttribute('value',ILP3_cascaded );

nodeILZ3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILZ3_cascaded);
nodeILZ3_cascaded.setAttribute('name','IL_CASCADED_ZERO3');
nodeILZ3_cascaded.setAttribute('value',strcat(ILZ3_cascaded));

nodeILKdc3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeILKdc3_cascaded);
nodeILKdc3_cascaded.setAttribute('name','IL_CASCADED_Kdc3');
nodeILKdc3_cascaded.setAttribute('value',strcat(ILKdc3_cascaded));

%% OUTER LOOP COMPENSATOR
%%
% nodeComment6 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment6);
% nodeComment6.setAttribute('name','Comment: Continious Time Domain Outer Loop Controller Parameters');

nodeOLCompensator = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLCompensator);
nodeOLCompensator.setAttribute('name','OUTER_LOOP_COMPENSATOR');
nodeOLCompensator.setAttribute('value',OLCompensator);

if OLCompensatorSel==2

nodeOLGain = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLGain);
nodeOLGain.setAttribute('name','OL_GAIN_Kdc');
nodeOLGain.setAttribute('value',strcat(OLGain));

nodeOLPole1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPole1);
nodeOLPole1.setAttribute('name','OL_POLE1');
nodeOLPole1.setAttribute('value',strcat(OLPole1));

nodeOLPole2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPole2);
nodeOLPole2.setAttribute('name','OL_POLE2');
nodeOLPole2.setAttribute('value',strcat(OLPole2));

nodeOLZero1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZero1);
nodeOLZero1.setAttribute('name','OL_ZERO1');
nodeOLZero1.setAttribute('value',strcat(OLZero1));

nodeOLZero2 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZero2);
nodeOLZero2.setAttribute('name','OL_ZERO2');
nodeOLZero2.setAttribute('value',strcat(OLZero2));

elseif OLCompensatorSel==1
nodeOLGain = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLGain);
nodeOLGain.setAttribute('name','OL_GAIN_Kdc');
nodeOLGain.setAttribute('value',strcat(OLGain));

nodeOLPole1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPole1);
nodeOLPole1.setAttribute('name','OL_POLE1');
nodeOLPole1.setAttribute('value',strcat(OLPole1));

% nodeOLPole2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLPole2);
% nodeOLPole2.setAttribute('name','OL_POLE2');
% nodeOLPole2.setAttribute('value',strcat(OLPole2));

nodeOLZero1 = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZero1);
nodeOLZero1.setAttribute('name','OL_ZERO1');
nodeOLZero1.setAttribute('value',strcat(OLZero1));

% nodeOLZero2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLZero2);
% nodeOLZero2.setAttribute('name','OL_ZERO2');
% nodeOLZero2.setAttribute('value',strcat(OLZero2));

end

% nodeComment7 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment7);
% nodeComment7.setAttribute('name','Comment: Continious Time Domain Outer Loop Cascaded Controller Parameters');

nodeOLP1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLP1_cascaded );
nodeOLP1_cascaded.setAttribute('name','OL_CASCADED_POLE1');
nodeOLP1_cascaded.setAttribute('value',OLP1_cascaded );

nodeOLZ1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZ1_cascaded);
nodeOLZ1_cascaded.setAttribute('name','OL_CASCADED_ZERO1');
nodeOLZ1_cascaded.setAttribute('value',strcat(OLZ1_cascaded));

nodeOLKdc1_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLKdc1_cascaded);
nodeOLKdc1_cascaded.setAttribute('name','OL_CASCADED_Kdc1');
nodeOLKdc1_cascaded.setAttribute('value',strcat(OLKdc1_cascaded));

nodeOLP2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLP2_cascaded );
nodeOLP2_cascaded.setAttribute('name','OL_CASCADED_POLE2');
nodeOLP2_cascaded.setAttribute('value',OLP2_cascaded );

nodeOLZ2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZ2_cascaded);
nodeOLZ2_cascaded.setAttribute('name','OL_CASCADED_ZERO2');
nodeOLZ2_cascaded.setAttribute('value',strcat(OLZ2_cascaded));

nodeOLKdc2_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLKdc2_cascaded);
nodeOLKdc2_cascaded.setAttribute('name','OL_CASCADED_Kdc2');
nodeOLKdc2_cascaded.setAttribute('value',strcat(OLKdc2_cascaded));

nodeOLP3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLP3_cascaded );
nodeOLP3_cascaded.setAttribute('name','OL_CASCADED_POLE3');
nodeOLP3_cascaded.setAttribute('value',OLP3_cascaded );

nodeOLZ3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLZ3_cascaded);
nodeOLZ3_cascaded.setAttribute('name','OL_CASCADED_ZERO3');
nodeOLZ3_cascaded.setAttribute('value',strcat(OLZ3_cascaded));

nodeOLKdc3_cascaded = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLKdc3_cascaded);
nodeOLKdc3_cascaded.setAttribute('name','OL_CASCADED_Kdc3');
nodeOLKdc3_cascaded.setAttribute('value',strcat(OLKdc3_cascaded));

%%
%% GPT3 Compensator COefficients
%%
% nodeILA0_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA0_Abs);
% nodeILA0_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_A0');
% nodeILA0_Abs.setAttribute('value',strcat(A0_Abs_IL));
% nodeComment10 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment10);
% nodeComment10.setAttribute('name','Comment: Inner Loop Digital Absolute coefficients');


nodeILA1_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA1_Abs);
nodeILA1_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_A1');
nodeILA1_Abs.setAttribute('value',strcat(A1_Abs_IL));

nodeILA2_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA2_Abs);
nodeILA2_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_A2');
nodeILA2_Abs.setAttribute('value',strcat(A2_Abs_IL));

nodeILA3_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA3_Abs);
nodeILA3_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_A3');
nodeILA3_Abs.setAttribute('value',strcat(A3_Abs_IL));

% nodeILA4_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA4_Abs);
% nodeILA4_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_A4');
% nodeILA4_Abs.setAttribute('value',strcat(A4_Abs_IL));

nodeILB0_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB0_Abs);
nodeILB0_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_B0');
nodeILB0_Abs.setAttribute('value',strcat(B0_Abs_IL));

nodeILB1_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB1_Abs);
nodeILB1_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_B1');
nodeILB1_Abs.setAttribute('value',strcat(B1_Abs_IL));

nodeILB2_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB2_Abs);
nodeILB2_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_B2');
nodeILB2_Abs.setAttribute('value',strcat(B2_Abs_IL));

nodeILB3_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB3_Abs);
nodeILB3_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_B3');
nodeILB3_Abs.setAttribute('value',strcat(B3_Abs_IL));

% nodeILB4_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILB4_Abs);
% nodeILB4_Abs.setAttribute('name','IL_ABSOLUTE_COEFFICIENT_B4');
% nodeILB4_Abs.setAttribute('value',strcat(B4_Abs_IL));

%%
% nodeComment11 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment11);
% nodeComment11.setAttribute('name','Comment: Inner Loop Digital Normalized coefficients');

% nodeILA0_Norm = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA0_Norm);
% nodeILA0_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_A0');
% nodeILA0_Norm.setAttribute('value',strcat(A0_Norm_IL));

nodeILA1_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA1_Norm);
nodeILA1_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_A1');
nodeILA1_Norm.setAttribute('value',strcat(A1_Norm_IL));

nodeILA2_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA2_Norm);
nodeILA2_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_A2');
nodeILA2_Norm.setAttribute('value',strcat(A2_Norm_IL));

nodeILA3_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA3_Norm);
nodeILA3_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_A3');
nodeILA3_Norm.setAttribute('value',strcat(A3_Norm_IL));

% nodeILA4_Norm = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA4_Norm);
% nodeILA4_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_A4');
% nodeILA4_Norm.setAttribute('value',strcat(A4_Norm_IL));

nodeILB0_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB0_Norm);
nodeILB0_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_B0');
nodeILB0_Norm.setAttribute('value',strcat(B0_Norm_IL));

nodeILB1_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB1_Norm);
nodeILB1_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_B1');
nodeILB1_Norm.setAttribute('value',strcat(B1_Norm_IL));

nodeILB2_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB2_Norm);
nodeILB2_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_B2');
nodeILB2_Norm.setAttribute('value',strcat(B2_Norm_IL));

nodeILB3_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB3_Norm);
nodeILB3_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_B3');
nodeILB3_Norm.setAttribute('value',strcat(B3_Norm_IL));

%nodeILB4_Norm = docNode.createElement('key'); 
%docRootNode.appendChild(nodeILB4_Norm);
%nodeILB4_Norm.setAttribute('name','IL_NORMALIZED_COEFFICIENT_B4');
%nodeILB4_Norm.setAttribute('value',strcat(B4_Norm_IL));

nodeIL_Norm_Normal = docNode.createElement('key'); 
docRootNode.appendChild(nodeIL_Norm_Normal);
nodeIL_Norm_Normal.setAttribute('name','IL_NORMALIZED_NORMAL');
nodeIL_Norm_Normal.setAttribute('value',strcat(IL_Norm_Normal));

nodeIL_Norm_PostShift = docNode.createElement('key'); 
docRootNode.appendChild(nodeIL_Norm_PostShift);
nodeIL_Norm_PostShift.setAttribute('name','IL_NORMALIZED_POSTSHIFT');
nodeIL_Norm_PostShift.setAttribute('value',strcat(IL_Norm_PostShift));

nodeIL_Norm_PostScalar = docNode.createElement('key'); 
docRootNode.appendChild(nodeIL_Norm_PostScalar);
nodeIL_Norm_PostScalar.setAttribute('name','IL_NORMALIZED_POSTSCALAR');
nodeIL_Norm_PostScalar.setAttribute('value',strcat(IL_Norm_PostScalar));


%% IL Cascaded 
%%
% nodeComment11 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment11);
% nodeComment11.setAttribute('name','Comment: Inner Loop Digital Cascaded coefficients');

% nodeILA10_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA10_cas);
% nodeILA10_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A10');
% nodeILA10_cas.setAttribute('value',strcat(A10_IL));

nodeILA11_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA11_cas);
nodeILA11_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A11');
nodeILA11_cas.setAttribute('value',strcat(A11_IL));

nodeILB10_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB10_cas);
nodeILB10_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B10');
nodeILB10_cas.setAttribute('value',strcat(B10_IL));

nodeILB11_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB11_cas);
nodeILB11_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B11');
nodeILB11_cas.setAttribute('value',strcat(B11_IL));

nodeILPS_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILPS_cas);
nodeILPS_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_POSTSHIFT');
nodeILPS_cas.setAttribute('value',strcat(PS_IL));

% nodeILA20_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA20_cas);
% nodeILA20_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A20');
% nodeILA20_cas.setAttribute('value',strcat(A20_IL));

nodeILA21_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA21_cas);
nodeILA21_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A21');
nodeILA21_cas.setAttribute('value',strcat(A21_IL));

nodeILB20_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB20_cas);
nodeILB20_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B20');
nodeILB20_cas.setAttribute('value',strcat(B20_IL));

nodeILB21_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB21_cas);
nodeILB21_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B21');
nodeILB21_cas.setAttribute('value',strcat(B21_IL));

% nodeILA30_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeILA30_cas);
% nodeILA30_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A30');
% nodeILA30_cas.setAttribute('value',strcat(A30_IL));

nodeILA31_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILA21_cas);
nodeILA31_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_A31');
nodeILA31_cas.setAttribute('value',strcat(A31_IL));

nodeILB30_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB30_cas);
nodeILB30_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B30');
nodeILB30_cas.setAttribute('value',strcat(B30_IL));

nodeILB31_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeILB31_cas);
nodeILB31_cas.setAttribute('name','IL_CASCADED_COEFFICIENT_B31');
nodeILB31_cas.setAttribute('value',strcat(B31_IL));

%% Outer Loop Coefficients
%%
% nodeComment12 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment12);
% nodeComment12.setAttribute('name','Comment: Outer Loop Digital Absolute Coefficients');

% nodeOLA0_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA0_Abs);
% nodeOLA0_Abs.setAttribute('name','OL_CASCADED_COEFFICIENT_A0');
% nodeOLA0_Abs.setAttribute('value',strcat(A0_Abs_OL));


nodeOLA1_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA1_Abs);
nodeOLA1_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_A1');
nodeOLA1_Abs.setAttribute('value',strcat(A1_Abs_OL));

nodeOLA2_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA2_Abs);
nodeOLA2_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_A2');
nodeOLA2_Abs.setAttribute('value',strcat(A2_Abs_OL));

nodeOLA3_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA3_Abs);
nodeOLA3_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_A3');
nodeOLA3_Abs.setAttribute('value',strcat(A3_Abs_OL));

% nodeOLA4_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA4_Abs);
% nodeOLA4_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_A4');
% nodeOLA4_Abs.setAttribute('value',strcat(A4_Abs_OL));

nodeOLB0_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB0_Abs);
nodeOLB0_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_B0');
nodeOLB0_Abs.setAttribute('value',strcat(B0_Abs_OL));

nodeOLB1_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB1_Abs);
nodeOLB1_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_B1');
nodeOLB1_Abs.setAttribute('value',strcat(B1_Abs_OL));

nodeOLB2_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB2_Abs);
nodeOLB2_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_B2');
nodeOLB2_Abs.setAttribute('value',strcat(B2_Abs_OL));

nodeOLB3_Abs = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB3_Abs);
nodeOLB3_Abs.setAttribute('name','OL_ABSOLUTE_COEFFICIENT_B3');
nodeOLB3_Abs.setAttribute('value',strcat(B3_Abs_OL));

% nodeOLB4_Abs = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLB4_Abs);
% nodeOLB4_Abs.setAttribute('name','OL_CASCADED_COEFFICIENT_B4');
% nodeOLB4_Abs.setAttribute('value',strcat(B4_Abs_OL));
%% OL Normalized Coefficients
%%
% nodeComment13 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment13);
% nodeComment13.setAttribute('name','Comment: Outer Loop Digital Normalized Coefficients');
% nodeOLA0_Norm = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA0_Norm);
% nodeOLA0_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_A0');
% nodeOLA0_Norm.setAttribute('value',strcat(A0_Norm_OL));

nodeOLA1_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA1_Norm);
nodeOLA1_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_A1');
nodeOLA1_Norm.setAttribute('value',strcat(A1_Norm_OL));

nodeOLA2_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA2_Norm);
nodeOLA2_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_A2');
nodeOLA2_Norm.setAttribute('value',strcat(A2_Norm_OL));

nodeOLA3_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA3_Norm);
nodeOLA3_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_A3');
nodeOLA3_Norm.setAttribute('value',strcat(A3_Norm_OL));

% nodeOLA4_Norm = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA4_Norm);
% nodeOLA4_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_A4');
% nodeOLA4_Norm.setAttribute('value',strcat(A4_Norm_OL));

nodeOLB0_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB0_Norm);
nodeOLB0_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_B0');
nodeOLB0_Norm.setAttribute('value',strcat(B0_Norm_OL));

nodeOLB1_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB1_Norm);
nodeOLB1_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_B1');
nodeOLB1_Norm.setAttribute('value',strcat(B1_Norm_OL));

nodeOLB2_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB2_Norm);
nodeOLB2_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_B2');
nodeOLB2_Norm.setAttribute('value',strcat(B2_Norm_OL));

nodeOLB3_Norm = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB3_Norm);
nodeOLB3_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_B3');
nodeOLB3_Norm.setAttribute('value',strcat(B3_Norm_OL));

% nodeOLB4_Norm = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLB4_Norm);
% nodeOLB4_Norm.setAttribute('name','OL_NORMALIZED_COEFFICIENT_B4');
% nodeOLB4_Norm.setAttribute('value',strcat(B4_Norm_OL));
nodeOL_Norm_Normal = docNode.createElement('key'); 
docRootNode.appendChild(nodeOL_Norm_Normal);
nodeOL_Norm_Normal.setAttribute('name','OL_NORMALIZED_NORMAL');
nodeOL_Norm_Normal.setAttribute('value',strcat(OL_Norm_Normal));

nodeOL_Norm_PostShift = docNode.createElement('key'); 
docRootNode.appendChild(nodeOL_Norm_PostShift);
nodeOL_Norm_PostShift.setAttribute('name','OL_NORMALIZED_POSTSHIFT');
nodeOL_Norm_PostShift.setAttribute('value',strcat(OL_Norm_PostShift));

nodeOL_Norm_PostScalar = docNode.createElement('key'); 
docRootNode.appendChild(nodeOL_Norm_PostScalar);
nodeOL_Norm_PostScalar.setAttribute('name','OL_NORMALIZED_POSTSCALAR');
nodeOL_Norm_PostScalar.setAttribute('value',strcat(OL_Norm_PostScalar));

%% OL Cascaded 
%%
% nodeComment14 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment14);
% nodeComment14.setAttribute('name','Comment: Outer Loop Digital Cascaded Coefficients');

nodeOLA11_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA11_cas);
nodeOLA11_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A11');
nodeOLA11_cas.setAttribute('value',strcat(A11_OL));

nodeOLB10_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB10_cas);
nodeOLB10_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B10');
nodeOLB10_cas.setAttribute('value',strcat(B10_OL));

nodeOLB11_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB11_cas);
nodeOLB11_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B11');
nodeOLB11_cas.setAttribute('value',strcat(B11_OL));

% nodeOLA10_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA10_cas);
% nodeOLA10_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A10');
% nodeOLA10_cas.setAttribute('value',strcat(A10_OL));

nodeOLPS_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLPS_cas);
nodeOLPS_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_POSTSHIFT');
nodeOLPS_cas.setAttribute('value',strcat(PS_OL));

% nodeOLA20_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA20_cas);
% nodeOLA20_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A20');
% nodeOLA20_cas.setAttribute('value',strcat(A20_OL));

nodeOLA21_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA21_cas);
nodeOLA21_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A21');
nodeOLA21_cas.setAttribute('value',strcat(A21_OL));

nodeOLB20_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB20_cas);
nodeOLB20_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B20');
nodeOLB20_cas.setAttribute('value',strcat(B20_OL));

nodeOLB21_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB21_cas);
nodeOLB21_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B21');
nodeOLB21_cas.setAttribute('value',strcat(B21_OL));

% nodeOLA30_cas = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOLA30_cas);
% nodeOLA30_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A30');
% nodeOLA30_cas.setAttribute('value',strcat(A30_OL));

nodeOLA31_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLA21_cas);
nodeOLA31_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_A31');
nodeOLA31_cas.setAttribute('value',strcat(A31_OL));

nodeOLB30_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB30_cas);
nodeOLB30_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B30');
nodeOLB30_cas.setAttribute('value',strcat(B30_OL));

nodeOLB31_cas = docNode.createElement('key'); 
docRootNode.appendChild(nodeOLB31_cas);
nodeOLB31_cas.setAttribute('name','OL_CASCADED_COEFFICIENT_B31');
nodeOLB31_cas.setAttribute('value',strcat(B31_OL));

%% IPT4
%%
% nodeComment8 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment8);
% nodeComment8.setAttribute('name','Comment: dsPIC DSC Configuration Parameters');

% nodeZCD1 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeZCD1 );
% nodeZCD1.setAttribute('name','CMP_ZCD1');
% nodeZCD1.setAttribute('value',ZCD1 );
% 
% nodeZCD2 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeZCD2 );
% nodeZCD2.setAttribute('name','CMP_ZCD2');
% nodeZCD2.setAttribute('value',ZCD2 );


% nodeGPIO4 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeGPIO4 );
% nodeGPIO4.setAttribute('name','GPIO 4');
% nodeGPIO4.setAttribute('value',GPIO4 );

% nodeGPIO4Port = docNode.createElement('key'); 
% docRootNode.appendChild(nodeGPIO4Port );
% nodeGPIO4Port.setAttribute('name','GPIO4_PORT');
% nodeGPIO4Port.setAttribute('value',GPIO4_Port );

% nodeDAC_Data = docNode.createElement('key'); 
% docRootNode.appendChild(nodeDAC_Data );
% nodeDAC_Data.setAttribute('name','DAC_DATA');
% nodeDAC_Data.setAttribute('value',DAC_Data );


%%
%% IPT5 xml configuration
%%
% #define INPUT_UV_FLT_THRESHOLD_CNTS������� d�� � data limit threshold
% #define INPUT_UV_FLT_HYSLIMIT_CNTS�������� d���� hysteresis data threshold to remove the fault
% #define INPUT_UV_FLT_CNT_THRESHOLD�������� u���� number of consecutive events before fault is enabled
% #define INPUT_UV_FLT_CNT_HYSLIMIT��������� u���� and number of consecutive events past hysteresis threshold before fault is actually removed

%%
% nodeComment9 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment9);
% nodeComment9.setAttribute('name','Comment: Protections Configuration Parameters');

% nodeIPUnderVoltageLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodeIPUnderVoltageLimit );
% nodeIPUnderVoltageLimit.setAttribute('name','PROTECTIONS');

%% Over Current Fault
% if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
%     
% nodeOPOverCurrentLimitE = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverCurrentLimitE);
% nodeOPOverCurrentLimitE.setAttribute('name','OVER_CURRENT_FAULT');
% nodeOPOverCurrentLimitE.setAttribute('value','ENABLED');    
%     
% nodeOPOverCurrentLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverCurrentLimit);
% nodeOPOverCurrentLimit.setAttribute('name','OUTPUT_OC_FLT_THRESHOLD_CNTS');
% nodeOPOverCurrentLimit.setAttribute('value',strcat(OPOverCurrentLimit));
% 
% nodeOPOverCurrentLimitHys = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverCurrentLimitHys);
% nodeOPOverCurrentLimitHys.setAttribute('name','OUTPUT_OC_FLT_HYSLIMIT_CNTS');
% nodeOPOverCurrentLimitHys.setAttribute('value',strcat(OPOverCurrentLimitHys));
% 
% nodeOPOverCurrentFaultEnable  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverCurrentFaultEnable );
% nodeOPOverCurrentFaultEnable.setAttribute('name','OUTPUT_OC_FLT_CNT_THRESHOLD');
% nodeOPOverCurrentFaultEnable.setAttribute('value',strcat(OPOverCurrentFaultEnable));
% 
% nodeOPOverCurrentLimitFaultDisable  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOPOverCurrentLimitFaultDisable  );
% nodeOPOverCurrentLimitFaultDisable.setAttribute('name','OUTPUT_OC_FLT_CNT_HYSLIMIT');
% nodeOPOverCurrentLimitFaultDisable.setAttribute('value',strcat(OPOverCurrentLimitFaultDisable ));
% end

%%
% if handles.IPT5.FeaturesConfig.OverTemperatureLimit.Value==1
%     
% nodeOverTemperatureLimitE  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOverTemperatureLimitE );
% nodeOverTemperatureLimitE.setAttribute('name','OVER_TEMP_FAULT');
% nodeOverTemperatureLimitE.setAttribute('value','ENABLED');    
%     
% nodeOverTemperatureLimit  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOverTemperatureLimit );
% nodeOverTemperatureLimit.setAttribute('name','OVERTEMP_FLT_THRESHOLD_CNTS');
% nodeOverTemperatureLimit.setAttribute('value',strcat(OverTemperatureLimit));
% 
% nodeOverTemperatureLimitHys  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOverTemperatureLimitHys);
% nodeOverTemperatureLimitHys.setAttribute('name','OVERTEMP_FLT_HYSLIMIT_CNTS');
% nodeOverTemperatureLimitHys.setAttribute('value',strcat(OverTemperatureLimitHys));
% 
% nodeOverTemperatureLimitFaultEnable  = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOverTemperatureLimitFaultEnable );
% nodeOverTemperatureLimitFaultEnable.setAttribute('name','OVERTEMP_FLT_CNT_THRESHOLD');
% nodeOverTemperatureLimitFaultEnable.setAttribute('value',strcat(OverTemperatureLimitFaultEnable));
% 
% nodeOverTemperatureLimitFaultdisable = docNode.createElement('key'); 
% docRootNode.appendChild(nodeOverTemperatureLimitFaultdisable);
% nodeOverTemperatureLimitFaultdisable.setAttribute('name','OVERTEMP_FLT_CNT_HYSLIMIT');
% nodeOverTemperatureLimitFaultdisable.setAttribute('value',strcat(OverTemperatureLimitFaultdisable));
% end




%% Phase shedding
if handles.IPT6.FeaturesConfiguration.PhaseShedding.Value==1
    
% nodePhaseSheddingIPFCTextBoxE = docNode.createElement('key'); 
% docRootNode.appendChild(nodePhaseSheddingIPFCTextBoxE );
% nodePhaseSheddingIPFCTextBoxE.setAttribute('name','PHASE_SHEDDING');
% nodePhaseSheddingIPFCTextBoxE.setAttribute('value','ENABLED');

nodePhaseSheddingIPFCTextBox = docNode.createElement('key'); 
docRootNode.appendChild(nodePhaseSheddingIPFCTextBox );
nodePhaseSheddingIPFCTextBox.setAttribute('name','PHASE_SHEDDING_THRESHOLD_CNTS');
nodePhaseSheddingIPFCTextBox.setAttribute('value',strcat(PhaseSheddingIPFCTextBox));

nodePhaseSheddingIPFCTextBoxWatts = docNode.createElement('key'); 
docRootNode.appendChild(nodePhaseSheddingIPFCTextBoxWatts );
nodePhaseSheddingIPFCTextBoxWatts.setAttribute('name','PHASE_SHEDDING_WATTS');
nodePhaseSheddingIPFCTextBoxWatts.setAttribute('value',strcat(PhaseSheddingIPFCTextBoxWatts));

% if handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value==1
nodeHysPhaseSheddingIPFCTextBox = docNode.createElement('key'); 
docRootNode.appendChild(nodeHysPhaseSheddingIPFCTextBox );
nodeHysPhaseSheddingIPFCTextBox.setAttribute('name','PHASE_SHEDDING_HYSLIMIT_CNTS');
nodeHysPhaseSheddingIPFCTextBox.setAttribute('value',strcat(HysPhaseSheddingIPFCTextBox));

nodeHysPhaseSheddingIPFCTextBoxWatts = docNode.createElement('key'); 
docRootNode.appendChild(nodeHysPhaseSheddingIPFCTextBoxWatts );
nodeHysPhaseSheddingIPFCTextBoxWatts.setAttribute('name','HYS_PHASE_SHEDDING_WATTS');
nodeHysPhaseSheddingIPFCTextBoxWatts.setAttribute('value',strcat(HysPhaseSheddingIPFCTextBoxWatts));
end


%% IPT6 xml configuration
%%
% nodeComment15 = docNode.createElement('key'); 
% docRootNode.appendChild(nodeComment15);
% nodeComment15.setAttribute('name','Comment: Features Configuration');

% nodeSoftStartDurationLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodeSoftStartDurationLimit);
% nodeSoftStartDurationLimit.setAttribute('name','SOFTSTART_DURATION');
% nodeSoftStartDurationLimit.setAttribute('value',strcat(SoftStartDurationLimit));
% 
% nodeSoftStartCallRate = docNode.createElement('key'); 
% docRootNode.appendChild(nodeSoftStartCallRate);
% nodeSoftStartCallRate.setAttribute('name','SOFTSTART_CALLRATE');
% nodeSoftStartCallRate.setAttribute('value',strcat(SoftStartCallRate));
% 
% nodeBurstModeEnableLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodeBurstModeEnableLimit);
% nodeBurstModeEnableLimit.setAttribute('name','BURSTMODE_ENABLE_LIMIT');
% nodeBurstModeEnableLimit.setAttribute('value',strcat(BurstModeEnableLimit));
% 
% nodeBurstModeDisableLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodeBurstModeDisableLimit);
% nodeBurstModeDisableLimit.setAttribute('name','BURSTMODE_DISABLE_LIMIT');
% nodeBurstModeDisableLimit.setAttribute('value',strcat(BurstModeDisableLimit));
% 
% nodePWMDitheringLimit = docNode.createElement('key'); 
% docRootNode.appendChild(nodePWMDitheringLimit );
% nodePWMDitheringLimit.setAttribute('name','PWM_DITHERING_LIMIT');
% nodePWMDitheringLimit.setAttribute('value',strcat(PWMDitheringLimit));


%%
% if isequal(handles.ProjectInformation.ProjName,"BlankProj")
%     MenuSaveAs_Callback(hObject,handles);
%     handles=guidata(hObject);
% end
% [fileName, pathName]=uiputfile('*.h','*.xml','Save File As',char(handles.ProjectInformation.ProjName));

% [fileName, pathName]=uiputfile('*.xml','Save File As',char(handles.ProjectInformation.ProjName));

% if (fileName==0)
%     return;
% end


%% saving of files
% pathName = cd;
% fileName = 'XMLFile.h';
[fileName, pathName]=uiputfile2('*.xml','Save File As',char(handles.ProjectInformation.ProjName));

file_path=fullfile(pathName,fileName);
    
[path,filename,~]=fileparts(file_path);
fileName=strcat(filename,'.xml');
file_path=fullfile(path,fileName);

xmlwrite(file_path,docNode);

% msgbox('Header and xml Files generated and Saved!!');


%%
% [filename, pathname] = uiputfile('output.dat');
%  path_file=fullfile(pathname,filename)
% a=fopen(path_file,'wt');
% fprintf(a,'write something.');
% fclose('all')
%%
%% Trabslating to counts based on the design inputs, Here suffix 'C' used to resemble Counts
%% 
%% Parameters Counts
%% 
[fileName,pathName] = uiputfile2('ParametersCounts.h');
file_path = fullfile(pathName,fileName);
fid4 = fopen(file_path, 'wt');
% fid4a = fopen('Disclaimer.txt');
% fget(fid4a);


fprintf(fid4,'/*********************************************************************************************************');
fprintf(fid4,'\n� 2018 Microchip Technology Inc and its subsidiaries.\n\nSubject to your compliance with these terms, you may use Microchip software and any \nderivatives exclusively with Microchip products. It is your responsibility to comply with third party \nlicense terms applicable to your use of third party software (including open source software) that \nmay accompany Microchip software.\n\n');
fprintf(fid4,'THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER \nEXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY \nIMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS \nFOR A PARTICULAR PURPOSE. \n\n');
fprintf(fid4,'IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,\nINCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND \nWHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP \nHAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO \nTHE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP`S TOTAL LIABILITY ON ALL \nCLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT \nOF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.\n\n ');       
fprintf(fid4,'*********************************************************************************************************/');
%% IPT4
fprintf(fid4,'\n\n\n/* Comment: Device Selection DSPic specification*/\n\n#define Device_Selection\t\t%s\n#define DEVICE_CLOCK \t\t\t%s\n#define CHOSEN_TOPOLOGY \t\t%s\n#define CONTROL_METHOD \t\t\t%s',DeviceSel,DeviceClock,Topology,ControlMethod);
if handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSelectionPanel == 1;
    fprintf(fid4,'\n\n\n#define IND_CURR_SENSE\t\t\t  ENABLED' );
    if  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value==1
        fprintf(fid4,'\n#define CURR_MEAS_NETWORK \t\t CURRENT_TRANSFORMER');
    elseif  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value==1
        fprintf(fid4,'\n#define CURR_MEAS_NETWORK \t\t  SHUNT RESISTOR');end
else
    fprintf(fid4,'\n\n\n#define IND_CURR_SENSE\t\t\t DISABLED' );
    if  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value==1
        fprintf(fid4,'\n#define CURR_MEAS_NETWORK \t\t CURRENT_TRANSFORMER');
    elseif  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value==1
        fprintf(fid4,'\n#define CURR_MEAS_NETWORK \t\t SHUNT RESISTOR');end
end
if handles.IPT6.FeaturesConfiguration.PFETControl.Value == 1
    fprintf(fid4,'\n#define PFET_GPIO\t\t\t\t ENABLED' );
else
    fprintf(fid4,'\n#define PFET_GPIO\t\t\t\t DISABLED' );
end
if handles.IPT6.FeaturesConfiguration.AutomaticRestartEnable.Value == 1
    fprintf(fid4,'\n#define AUTOMATIC_RESTART\t\t ENABLED' );
else
    fprintf(fid4,'\n#define AUTOMATIC_RESTART\t\t DISABLED ');
end
fprintf(fid4,'\n#define MAINSLINESCALING\t\t ENABLED' );
if handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value == 1
    fprintf(fid4,'\n\n\n#define MAINS_UNDERVOLTAGE_FAULT\t ENABLED ');
else
    fprintf(fid4,'\n#define MAINS_UNDERVOLTAGE_FAULT\t\t DISABLED ');
end
if handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value == 1
    fprintf(fid4,'\n#define MAINS_OVERVOLTAGE_FAULT\t\t ENABLED' );
else
    fprintf(fid4,'\n#define MAINS_OVERVOLTAGE_FAULT\t\t DISABLED' );
end
if handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value
    fprintf(fid4,'\n#define OUTPUT_UNDERVOLTAGE_FAULT\t\t ENABLED' );
else
    fprintf(fid4,'\n#define OUTPUT_UNDERVOLTAGE_FAULT\t\t DISABLED' );
end
if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value == 1
    fprintf(fid4,'\n#define OUTPUT_OVERVOLTAGE_FAULT\t\t ENABLED' );
else
    fprintf(fid4,'\n#define OUTPUT_OVERVOLTAGE_FAULT\t\t DISABLED ');
end

if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
    fprintf(fid4,'\n#define OVER_POWER_FAULT\t\t\t ENABLED' );
else
    fprintf(fid4,'\n#define OVER_POWER_FAULT\t\t\t DISABLED ');
end

if handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value==1
    fprintf(fid4,'\n#define UNDER_FREQ_FAULT\t\t ENABLED' );
else
    fprintf(fid4,'\n#define UNDER_FREQ_FAULT\t\t DISABLED' );
end

if handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value==1
    fprintf(fid4,'\n#define OVER_FREQ_FAULT\t\t ENABLED' );
else
    fprintf(fid4,'\n#define OVER_FREQ_FAULT\t\t DISABLED' );
end
fprintf(fid4,'\n#define DEBUG_GPIO\t\t\t ENABLED ');

if handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value==1
    fprintf(fid4,'\n#define GENERIC_FLT1\t\t ENABLED' );
else
    fprintf(fid4,'\n#define GENERIC_FLT1\t\t DISABLED' );
end
if handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value==1
    fprintf(fid4,'\n#define GENERIC_FLT2\t\t ENABLED' );
else
    fprintf(fid4,'\n#define GENERIC_FLT2\t\t DISABLED ');
end
if handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value==1
    fprintf(fid4,'\n\n\n#define PWM_DITHERING\t\t ENABLED ');
else
    fprintf(fid4,'\n#define PWM_DITHERING\t\t DISABLED ');
end


%% Burst Mode Enable Limit
if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
    fprintf(fid4,'\n#define BURST_MODE\t\t\t ENABLED ');
else
    fprintf(fid4,'\n#define BURST_MODE\t\t\t DISABLED ');
end

%% DCM Correction factor
if handles.IPT6.FeaturesConfiguration.DCMCorrection.Value == 1
    fprintf(fid4,'\n#define DCM_CORRECTION_FACTOR\t\t ENABLED ');
else
    fprintf(fid4,'\n#define DCM_CORRECTION_FACTOR\t\t DISABLED ');
end

%% Phase shedding
if handles.IPT6.FeaturesConfiguration.PhaseShedding.Value==1
    fprintf(fid4,'\n#define PHASE_SHEDDING\t\t ENABLED ');
else
    fprintf(fid4,'\n#define PHASE_SHEDDING\t\t DISABLED ');
end
if handles.IPT6.FeaturesConfiguration.XCapCompensation.Value == 1
    fprintf(fid4,'\n#define XCAP_COMPENSATION\t\t\t ENABLED ');
else
    fprintf(fid4,'\n#define XCAP_COMPENSATION\t\t\t DISABLED ');
end
fprintf(fid4,'\n\n#define VCOMPSCALER\t\t %s', vcompscaler);
fprintf(fid4,'\n\n#define ZEROCROSSSCALER\t\t\t %s', ZerocrossScaler);
%% PWM selection Implementation 1
switch PWM_GENx_Val
    case 1
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t  PWM Channel Not Selected' );
        
    case 2      %PWM1H
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-1) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 3      %PWM1L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-2) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 4       %PWM2H
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-2) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 5       %PWM2L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-3) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 6         %PWM3H
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-3) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 7   %PWM3L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-4) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 8          %PWM4H
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-4) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 9         %PWM4L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-5) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 10             %PWM5H        
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-5) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 11            %PWM5L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-6) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 12         %PWM6H        
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-6) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 13        %PWM6L        
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-7) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 14         %PWM7H        
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-7) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 15        %PWM7L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-8) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
        
    case 16         %PWM8H        
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-8) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  DISABLED' );
        
    case 17        %PWM8L
        fprintf(fid4,'\n\n\n#define PWM_PH1_DRV_CH\t\t\t %s',num2str(PWM_GENx_Val-9) );
        fprintf(fid4,'\n#define PWM_PH1_CH_LOW\t\t\t  ENABLED' );
end
switch PWM_GENy_Val
    case 1
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t  PWM Channel Not Selected' );
        
    case 2      %PWM1H
        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-1) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 3      %PWM1L
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-2) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 4       %PWM2H
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-2) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 5       %PWM2L
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-3) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 6         %PWM3H        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-3) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 7         %PWM3L        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-4) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 8          %PWM4H        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-4) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 9         %PWM4L        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-5) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 10             %PWM5H        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-5) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 11            %PWM5L      
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-6) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 12         %PWM6H    
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-6) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
                
    case 13        %PWM6        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-7) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
        
    case 14         %PWM7H        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-7) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );        
        
    case 15        %PWM7L        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-8) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );        
        
    case 16         %PWM8H        
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-8) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  DISABLED' );
        
    case 17        %PWM8L   
        fprintf(fid4,'\n\n\n#define PWM_PH2_DRV_CH\t\t\t %s',num2str(PWM_GENy_Val-9) );
        fprintf(fid4,'\n#define PWM_PH2_CH_LOW\t\t\t  ENABLED' );
end

if handles.dsPICDSCTab.ADC_PFCCurrentEnable.BLPFCCurrent.Value==1
    fprintf(fid4,'\n\n\n#define IPH1_SENSE_CH\t\t\t\t %s',ADC_PFC_I);   
else
    fprintf(fid4,'\n\n\n#define IPH1_SENSE_CH\t\t\t %s\n#define IPH2_SENSE_CH\t\t\t %s',ADC_PFC_I1,ADC_PFC_I2);
end

fprintf(fid4,'\n#define VAC_LINE_SENSE_CH\t\t\t %s\n#define VAC_NEUTRAL_SENSE_CH\t\t %s\n#define VOUT_SENSE_CH\t\t\t\t %s',ADC_Line_Voltage,ADC_Neutral_Voltage,ADC_Output_Voltage);

if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value == 1
    switch Output_Over_V_prot_Val
        case 1
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t  OutputOVP ACMP Not Selected' );
            
        case 2
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-1) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  0' );
        case 3
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-2) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  1' );
        case 4
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-3) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t 2' );
        case 5
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-4) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  3' );
        case 6
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-4) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  0' );
        case 7
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-5) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  1' );            
        case 8
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-6) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  2' );            
        case 9
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-7) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  3' );
        case 10            
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-7) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  0' );
        case 11
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-8) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  1' );
        case 12            
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-9) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  2' );
        case 13            
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-10) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  3' );            
        case 14            
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-10) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  0' );            
        case 15        %PWM7L
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-11) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  1' );            
        case 16            
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-12) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  2' );            
        case 17        %PWM8L
            fprintf(fid4,'\n#define LATCH_FLT_CMP_CH\t\t\t %s',num2str(Output_Over_V_prot_Val-13) );
            fprintf(fid4,'\n#define LATCH_FLT_CMP_INSEL\t\t\t  3' );
    end
    
    fprintf(fid4,'\n\n#define LATCH_FLT_DAC_THRESHOLD_CNTS\t\t\t%s' ,strcat(DAC_Data));
end
if handles.IPT6.FeaturesConfiguration.PFETControl.Value == 1;
    fprintf(fid4,'\n\n#define PFET_GPIO_PORT\t\t\t %s\n#define PFET_GPIO_PORTNUM\t\t %s',PWM_Enable ,PWM_Enable_PinName);
end
fprintf(fid4,'\n\n#define RELAY_GPIO_PORT\t\t\t %s\n#define RELAY_GPIO_PORTNUM\t\t %s',Relay_Drive ,Relay_Drive_Port);
fprintf(fid4,'\n\n#define POWER_ON_GPIO_PORT\t\t\t %s\n#define POWER_ON_GPIO_PORTNUM\t\t %s',GPIO1 ,GPIO1_Port);
fprintf(fid4,'\n\n#define FAULT_GPIO_PORT\t\t\t %s\n#define FAULT_GPIO_PORTNUM\t\t %s',GPIO2 ,GPIO2_Port);
fprintf(fid4,'\n\n#define DEBUG_GPIO_PORT\t\t\t %s\n#define DEBUG_GPIO_PORTNUM\t\t %s',GPIO3 ,GPIO3_Port);
fprintf(fid4,'\n\n#define PWM_SW_PERIOD\t\t\t %s',strcat(ILPTPER,'u'));

if (DeviceSelVal==0)||(DeviceSelVal==1)||(DeviceSelVal==2)||(DeviceSelVal==3)||(DeviceSelVal==4)||(DeviceSelVal==5)||(DeviceSelVal==6)||(DeviceSelVal==7)||(DeviceSelVal==8)||(DeviceSelVal==9)||(DeviceSelVal==10)||(DeviceSelVal==11)||(DeviceSelVal==12)||(DeviceSelVal==13)||(DeviceSelVal==14)
    fprintf(fid4,'\n#define PWM_RESOLUTION\t\t\t %s',strcat(PWM_Res1,'u'));
end
fprintf(fid4,'\n\n#define I_SAMPLERATE\t\t\t %s\n#define V_SAMPLERATE\t\t\t %s\n#define CURR_REF_ISR_TRGCNT\t\t\t %s\n#define PHANTHOM_TRIG_OFFSET\t\t\t %s',strcat(num2str(ILPWMSampFreq),'kHz')) ,strcat(OLPWMSampFreqP,'u'),strcat(num2str(OLSampRatioP),'u') ,strcat(InputVoltageSampFreq, ' kHz');
fprintf(fid4,'\n\n#define VOLTAGE_REFERENCE\t\t\t %s',strcat(num2str(OutPutVoltRefC),'u'));
fprintf(fid4,'\n\n#define GATE_DRV_DELAY\t\t\t %s',strcat(ILGateDriveDelay,'u'));
fprintf(fid4,'\n\n#define MAX_RESTART_ATTEMPTS\t\t %s\n#define SYSTEM_OPERATIONAL\t\t\t %s\n#define SYSTEM_RESTART_TIME\t\t\t %s',strcat(MaxRestartAttempts, 'u') ,strcat(SystemOperational, 'u'),strcat(SystemRestartTime, 'ul'));
if handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value==1
    fprintf(fid4,'\n\n#define MAINS_UV_FLT_THRESHOLD_CNTS\t\t\t %s\n#define MAINS_UV_FLT_HYSLIMIT_CNTS\t\t\t %s\n#define MAINS_UV_FLT_CNT_THRESHOLD\t\t\t %s\n#define MAINS_UV_FLT_CNT_HYSLIMIT\t\t\t %s',num2str(IPUVLimitCounts),num2str(IPUVHysCounts) ,strcat(IPUnderVoltageFaultenable),strcat(IPUnderVoltageFaultdisable));
end
if handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value==1
    fprintf(fid4,'\n\n#define MAINS_OV_FLT_THRESHOLD_CNTS\t\t\t %s',num2str(IPOVLimitCounts));
    fprintf(fid4,'\n#define MAINS_OV_FLT_HYSLIMIT_CNTS\t\t\t %s',num2str(IPOVHysCounts));
    fprintf(fid4,'\n#define MAINS_OV_FLT_CNT_THRESHOLD\t\t\t %s',strcat(IPoverVoltageFaultenable));
    fprintf(fid4,'\n#define MAINS_OV_FLT_CNT_HYSLIMIT\t\t\t %s',strcat(IPoverVoltageFaultdisable));
end
if handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value==1
    fprintf(fid4,'\n\n#define OUTPUT_UV_FLT_THRESHOLD_CNTS\t\t %s',num2str(OPUVLimitCounts));
    fprintf(fid4,'\n#define OUTPUT_UV_FLT_CNT_THRESHOLD\t\t\t %s',strcat(OPUnderVoltageFaultenable));
end
if handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value==1
    fprintf(fid4,'\n\n#define OUTPUT_OV_FLT_THRESHOLD_CNTS\t\t %s',num2str(OPOVLimitCounts));
    fprintf(fid4,'\n#define OUTPUT_OV_FLT_HYSLIMIT_CNTS\t\t\t %s',num2str(OPOVHysCounts));
    fprintf(fid4,'\n#define OUTPUT_OV_FLT_CNT_THRESHOLD\t\t\t %s',strcat(OPOverVoltageFaultenable));
    fprintf(fid4,'\n#define OUTPUT_OV_FLT_CNT_HYSLIMIT\t\t\t %s',strcat(OPOverVoltageFaultdisable));
end
if handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value==1
    fprintf(fid4,'\n\n#define OVR_POWER_FLT_THRESHOLD_CNTS\t\t %s',strcat(num2str(OPOPLimitCounts)));
    fprintf(fid4,'\n#define OVR_POWER_FLT_HYSLIMIT_CNTS\t\t\t %s',strcat(num2str(OPOPHysCounts)));
    fprintf(fid4,'\n#define OVR_POWER_FLT_CNT_THRESHOLD\t\t\t %s',strcat(OPOverPowerFaultEnable));
    fprintf(fid4,'\n#define OVR_POWER_FLT_CNT_HYSLIMIT\t\t\t %s',strcat(OPOverPowerLimitFaultDisable));
end

if handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value==1
    fprintf(fid4,'\n\n#define UNDER_FREQ_FLT_THRESHOLD_CNTS\t\t\t %s',num2str(IPUFLimitCounts));
    fprintf(fid4,'\n#define UNDER_FREQ_FLT_HYSLIMIT_CNTS\t\t\t %s',num2str(IPUFLimitHysCounts));
    fprintf(fid4,'\n#define UNDER_FREQ_FLT_CNT_THRESHOLD\t\t\t %s',strcat(LineUnderFreqfaultenable));
    fprintf(fid4,'\n#define UNDER_FREQ_FLT_CNT_HYSLIMIT\t\t\t\t %s',strcat(LineUnderFreqFaultdisable));
end
fprintf(fid4,'\n\n#define OVR_FREQ_FLT_THRESHOLD_CNTS\t\t\t %s',num2str(IPOFLimitCounts));
fprintf(fid4,'\n#define OVR_FREQ_FLT_HYSLIMIT_CNTS\t\t\t %s',num2str(IPOFLimitHysCounts));
fprintf(fid4,'\n#define OVR_FREQ_FLT_CNT_THRESHOLD\t\t\t %s',strcat(LineOverFrequencyLimitFaultenable));
fprintf(fid4,'\n#define OVR_FREQ_FLT_CNT_HYSLIMIT\t\t\t %s',strcat(LineOverFrequencyLimitfaultdisable));
if handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value==1
    fprintf(fid4,'\n\n#define RELAY_TURNON_THRESHOLD_CNTS\t\t\t %s',strcat(RelayTurnONLimit));
    fprintf(fid4,'\n#define RELAY_HYSLIMIT_CNTS\t\t\t\t\t %s',strcat(RelayTurnONLimitHys));
    fprintf(fid4,'\n#define RELAY_FLT_CNT_THRESHOLD\t\t\t\t  %s',strcat(RelayTurnONLimitfaultenable));
    fprintf(fid4,'\n#define RELAY_FLT_CNT_HYSLIMIT\t\t\t\t  %s',strcat(RelayTurnONLimitFaultdisable));
end
if handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value==1
    fprintf(fid4,'\n\n#define GENERIC_FLT1_THRESHOLD_CNTS\t\t\t %s',strcat(GenericParameter1Limit));
    fprintf(fid4,'\n#define GENERIC_FLT1_HYSLIMIT_CNTS\t\t\t %s',strcat(GenericParameter1LimitHys));
    fprintf(fid4,'\n#define GENERIC_FLT1_CNT_THRESHOLD\t\t\t  %s',strcat(GenericParameter1FaultEnable));
    fprintf(fid4,'\n#define GENERIC_FLT1_CNT_HYSLIMIT\t\t\t  %s',strcat(GenericParameter1FaultDisable));
end
if handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value==1
    fprintf(fid4,'\n\n#define GENERIC_FLT2_THRESHOLD_CNTS\t\t\t %s',strcat(GenericParameter2Limit));
    fprintf(fid4,'\n#define GENERIC_FLT2_HYSLIMIT_CNTS\t\t\t %s',strcat(GenericParameter2LimitHys));
    fprintf(fid4,'\n#define GENERIC_FLT2_CNT_THRESHOLD\t\t\t %s',strcat(GenericParameter2LimitFaultEnable));
    fprintf(fid4,'\n#define GENERIC_FLT2_CNT_HYSLIMIT\t\t\t %s',strcat(GenericParameter2LimitFaultDisable));
end
if handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value==1
    fprintf(fid4,'\n\n#define SOFT_START_DURATION\t\t\t %s',strcat(num2str(SoftStartDurationLimitP),'ul'));
    fprintf(fid4,'\n#define SOFT_START_CALLRATE\t\t\t %s',strcat(num2str(SoftStartCallRateP),'ul'));
end
if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
    fprintf(fid4,'\n\n#define BURST_MODE_EN_THRESHOLD\t\t\t %s',strcat(BurstModeEnableLimit));
    fprintf(fid4,'\n#define BURSTMODE_ENABLE_WATTS\t\t\t %s',strcat(BurstModeEnableLimitWatts));
    fprintf(fid4,'\n#define BURST_MODE_DIS_THRESHOLD\t\t %s',strcat(BurstModeDisableLimit));
    fprintf(fid4,'\n#define BURST_MODE_OFF_CYCLES\t\t\t %s',strcat(BurstModeOffCycles));
end
if handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value==1
    fprintf(fid4,'\n\n#define MAX_DITHER_FACTOR\t\t\t %s',strcat(num2str(MaxDitherFactor),'u'));
    fprintf(fid4,'\n#define MIN_DITHER_FACTOR\t\t\t %s',strcat(num2str(MinDitherFactor),'u'));
    fprintf(fid4,'\n#define DITHER_SCALEFACTOR\t\t\t %s',strcat(num2str(DitherScaleFactor),'u'));
end
if handles.IPT6.FeaturesConfiguration.XCapCompensation.Value==1
    fprintf(fid4,'\n\n#define XCAP_FREQ_GAIN\t\t\t %s',strcat(XCapFreqGain,'u'));
    fprintf(fid4,'\n#define XCAP_CURR_MAX_CNTS\t\t %s',strcat(XCapCurrMaxCnts,'u'));
    fprintf(fid4,'\n#define XCAP_VAC_ARRAY\t\t\t %s',strcat(XCapVacArray,'u'));
end

% fclose(fid4a);
fclose(fid4);
%%
msgbox('Header and xml Files generated and Saved!!');