function [NUMER,DENOM]=Append_TF_sys(TF)
[num,den] = tfdata(TF,'v');  

 NUMER = '';
                m = length(num);
                for i = 1:m-2
                    if num(i)~=0
                    NUMER = [ NUMER  num2str(num(i))  ' s^' num2str(m-i) ' + '];
                    end
                end
                NUMER= [ NUMER num2str(num(m-1))  's +'  num2str(num(m)) ];
               % numer = numer(1:end-3);
%                
 DENOM = '';
                n = length(den);
                for i = 1:n-2
                    if den(i)~=0
                    DENOM = [DENOM num2str(den(i)) ' s^' num2str(n-i) ' + '];
                    end
                end
                DENOM= [DENOM num2str(den(n-1)) 's +' num2str(den(n))];
                %denom = denom(1:end-3);
end