function GenerateProjectReport(hObject,~)
handles=guidata(hObject);
makeDOMCompilable(); 
import mlreportgen.report.*
import mlreportgen.dom.*
fileContents = fileread('Chap2_1.txt');
%% IPT1 Handles
TopologySel = handles.SpecificationsTab.SelectionDropdowns.TopologySelection.Value;
Topology = string(handles.SpecificationsTab.SelectionDropdowns.TopologySelection.String(TopologySel));                                                               
ControlMethodSel = handles.SpecificationsTab.SelectionDropdowns.ControlMethodSelection.Value;
ControlMethod = string(handles.SpecificationsTab.SelectionDropdowns.ControlMethodSelection.String(ControlMethodSel));

MinVoltage = handles.SpecificationsTab.CommonSpecs.VinMin.String;
OutputVoltage = handles.SpecificationsTab.CommonSpecs.Vout.String;
OutputPower = handles.SpecificationsTab.CommonSpecs.Pout.String;
Inductance = handles.SpecificationsTab.CommonSpecs.Inductor.Inductance.String;
Inductor_DCR = handles.SpecificationsTab.CommonSpecs.Inductor.DCR.String;
Capacitance = handles.SpecificationsTab.CommonSpecs.Capacitor.Capacitance.String;
Capacitor_ESR = handles.SpecificationsTab.CommonSpecs.Capacitor.ESR.String;
% PWMSwitchingFreq = handles.SpecificationsTab.CommonSpecs.PWMSwitchingFreq.Fsw.String;

FilePath = handles.SpecificationsTab.FilePath.BodeFilePath.String;

% OuterLoopPlant=handles.SpecificationsTab.PlantInfo.OL.PlantTF;

% Testbode = handles.bodeplot(bplot,OuterLoopPlant,bOptions);


%% IPT2 Handles

ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
ADCLat = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String;

Rfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String;
Rfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String;
Rfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String;
Cfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String;
Cfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String;

Rfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String;
Rfb5 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String;
Rfb6 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String;
Cfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String;
Cfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String;

Rfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String;
Rfb8 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String;
Cfb5 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String;
PrimaryTurnsRatioNp = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String;
SecondaryTurnsRatioNs = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String;

Rfb9 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String;
Rfb10 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String;
Rfb11 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String;
Cfb6 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String;
Rfb12 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String;
Cfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String;




%% IPT3 Handles

ILPWMFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String;
ILSampRatio = handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String;
ILPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String;
% ILMaxPWMSwitchingFreq = handles.ControllerDesignTab.PWMConfiguration.IL.MaxPWMSwitchingFreq.String;
% ILPWMResolution = handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String;
ILComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String;
ILGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String;
ILCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String;
ILPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String;
ILMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String;
ILMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String;

OLPWMFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String;
OLSampRatio = handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String;
OLPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String;
% OLMaxPWMSwitchingFreq = handles.ControllerDesignTab.PWMConfiguration.OL.MaxPWMSwitchingFreq.String;
% OLPWMResolution = handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String;
OLComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String;
OLGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String;
OLCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String;
OLPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String;
OLMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String;
OLMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String;

% Ki=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;

ILCompensatorSel =handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
ILCompensator = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.String(ILCompensatorSel));
ILGain = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain.String;
ILPole1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1.String;
ILPole2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2.String;
% ILPole3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole3.String;
ILZero1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1.String;
ILZero2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2.String;
% ILZero3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero3.String;

ILP1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1.String;
ILZ1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1.String;
ILKdc1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1.String;

ILP2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2.String;
ILZ2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2.String;
ILKdc2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2.String;

ILP3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3.String;
ILZ3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3.String;
ILKdc3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3.String;

OLCompensatorSel = handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;
OLCompensator = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.String(OLCompensatorSel));
OLGain = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain.String;
OLPole1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1.String;
OLPole2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2.String;
% OLPole3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole3.String;
OLZero1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1.String;
OLZero2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2.String;
% OLZero3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero3.String;

OLP1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1.String;
OLZ1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1.String;
OLKdc1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1.String;

OLP2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2.String;
OLZ2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2.String;
OLKdc2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2.String;

OLP3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3.String;
OLZ3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3.String;
OLKdc3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3.String;


%% handles for GPT3
if isempty(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1.String)
    
    errordlg('"Run" the application before chosing "Generate Project Report" ','Error');
    
    return;
    
end

% Absolute Coefficients IL
B0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0);
B1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B1);
B2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B2);
B3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B3);
B4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A0);
A1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A1);
A2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A2);
A3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A3);
A4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A4);
% 
% % Normalized Coefficients IL
B0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B0);
B1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B1);
B2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B2);
B3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B3);
B4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B4);

% A0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A0);
A1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A1);
A2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A2);
A3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A3);
A4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A4);
% 
%% Cascaded Coefficients IL
%% the following handles are create for header file genaration
%%
% A10_IL_C = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_IL_C =  string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostShift);
% 
% A20_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A20);
A21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A30);
A31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B31);

%IL Normalized Q15 Parameters
IL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.Normal);
IL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostShift);
IL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostScalar);

%%
% % Absolute Coefficients OL
B0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0);
B1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1);
B2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2);
B3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3);
B4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0);
A1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1);
A2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2);
A3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3);
A4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A4);
 
%% Normalized Coefficients OL
B0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0);
B1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1);
B2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2);
B3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3);
B4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B4);

% A0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0);
A1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1);
A2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2);
A3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3);
A4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A4);


%% Cascaded Coefficients OL
%%
% A10_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_OL_C  = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostShift);

% A20_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A20;
A21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A30;
A31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B31);

%OL Normalized Q15 Parameters
OL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.Normal);
OL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostShift);
OL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostScalar);
%% from the PlantTFComputation_PFC.m, this is to print the equations in the report generation

  GvdP = handles.SpecificationsTab.PlantInfo.OL.PlantTF; 
  GvcP = handles.SpecificationsTab.PlantInfo.Gvc.PlantTF ;
  GidP = handles.SpecificationsTab.PlantInfo.IL.PlantTF;
  GvifilterP = handles.FeedbackNetworkTab.FeedbackParameters.OL.IPFilterTF;
  GvofilterP = handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
  GciP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;% =Ki;Inner Loop Analaog Compensator
  Ki_c_cascadedP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog; % Inner Loop Analaog Cascaded Compensator
  GcoP = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog;%  = Kv;Outer Loop Analaog Compensator
  GifilterP = handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;% =GInnerLoopFilter; Current feedback TF
  GCLI_AP = handles.SpecificationsTab.PlantInfo.IL.ILCLTFAnalog; % =GCLI_A; Closed loop T/F Inner current loop Analog
  Gvl_D = handles.SpecificationsTab.PlantInfo.OL.LoopGainDigitalTF;
  Ki_dP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital;%=Ki_d; Inner loop Digital Compensator
  Ki_d_cascaded_sectionsP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Digital;
  Kv_dP =handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital;
  Kv_c_cascadedP = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Analog; 
  
  
%% Appedning Transfer function in the project report Generation
eq1 = Equation;
eq2 = Equation;   
eq3 = Equation;
eq4 = Equation;
eq5 = Equation;   
eq6 = Equation;
eq7 = Equation;
eq8 = Equation;   
eq9 = Equation;
eq10 = Equation;
eq11 = Equation;
eq12 = Equation;   
eq13 = Equation;
eq14 = Equation;   
eq15 = Equation;
eq16 = Equation;
eq17 = Equation;   
eq18 = Equation;
eq19 = Equation;   
eq20 = Equation;
[numer,denom] = Append_TF_sys(GidP);
eq1.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvcP);
eq2.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvdP);
%[numer,denom] = Append_TF1(GvdP);
eq3.Content = ['\frac{' numer '}{' denom '}'] ;
   % Gvifilter, I/P Voltage Measurement Network T/F
[numer,denom] = Append_TF_sys(GvifilterP);
eq4.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvofilterP);
eq5.Content = ['\frac{' numer '}{' denom '}'] 
[numer,denom] = Append_TF_sys(GciP);
eq6.Content = ['\frac{' numer '}{' denom '}'] 
 [numer,denom] = Append_TF_sys(GcoP);
  eq7.Content = ['\frac{' numer '}{' denom '}'] 
 [numer,denom] = Append_TF_sys(GifilterP);
 eq8.Content = ['\frac{' numer '}{' denom '}'];
[numer,denom]= Append_TF_sys (GCLI_AP);
 eq9.Content = ['\frac{' numer '}{' denom '}'] 
 GvcP_ZPK = zpk(GvcP);                                % T/F in S domain ZPK
 GvcP_ZPK.DisplayFormat = 'frequency';               % T/F ZPK 
[numer,denom]= Append_TF1(GvcP_ZPK)
eq10.Content = ['\frac{' numer '}{' denom '}']; % In LaTex format
[numer1 denom1 numer2 denom2 numer3 denom3]= Append_TF_CASCADED(Ki_c_cascadedP);
eq11.Content = ['\frac{' numer1 '}{' denom1 '}']% In LaTex format
eq12.Content = ['\frac{' numer2 '}{' denom2 '}']% In LaTex format
eq13.Content = ['\frac{' numer3 '}{' denom3 '}']% In LaTex format
[numer1 denom1 numer2 denom2 ]= Append_TF_CASCADED_2eq(Kv_c_cascadedP);
eq14.Content = ['\frac{' numer1 '}{' denom2 '}'];% In LaTex format
eq15.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
% eq405.Content = ['\frac{' numer6 '}{' denom6 '}']% In LaTex format
[numer1 denom1 numer2 denom2 numer3 denom3]= Append_TF_CASCADED(Ki_d_cascaded_sectionsP);
eq16.Content = ['\frac{' numer1 '}{' denom1 '}']% In LaTex format
eq17.Content = ['\frac{' numer2 '}{' denom2 '}']% In LaTex format
eq18.Content = ['\frac{' numer3 '}{' denom3 '}']% In LaTex format
[numer1 denom1 numer2 denom2 ]= Append_TF_CASCADED_2eq(Kv_c_cascadedP);
eq19.Content = ['\frac{' numer1 '}{' denom2 '}'];% In LaTex format
eq20.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
%% Report Generation test
% https://in.mathworks.com/help/rptgen/ug/create-a-report-program.html
% https://in.mathworks.com/help/rptgen/ug/what-is-a-reporter.html
%% Example 2
%% (Important Link): https://in.mathworks.com/company/newsletters/articles/building-deployable-applications-for-evaluating-pkpd-drug-efficacy.html
%%  https://in.mathworks.com/help/rptgen/ug/mlreportgen.report.chapter-class.html
% rpt = mlreportgen.report.Report('PSDS','pdf');
% rpt = Document('PSDS','pdf');
% open(rpt);
% [fileName,pathName] = uiputfile2('PSDS.PDF');
% file_path = fullfile(pathName,fileName);
% report ('simple-report',strcat('-o',file_path))
rpt = Report('PSDS','pdf');
% getMainPartPath(rpt)
NL = newline();

add(rpt,TitlePage ('Title','PowerSmart� Development Suite',...
                   'Author','Microchip Technology Inc'))

% NL = newline();
% add(rpt,mlreportgen.report.TitlePage('Title','PowerSmart� Development Suite',...
%                                      'Author','Microchip Technology Inc'))

image = FormalImage();
image.Image = which('MCHPTitle.png');
add(rpt,image); 

% image = FormalImage();
% image.Image = which('Testbode');
% add(rpt,image); 

add(rpt,mlreportgen.report.TableOfContents)
%% Chapter1

ch1 = mlreportgen.report.Chapter('Title','Introduction');
% add(ch1,mlreportgen.dom.Text...
%    ('Power Factor Correction - an important concept imposed by regulatory standards'))

%% Adding text in Chapter 1
fid = fopen('Introduction.txt','rt');
Introduction = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
add(ch1,Introduction );
add(rpt,ch1);

%% Chapter2

ch2 = mlreportgen.report.Chapter('Title','User Design Inputs');
% add(ch2,mlreportgen.dom.Text...
%    ('Power Factor Correction'))
% add(rpt,ch1)
%%
para200 = Paragraph(sprintf('This chapter discusses about the design values given by the user for power factor correction.'));        
para0 = Paragraph(sprintf('Chosen Power factor Correction Topology is %s ', Topology));
para1 = Paragraph(sprintf('Chosen Control Method is %s',ControlMethod));
para1.WhiteSpace='preserve';
para202 = Paragraph(sprintf('Table2.1 shows the user entered design inputs'));
para201 = Paragraph(sprintf('Power stage parameters are listed below in Table2.1'));        
para201.WhiteSpace='preserve';
para203 = Paragraph(sprintf('Transfer Functions for the Power stage parameters listed in Table2.1')); 
para202.WhiteSpace='preserve';
para204 = Paragraph(sprintf(' Transfer Function between Duty to Inductor Current , Inner Loop Transfer Function (Gid), ')); 
para203.WhiteSpace='preserve';
para205 = Paragraph(sprintf(' Transfer Function between Control to Output Voltage, Outer Loop Transfer Function (Gvc), ')); 
para204.WhiteSpace='preserve';
para206 = Paragraph(sprintf(' Transfer Function between Duty to Output Voltage, Outer Loop Transfer Function (Gvd), ')); 
para205.WhiteSpace='preserve';
para207 = Paragraph(sprintf(' Bode Plot of Outer Loop Transfer Function (Gvd)')); 
para207.Bold = true;
para206.WhiteSpace='preserve';
para208 = Paragraph(sprintf(' Bode Plot of Inner Loop Transfer Function (Gid)')); 
para208.Bold = true;
para207.WhiteSpace='preserve';
para209 = Paragraph(sprintf(' Bode Plot of Control to Output Voltage Loop Transfer Function (Gvc)')); 
para209.Bold = true;
para208.WhiteSpace='preserve';
para210 = Paragraph(sprintf(' Bode Plot of IputVoltage Sensing network (Gvifilter)')); 
para210.Bold = true;
para209.WhiteSpace='preserve'
para211 = Paragraph(sprintf(' Bode Plot of OutputVoltage Sensing network (Gvofilter)')); 
para211.Bold = true;
para210.WhiteSpace='preserve'
para212 = Paragraph(sprintf(' Bode Plot of Current Sensing network (GifilterP)')); 
para212.Bold = true;
para211.WhiteSpace='preserve'
para213 = Paragraph(sprintf(' Chosen Topology High Level Circuit Schematic')); 
para213.Bold = true;
para212.WhiteSpace='preserve'
para214 = Paragraph(sprintf(' Closed Loop Transfer Function - Inner Loop Analog')); 
para214.Bold = true;
para213.WhiteSpace='preserve'
para215 = Paragraph(sprintf('Outer Loop Transfer Function (Gvc) in Pole Zero form'));
para215.Bold = true;
para214.WhiteSpace='preserve'
para216 = Paragraph(sprintf('Bode plot of Closed Loop Transfer Function - Inner Loop Analog'));
para216.Bold = true;
para215.WhiteSpace='preserve'

% para0.WhiteSpace = 'preserve';
% para1.WhiteSpace = 'preserve';
% para10 = Paragraph(sprintf('Input AC Voltage (Vin)  \t%s \t Vrms',MinVoltage));
% para11 = Paragraph(sprintf('Output DC Voltage (Vdc) %s Vdc',OutputVoltage));
% para12 = Paragraph(sprintf('Output Power (Po)  %s Watts',OutputPower));
% para13 = Paragraph(sprintf('Inductance (L1 = L2)  %s uH',Inductance));
% para14 = Paragraph(sprintf('DC Resistance (DCR)  %s mOhm',Inductor_DCR));
% para15 = Paragraph(sprintf('Capacitance (Co)  %s uF',Capacitance));
% para16 = Paragraph(sprintf('Capacitor (Co) ESR   %s mOhm',Capacitor_ESR));
% para17 = Paragraph(sprintf('PWM Switching Frequency Max (Fsw)  %s KHz',PWMSwitchingFreq));

%% Comment: Selected Topology and Control Method
add(ch2,para200);
add(ch2,para0);
add(ch2,para1);
append(para1,NL);
add(ch2,para213);
para213.Bold = true;
append(para213,NL);
switch TopologySel
    case 1
    img9 = FormalImage();
    img9.Image = which('SinglePhasePFCCkt.png');
    add(ch2, img9);
    case 2
    img10 = FormalImage();
    img10.Image = which('InterleavedPFCCkt.png');
    add(ch2, img10);
    case 3
    img11 = FormalImage();
    img11.Image = which('SemiBridgelessLPFCCkt.png');
    add(ch2, img11);
end   
  
para1.WhiteSpace='preserve';
add(ch2,para202);
add(ch2,para201);
para201.WhiteSpace='preserve';
append(para1,NL);
%% Comment: User Entered Design Specifications in tabel format (Table 1)
%% https://in.mathworks.com/help/rptgen/ug/create-a-dynamic-table.html   ---- Imp link work on this

%% Table1 Power Stage Parameters
%%
table1 = Table(4);
table1.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table1.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table1,row);

for i=1:7
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Input AC Voltage (Vin)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',MinVoltage)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Vrms']));
            append(row,te);

            append(table1,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Output DC Voltage (Vdc)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OutputVoltage)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Vdc']));
            append(row,te);

            append(table1,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Output Power (Po)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OutputPower)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Watts']));
            append(row,te);

            append(table1,row);
        end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Inductance (L1 = L2) ']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Inductance)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['uH']));
            append(row,te);

            append(table1,row);
        end
        
        if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['DC Resistance (DCR)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Inductor_DCR)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['mOhm']));
            append(row,te);

            append(table1,row);
        end    
        
      if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Capacitance (Co)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Capacitance)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['uF']));
            append(row,te);

            append(table1,row);
      end    
        
       if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Capacitor(Co)ESR']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Capacitor_ESR)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['mOhm']));
            append(row,te);

            append(table1,row);
        end 
        
end

add (ch2, table1);
add (ch2,para204);
add (ch2,eq1);          % Gid T.F
add (ch2,para206);
add (ch2,eq3);          % Gvd T.F
add (ch2,para205);
add (ch2,eq2);          % Gvc T.F
add (ch2,para215);
add(ch2,eq10);          % Gvc in ZPK

%% Plant TF Bode plot
%% Bode Options
    bOptions=bodeoptions;
    bOptions.Grid='on';
    bOptions.FreqUnits='Hz';
    bOptions.PhaseWrapping = 'on' ;
    bOptions.MagUnits = 'dB';

fig3 = figure;
GvdPBode = bodeplot(GvdP,bOptions);
%  h1 = findobj(handles.UserBodeResponseTab.Subplot1.axis,'type','axes');
%  h3 = bodeplot(bplot,GvdP,bOptions); % GvdPBode
h3 = findobj(GvdPBode,'type','axes');
% h3 = findobj(handles.PlotsTab.PlotsAxes.BodePlotAx,'type','axes');
% h4 = findobj(handles.PlotsTab.PlotsAxes.BodePlotAx,'type','axes');
copyobj(h3,fig3);
saveas(fig3,'Outer_Loop_Bode_Plot(Gvd).png');
close(fig3);
img3 = Image('Outer_Loop_Bode_Plot(Gvd).png');
img3.Style = {Height('3.5in'),Width('7in')};
add (ch2,para207);
add(ch2, img3);

fig4 = figure;
GidPBode = bodeplot(GidP,bOptions);
h4 = findobj(GidPBode,'type','axes');
copyobj(h4,fig4);
saveas(fig4,'Inner_Loop_Bode_Plot(Gid).png');
close(fig4);
img4 = Image('Inner_Loop_Bode_Plot(Gid).png');
img4.Style = {Height('3.5in'),Width('7in')};
add (ch2,para208);
add(ch2, img4);

fig5 = figure;
GvcPBode = bodeplot(GvcP,bOptions);
h5 = findobj(GvcPBode,'type','axes');
copyobj(h5,fig5);
saveas(fig5,'GvcPBodeplot.png');
close(fig5);
img5 = Image('GvcPBodeplot.png');
img5.Style = {Height('3.5in'),Width('7in')};
add (ch2,para209);
add(ch2, img5);

%% Plant Bode end
%%
para7 = Paragraph(sprintf('User Entered Feedback Network Parameters'));
add(ch2,para7);
para7.Bold = true;
para8 = Paragraph(sprintf('PFC control system needs Input Voltage measurement, Output Voltage measurement and Current measurement values and Table2.2 shows the user entered feedback network design parameters'));
add(ch2,para8);

%% Table2 Input voltage measurements feedback parameters
para13 = Paragraph(sprintf('Input Voltage Measurement network parameters are listed below in Table 2.2'));
add(ch2,para13);
append(para13,NL);

table2 = Table(4);
table2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table2.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table2,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb1)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table2,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb2)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table2,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb3)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table2,row);
        end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb1 ']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb1)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table2,row);
        end
        
        if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb2)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table2,row);
        end          
end

add (ch2, table2);
NL = newline();

para9 = Paragraph(sprintf('Input Voltage Measurement Network Transfer Function (Gvifilter)'));
add(ch2,para9);
add (ch2,eq4);          % Gvifilter T.F

fig6 = figure;
GvifilterPBode = bodeplot(GvifilterP,bOptions);
h6 = findobj(GvifilterPBode,'type','axes');
copyobj(h6,fig6);
saveas(fig6,'Gvifilter.png');
close(fig6);
img6 = Image('Gvifilter.png');
img6.Style = {Height('3.5in'),Width('7in')};
add (ch2,para210);
add(ch2, img6);


%% Table3 Output voltage measurements(feedback parameters)

para20 = Paragraph(sprintf('Output voltage measurement network parameters are listed below in Table2.3'));
add(ch2,para20)
append(para20,NL);

table3 = Table(4);
table3.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table3.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table3,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb4)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table3,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb5']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb5)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table3,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb6']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb6)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table3,row);
        end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb3 ']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb3)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table3,row);
        end
        
        if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb4)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table3,row);
        end           
end

add (ch2, table3);

para10 = Paragraph(sprintf('Output Voltage Measurement Network Transfer Function (Gvofilter)'));
add(ch2,para10);
add (ch2,eq5);          % Gvofilter T.F

fig7 = figure;
GvofilterPBode = bodeplot(GvofilterP,bOptions);
h7 = findobj(GvofilterPBode,'type','axes');
copyobj(h7,fig7);
saveas(fig7,'Gvofilter.png');
close(fig7);
img7 = Image('Gvofilter.png');
img7.Style = {Height('3.5in'),Width('7in')};
add (ch2,para211);
add(ch2, img7);

if  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value==1

    para119 = Paragraph(sprintf('Current measurement can be done either by current transformer or by shunt resistor'));
    add (ch2,para119);
    para120 = Paragraph(sprintf('\n Here current measurement is done by current transformer and the parameters are as shown in Table2.4'));
    add(ch2,para120)
    append(para120,NL);

table24 = Table(4);
table24.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table24.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table24,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb7']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb7)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table24,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb8']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb8)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table24,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb5']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb5)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table24,row);
        end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Primary Turns Ratio']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',PrimaryTurnsRatioNp)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['-']));
            append(row,te);

            append(table24,row);
        end
        
        if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Secondary Turns Ratio']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',SecondaryTurnsRatioNs)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['-']));
            append(row,te);

            append(table24,row);
        end            
end

add (ch2, table24);

para11 = Paragraph(sprintf('Current Measurement Network Transfer Function (Gifilter)'));
add(ch2,para11);
add (ch2,eq8);          % Gifilter T.F

fig8 = figure;
GifilterPBode = bodeplot(GifilterP,bOptions);
h8 = findobj(GifilterPBode,'type','axes');
copyobj(h8,fig8);
saveas(fig8,'GifilterP.png');
close(fig8);
img8 = Image('GifilterP.png');
img8.Style = {Height('3.5in'),Width('7in')};
add (ch2,para212);
add(ch2, img8);


elseif  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value==1

    
    para119 = Paragraph(sprintf('Current measurement can be done either by current transformer or by shunt resistor'));
    add (ch2,para119);
    para121 = Paragraph(sprintf('Here current measurement is done by shunt resistor and the parameters are as shown in Table2.4'));
    add(ch2,para121)
    append(para121,NL);

table25 = Table(4);
table25.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table25.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table25,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb9']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb9)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table25,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb10']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb10)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table25,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb11']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb11)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table25,row);
        end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb6 ']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb6)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table25,row);
        end
        
        if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cfb7']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Cfb7)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['pF']));
            append(row,te);

            append(table25,row);
        end    
        
        if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Rfb12']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',Rfb12)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kOhm']));
            append(row,te);

            append(table25,row);
        end
end

add (ch2, table25);

para11 = Paragraph(sprintf('Current Measurement Network Transfer Function (Gifilter)'));
add(ch2,para11);
add (ch2,eq8);          % Gifilter T.F

fig8 = figure;
GifilterPBode = bodeplot(GifilterP,bOptions);
h8 = findobj(GifilterPBode,'type','axes');
copyobj(h8,fig8);
saveas(fig8,'GifilterP.png');
close(fig8);
img8 = Image('GifilterP.png');
img8.Style = {Height('3.5in'),Width('7in')};
add (ch2,para212);
add(ch2, img8);
        
end

%% Table4 Control system inputs for the innerloop

para29 = Paragraph(sprintf('The Control System Design Parameters'));
para29.Bold = true;
add(ch2,para29)
append(para29,NL);

para30 = Paragraph(sprintf('The control system design inputs chosen by user for the innerloop compensator are listed below in Table2.5'));
add(ch2,para30)
append(para30,NL);

table4 = Table(4);
table4.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table4.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table4,row);

for i=1:9
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['PWM Switching frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILPWMFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kHz']));
            append(row,te);

            append(table4,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Sampling Ratio']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILSampRatio)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['-']));
            append(row,te);

            append(table4,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['PWM Sampling Frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILPWMSampFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kHz']));
            append(row,te);

            append(table4,row);
        end
        
%         if i == 4
%             row = TableRow();
% 
%             te = TableEntry();
%             append(te,Text([num2str(i) ]));
%             append(row,te);
% 
%             te = TableEntry();
%             append(te,Text(['Maximum PWM Switching Frequency']));
%             append(row,te);
% 
%             te = TableEntry();
%             append(te,Paragraph(sprintf('%s',ILMaxPWMSwitchingFreq)));
%             append(row,te);
% 
%             te = TableEntry();
%             append(te,Text(['kHz']));
%             append(row,te);
% 
%             append(table4,row);
%         end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Computational Delay']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILComputationalDelay)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['ns']));
            append(row,te);

            append(table4,row);
        end    
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gate Drive Delay']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILGateDriveDelay)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['ns']));
            append(row,te);

            append(table4,row);
      end    
        
       if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cross Over Frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILCrossOverFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Hz']));
            append(row,te);

            append(table4,row);
       end 
        
       if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Phase Margin']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILPhaseMargin)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['deg']));
            append(row,te);

            append(table4,row);
       end 
        
       if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Control Output(Min)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILMinControlOutput)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['']));
            append(row,te);

            append(table4,row);
       end 
        
       if i == 10
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Control Output(Max)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILMaxControlOutput)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['']));
            append(row,te);

            append(table4,row);
        end 
        
end

add (ch2, table4);

para28 = Paragraph(sprintf('The Inner Loop Continious Time Domain Compensator Transfer Function'));
para28.Bold = true;
add(ch2,para28)
append(para28,NL);

image1 = FormalImage();
image1.Image = which('3P3ZGP.png');
add(ch2,image1); 

para27 = Paragraph(sprintf('Computed Inner Loop Continious Time Domain Compensator Transfer Function'));
para27.Bold = true;
add(ch2,para27)
append(para27,NL);
add (ch2,eq6);          % Computed Inner Loop Continious Time Domain Transfer Function


%% Inner Loop Compensator Pole, Zero and Gain values In Table format
para45  = Paragraph(sprintf('The Pole, Zero and Gain parameters for inner loop compensator are as follows'));
para45.Bold = true;
add(ch2,para45);
append(para45,NL);

table16 = Table(3);
table16.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table16.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table16,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILGain )));
            append(row,te);
            append(table16,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILPole1)));
            append(row,te);
            append(table16,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILPole2)));
            append(row,te);
            append(table16,row);
          end  
        
          if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILZero1)));
            append(row,te);
            append(table16,row);
          end 
        
          if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILZero2)));
            append(row,te);
            append(table16,row);
        end 
end

add (ch2, table16);
add (ch2,para214);
append(para214,NL);
add (ch2,eq9);

fig12 = figure;         % Bode plot of Closed Loop Transfer Function - Inner Loop Analog
GCLI_APBode = bodeplot(GCLI_AP,bOptions);
h12 = findobj(GCLI_APBode,'type','axes');
copyobj(h12,fig12);
saveas(fig12,'GCLI_AP.png');
close(fig12);
img12 = Image('GCLI_AP.png');
img12.Style = {Height('3.5in'),Width('7in')};
add (ch2,para216);
add(ch2, img12);

%% Inner Loop Cascaded Compensator Pole, Zero and Gain values in Table
para26 = Paragraph(sprintf('Cascaded Continious Time Domain Compensator Transfer Function'));
para26.Bold = true;
add(ch2,para26)
append(para26,NL);

image1 = FormalImage();
image1.Image = which('CASCADEDGP.png');
add(ch2,image1); 

para46  = Paragraph(sprintf('Pole, Zero and Gain Parameters for inner loop cascaded controller are as follows'));
para46.Bold = true;
para47  = Paragraph(sprintf('Cascaded Controller1'));
add(ch2,para46);
add(ch2,para47);
append(para47,NL);
append(para46,NL);

table17 = Table(3);
table17.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table17.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table17,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILKdc1_cascaded)));
            append(row,te);
            append(table17,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILP1_cascaded)));
            append(row,te);
            append(table17,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILZ1_cascaded)));
            append(row,te);
            append(table17,row);
        end  
end

add (ch2, table17);

para48  = Paragraph(sprintf('Cascaded Controller2'));
add(ch2,para48);
append(para48,NL);
append(para46,NL);

table18 = Table(3);
table18.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table18.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table18,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILKdc2_cascaded)));
            append(row,te);
            append(table18,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILP2_cascaded)));
            append(row,te);
            append(table18,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILZ2_cascaded)));
            append(row,te);
            append(table18,row);
        end  
end

add (ch2, table18);

para49  = Paragraph(sprintf('Cascaded Controller3'));
add(ch2,para49);
append(para49,NL);
append(para46,NL);

table19 = Table(3);
table19.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table19.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table19,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILKdc3_cascaded)));
            append(row,te);
            append(table19,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILP3_cascaded)));
            append(row,te);
            append(table19,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',ILZ3_cascaded)));
            append(row,te);
            append(table19,row);
        end  
end

add (ch2, table19);

%%  cascaded equations Analog Inner loop
para61  = Paragraph(sprintf('Inner loop Continious Cascaded Controller Transfer Function'));
para61.Bold = true;
add(ch2,para61);
add(ch2,eq11);
add(ch2,eq12);
add(ch2,eq13);

%% Table5 Outer loop Design input parameters
% break = PageBreak();         %% creates a page break object. 
para40 = Paragraph(sprintf('\n The control system inputs for the outerloop are listed below in Table2.5\n\n\n'));
para40.Bold = true;
add(ch2,para40);
append(para40,NL);

table5 = Table(4);
table5.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table5.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(table5,row);

for i=1:10
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['PWM Switching frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLPWMFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kHz']));
            append(row,te);

            append(table5,row);
        end
        
        if i == 2    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Sampling Ratio']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLSampRatio)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['']));
            append(row,te);

            append(table5,row);
        end  
        
        if i == 3    
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['PWM Sampling Frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLPWMSampFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['kHz']));
            append(row,te);

            append(table5,row);
        end
        
%         if i == 4
%             row = TableRow();
% 
%             te = TableEntry();
%             append(te,Text([num2str(i) ]));
%             append(row,te);

%             te = TableEntry();
%             append(te,Text(['Maximum PWM Switching Frequency']));
%             append(row,te);
% 
%             te = TableEntry();
%             append(te,Paragraph(sprintf('%s',OLMaxPWMSwitchingFreq)));
%             append(row,te);
% 
%             te = TableEntry();
%             append(te,Text(['kHz']));
%             append(row,te);

%             append(table5,row);
%         end
        
        if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Computational Delay']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLComputationalDelay)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['ns']));
            append(row,te);

            append(table5,row);
        end    
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gate Drive Delay']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLGateDriveDelay)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['ns']));
            append(row,te);

            append(table5,row);
      end    
        
       if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Cross Over Frequency']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLCrossOverFreq)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Hz']));
            append(row,te);

            append(table5,row);
       end 
        
       if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Phase Margin']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLPhaseMargin)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['deg']));
            append(row,te);

            append(table5,row);
       end 
        
       if i == 8
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Control Output(Min)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLMinControlOutput)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['']));
            append(row,te);

            append(table5,row);
       end 
        
       if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Control Output(Max)']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLMaxControlOutput)));
            append(row,te);

            te = TableEntry();
            append(te,Text(['']));
            append(row,te);

            append(table5,row);
        end 
        
end

add (ch2, table5);

para26 = Paragraph(sprintf('The Outer Loop Continious Time Domain Compensator Transfer Function'));
para26.Bold = true;
add(ch2,para26)
append(para26,NL);

image1 = FormalImage();
image1.Image = which('2P2ZGP.png');
add(ch2,image1); 

para25 = Paragraph(sprintf('Computed Outer Loop Continious Time Domain Compensator Transfer Function'));
para25.Bold = true;
add(ch2,para25)
append(para25,NL);
add (ch2,eq7);          % Computed Outer Loop Continious Time Domain Compensator Transfer Function

% append(table5,NL);

%%
para100  = Paragraph(sprintf('The transfer function parameters for outer loop compensator are as follows'));
para100.Bold = true;
add(ch2,para100);
append(para100,NL);

table20 = Table(3);
table20.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table20.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table20,row);

for i=1:5
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLGain )));
            append(row,te);
            append(table20,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLPole1)));
            append(row,te);
            append(table20,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLPole2)));
            append(row,te);
            append(table20,row);
          end  
        
          if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLZero1)));
            append(row,te);
            append(table20,row);
          end 
        
          if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLZero2)));
            append(row,te);
            append(table20,row);
        end 
end

add (ch2, table20);


para101  = Paragraph(sprintf('The transfer function parameters for outer loop cascaded controller are as follows'));
para101.Bold = true;
para102  = Paragraph(sprintf('Cascaded Controller1'));
add(ch2,para101);
add(ch2,para102);
append(para102,NL);
append(para101,NL);

table21 = Table(3);
table21.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table21.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table21,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLKdc1_cascaded)));
            append(row,te);
            append(table21,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLP1_cascaded)));
            append(row,te);
            append(table21,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLZ1_cascaded)));
            append(row,te);
            append(table21,row);
        end  
end

add (ch2, table21);

para103  = Paragraph(sprintf('Cascaded Controller2'));
add(ch2,para103);
append(para103,NL);

table22 = Table(3);
table22.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table22.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table22,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLKdc2_cascaded)));
            append(row,te);
            append(table22,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLP2_cascaded)));
            append(row,te);
            append(table22,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLZ2_cascaded)));
            append(row,te);
            append(table22,row);
        end  
end

add (ch2, table22);

para104  = Paragraph(sprintf('Cascaded Controller3'));
add(ch2,para104);
append(para104,NL);
append(para101,NL);

table23 = Table(3);
table23.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table23.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table23,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Gain']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLKdc3_cascaded)));
            append(row,te);
            append(table23,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Pole']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLP3_cascaded)));
            append(row,te);
            append(table23,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Zero']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OLZ3_cascaded)));
            append(row,te);
            append(table23,row);
        end  
end

add (ch2, table23);

%%  cascaded equations Analog Outer loop
para62  = Paragraph(sprintf('Outer loop Continious Cascaded Controller Transfer Function'));
para62.Bold = true;
add(ch2,para62);
add(ch2,eq14);
add(ch2,eq15);
add(rpt,ch2);

%% Chapter3

ch3 = mlreportgen.report.Chapter('Title','Digital Coefficients');

%% Table6 Digital coefficients (Inner loop)

para50  = Paragraph(sprintf('Discretization of controller'));
para50.Bold = true;
para51  = Paragraph(sprintf('In order to translate the S- Domain transfer function of the controller to a form acceptable to a digital controller the bilinear, or �Tustin� transformation is used. Using this transformation, the S � domain transfer function can be converter to Z- domain transfer function. By taking inverse Z � Transform of this Z - domain transfer function we obtain the equation of the compensator which can be programmed into the Digital Signal Controller (DSC).'));
add(ch3,para51);
para52  = Paragraph(sprintf('The expression relating the complex frequencies �S� and �Z� is given by   Z = e^(s*Ts)and This expression can be approximated using Pade�s approximation,' ));
add(ch3,para52);

    img13 = FormalImage();
    img13.Image = which('PadeApprox.png');
    add(ch3, img13);    
    img14 = FormalImage();
    img14.Image = which('Tustin.png');
    add(ch3, img14);    
    para53  = Paragraph(sprintf('Substituting the Tustin transformation equation into  Continious Time Domain Compensator Transfer Function' ));
    add(ch3,para53); 
    img15 = FormalImage();
    img15.Image = which('Z_Transferfunction.png');
    add(ch3,img15);
    para54  = (sprintf('e = present voltage error\n\n     y = present output    e[n-1] = previous error      e[n-2] = Error previous to e[n-1]    e[n-3] = Error previous to e[n-2]       y[n-1]  = previous output     y[n-2] = Output previous to y[n-1]    y[n-3] = Output previous to y[n-2]      a0, a1, a2, a3, b1, b2, b3 are coefficients of the digital compensator'));
    add(ch3,para54);    
    

para59  = Paragraph(sprintf('Innerloop Digital Coeficients'));
para59.Bold = true;
para60  = Paragraph(sprintf('Absolute Coefficients are '));
para60.Bold = true;
add(ch3,para59);
add(ch3,para60);
append(para59,NL);
append(para60,NL);

table6 = Table(3);
table6.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table6.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table6,row);

for i=1:9
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A1_Abs_IL_H)));
            append(row,te);
            append(table6,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A2_Abs_IL_H)));
            append(row,te);
            append(table6,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A3_Abs_IL_H)));
            append(row,te);
            append(table6,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A4_Abs_IL_H)));
            append(row,te);
            append(table6,row);
      end 
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b0']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B0_Abs_IL_H)));
            append(row,te);
            append(table6,row);
      end   
      
           if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B1_Abs_IL_H)));
            append(row,te);
            append(table6,row);
           end      
      
     if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B2_Abs_IL_H)));
            append(row,te);
            append(table6,row);
     end   
           
     if i == 8
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B3_Abs_IL_H)));
            append(row,te);
            append(table6,row);
     end     
     
        if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B4_Abs_IL_H)));
            append(row,te);
            append(table6,row);
        end     
     
end

add (ch3, table6);
para70  = Paragraph(sprintf('Normalized Coefficients are '));
para70.Bold = true;
add(ch3,para70);
append(para70,NL);

table7 = Table(3);
table7.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table7.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table7,row);

for i=1:12
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A1_Norm_IL_H)));
            append(row,te);
            append(table7,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A2_Norm_IL_H)));
            append(row,te);
            append(table7,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A3_Norm_IL_H)));
            append(row,te);
            append(table7,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A4_Norm_IL_H)));
            append(row,te);
            append(table7,row);
      end 
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b0']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B0_Norm_IL_H)));
            append(row,te);
            append(table7,row);
      end   
      
           if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B1_Norm_IL_H)));
            append(row,te);
            append(table7,row);
           end      
      
     if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B2_Norm_IL_H)));
            append(row,te);
            append(table7,row);
     end   
           
     if i == 8
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B3_Norm_IL_H)));
            append(row,te);
            append(table7,row);
     end     
     
        if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B4_Norm_IL_H)));
            append(row,te);
            append(table7,row);
        end     
     if i == 10
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Normal']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',IL_Norm_Normal)));
            append(row,te);
            append(table7,row);
     end 
        
          if i == 11
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Shift']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',IL_Norm_PostShift)));
            append(row,te);
            append(table7,row);
          end 
        
        if i == 12
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Scalar']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',IL_Norm_PostScalar)));
            append(row,te);
            append(table7,row);
        end 
end

add (ch3, table7);

%% Adding equation image
para43 = Paragraph(sprintf('The Inner Loop Compensator Digital Transfer Function is '));
para43.Bold = true;
add(ch3,para43)
% append(para43,NL);
% append(para43,NL);

image1 = FormalImage();
image1.Image = which('DIGITAL CASCADED TRANSFER FUNCTION GP.png');
add(ch3,image1); 



para71  = Paragraph(sprintf('Cascaded Coefficients are '));
para71.Bold = true;
para72  = Paragraph(sprintf('Compensator1'));
para72.Bold = true;
add(ch3,para71);
add(ch3,para72);
append(para71,NL);
append(para72,NL);

table8 = Table(3);
table8.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table8.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table8,row);

for i=1:4
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a11']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A11_IL_C)));
            append(row,te);
            append(table8,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b10']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B10_IL_C)));
            append(row,te);
            append(table8,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b11']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B11_IL_C)));
            append(row,te);
            append(table8,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Shift']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',PS_IL_C)));
            append(row,te);
            append(table8,row);
      end 
end

add (ch3, table8);

%%
para73  = Paragraph(sprintf('Compensator2'));
para73.Bold = true;
add(ch3,para73);
append(para73,NL);

table9 = Table(3);
table9.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table9.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table9,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a21']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A21_IL_C)));
            append(row,te);
            append(table9,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b20']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B20_IL_C)));
            append(row,te);
            append(table9,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b21']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B21_IL_C)));
            append(row,te);
            append(table9,row);
        end  
end

add (ch3, table9);

%%
para74  = Paragraph(sprintf('Compensator3'));
para74.Bold = true;
add(ch3,para74);
append(para74,NL);

table10 = Table(3);
table10.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table10.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table10,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a31']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A31_IL_C)));
            append(row,te);
            append(table10,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b30']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B30_IL_C)));
            append(row,te);
            append(table10,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b31']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B31_IL_C)));
            append(row,te);
            append(table10,row);
        end  
end

add (ch3, table10);


%% Table11 Digital coefficients (Outer loop)
para89  = Paragraph(sprintf('Outerloop Digital Coeficients'));
para89.Bold = true;
para90  = Paragraph(sprintf('Absolute Coefficients are '));
para90.Bold = true;
add(ch3,para89);
add(ch3,para90);
append(para89,NL);
append(para90,NL);

table11 = Table(3);
table11.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table11.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table11,row);

for i=1:9
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A1_Abs_OL_H)));
            append(row,te);
            append(table11,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A2_Abs_OL_H)));
            append(row,te);
            append(table11,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A3_Abs_OL_H)));
            append(row,te);
            append(table11,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A4_Abs_OL_H)));
            append(row,te);
            append(table11,row);
      end 
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b0']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B0_Abs_OL_H)));
            append(row,te);
            append(table11,row);
      end   
      
           if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B1_Abs_OL_H)));
            append(row,te);
            append(table11,row);
           end      
      
     if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B2_Abs_OL_H)));
            append(row,te);
            append(table11,row);
     end   
           
     if i == 8
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B3_Abs_OL_H)));
            append(row,te);
            append(table11,row);
     end     
     
        if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B4_Abs_OL_H)));
            append(row,te);
            append(table11,row);
        end     
     
end

add (ch3, table11);

para91  = Paragraph(sprintf('Normalized Coefficients are '));
para91.Bold = true;
add(ch3,para91);
append(para91,NL);

table12 = Table(3);
table12.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table12.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table12,row);

for i=1:12
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A1_Norm_OL_H)));
            append(row,te);
            append(table12,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A2_Norm_OL_H)));
            append(row,te);
            append(table12,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A3_Norm_OL_H)));
            append(row,te);
            append(table12,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A4_Norm_OL_H)));
            append(row,te);
            append(table12,row);
      end 
        
      if i == 5
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b0']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B0_Norm_OL_H)));
            append(row,te);
            append(table12,row);
      end   
      
           if i == 6
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b1']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B1_Norm_OL_H)));
            append(row,te);
            append(table12,row);
           end      
      
     if i == 7
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b2']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B2_Norm_OL_H)));
            append(row,te);
            append(table12,row);
     end   
           
     if i == 8
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b3']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B3_Norm_OL_H)));
            append(row,te);
            append(table12,row);
     end     
     
        if i == 9
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b4']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B4_Norm_OL_H)));
            append(row,te);
            append(table12,row);
        end     
     if i == 10
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Normal']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OL_Norm_Normal)));
            append(row,te);
            append(table12,row);
     end 
        
          if i == 11
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Shift']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OL_Norm_PostShift)));
            append(row,te);
            append(table12,row);
          end 
        
        if i == 12
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Scalar']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',OL_Norm_PostScalar)));
            append(row,te);
            append(table12,row);
        end 
end

add (ch3, table12);


para92  = Paragraph(sprintf('Cascaded Coefficients are '));
para92.Bold = true;
para93  = Paragraph(sprintf('Compensator1'));
para93.Bold = true;
add(ch3,para92);
add(ch3,para93);
append(para92,NL);
append(para93,NL);

table13 = Table(3);
table13.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table13.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table13,row);

for i=1:4
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a11']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A11_OL_C)));
            append(row,te);
            append(table13,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b10']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B10_OL_C)));
            append(row,te);
            append(table13,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b11']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B11_OL_C)));
            append(row,te);
            append(table13,row);
        end  
        
      if i == 4
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['Post Shift']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',PS_OL_C)));
            append(row,te);
            append(table13,row);
      end 
end

add (ch3, table13);

%%
para94  = Paragraph(sprintf('Compensator2'));
para94.Bold = true;
add(ch3,para94);
append(para94,NL);

table14 = Table(3);
table14.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table14.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table14,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a21']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A21_OL_C)));
            append(row,te);
            append(table14,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b20']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B20_OL_C)));
            append(row,te);
            append(table14,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b21']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B21_OL_C)));
            append(row,te);
            append(table14,row);
        end  
end

add (ch3, table14);

%%
para95  = Paragraph(sprintf('Compensator3'));
para95.Bold = true;
add(ch3,para95);
append(para95,NL);

table15 = Table(3);
table15.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
table15.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(table15,row);

for i=1:3
        if i == 1
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['a31']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',A31_OL_C)));
            append(row,te);
            append(table15,row);
        end
        
     if i == 2
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b30']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B30_OL_C)));
            append(row,te);
            append(table15,row);
     end  
        
          if i == 3
            row = TableRow();

            te = TableEntry();
            append(te,Text([num2str(i) ]));
            append(row,te);

            te = TableEntry();
            append(te,Text(['b31']));
            append(row,te);

            te = TableEntry();
            append(te,Paragraph(sprintf('%s',B31_OL_C)));
            append(row,te);
            append(table15,row);
        end  
end

add (ch3, table15);


%% end of chapter 3
add(rpt,ch3);
%% CH 4 ----- Plots
%% User defined Bode plot
ch4 = mlreportgen.report.Chapter('Title','User defined Bode plot');
% fig1 = figure;
% fig2 = figure;
fig = figure;
%h = findobj(handles.BODEPLOT,'type','axes');
h1 = findobj(handles.UserBodeResponseTab.Subplot1.axis,'type','axes');
h2 = findobj(handles.UserBodeResponseTab.Subplot2.axis,'type','axes');
% copyobj(h1,fig1);
% copyobj(h2,fig2);
copyobj(h1,fig);
copyobj(h2,fig);
saveas(fig,'User_Define_BPLOT.png');
%saveas(fig,'Phase.png');
% saveas(fig1,'Magnitude.png');
% saveas(fig2,'Phase.png');
%print(fig,'MySavedPlot','-dpng');
% close(fig1);
% close(fig2);
close(fig);
img = Image('User_Define_BPLOT.png');
%img2 = Image('Phase.png');
img.Style = {Height('5in'),Width('5in')};
add(ch4, img);
add(rpt,ch4);
%end

%% CH 5 ----- cascaded equations


%%  end of total report
close(rpt);
delete Outer_Loop_Bode_Plot(Gvd).png;
delete Inner_Loop_Bode_Plot(Gid).png;
delete GCLI_AP.png,
delete GifilterP.png;
delete Gvifilter.png;
delete Gvofilter.png;
delete User_Define_BPLOT.png;
delete GvcPBodeplot.png;
%delete PSDS.pdf
rptview(rpt);

