function DACcalculation(hObject,~)
handles=guidata(hObject);
OPOverVoltageLimit = handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String;
OPOverVoltageLimitC = str2double(OPOverVoltageLimit);

ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
Rfb4C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
Rfb5C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
ADCVoltC = str2double(ADCVolt);
VoutbaseC = (ADCVoltC / (Rfb5C / (Rfb5C+Rfb4C)));
VoutbaseCK = str2double(handles.FeedbackNetworkTab.Voutbase);

ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
ADCResC = 2^str2double(ADCRes);
OPOVLimitCounts = round((ADCResC * OPOverVoltageLimitC / VoutbaseC),0);
handles.IPT5.DACCountValueCalculated=OPOVLimitCounts;
handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String=handles.IPT5.DACCountValueCalculated;

if ( OPOVLimitCounts > 4095)
%         hObject.BackgroundColor=[1 0.8 0.8];
        handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.BackgroundColor=[1 0.8 0.8];
        handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String='4095';
        errordlg('Output Over Voltage Limit is greater than Equivalent 12 Bit ADC Value (4096) and will not be accepted','Error')
    return;    
end