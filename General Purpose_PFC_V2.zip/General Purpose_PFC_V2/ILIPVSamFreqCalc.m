function ILIPVSamFreqCalc(hObject,~)                 % IPT3, IL, Input Voltage Sampling Freq Calculations
handles=guidata(hObject);


Fswitching = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String)*1e3;    % Switching frequency in Hz
SampRatioIL = round(str2double(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String),0);

if ~isnan(Fswitching)&& ~isnan(SampRatioIL)

FsampIL = Fswitching/SampRatioIL;
PWMSamplFreqIL = string(FsampIL/1000);
set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String', PWMSamplFreqIL);
handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq=FsampIL;

% PWMSampling_Freq=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String)*1e3;
% CrossOver_Frequency=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String);
% Ratio=PWMSampling_Freq/CrossOver_Frequency;
% if (Ratio) < 5     
% errordlg('Recommended to choose Crossover Frequency less than 1/5 th of the PWM Sampling Frequency','Warning'); 
% end

else
    
set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String', ' ');    
end

% ILSamplingFreq=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String);
% OLSamplingFreq=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
% if ~isnan(ILSamplingFreq)&& ~isnan(OLSamplingFreq)
%     if ILSamplingFreq > OLSamplingFreq
%     errordlg('Inner loop sampling frequency should be greater than Outer loop sampling frequency','Error');
%     end
% end
% OLSamplingFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
% % ILSamplingFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String);
% PWMSamplFreqILC = str2double(PWMSamplFreqIL);
% if PWMSamplFreqILC < OLSamplingFreq
%     errordlg('Inner loop sampling frequency should be greater than Outer loop sampling frequency','Error');
% end
