function MenuSaveAs_Callback(hObject,handles)
if (handles.ProjectInformation.SavedStatus=="Saved")
    ProjName=char(handles.ProjectInformation.ProjName);
else
    ProjName=char("");
end
[fileName ,pathName]=uiputfile('*.psds','Save ProjectAs',ProjName);
if fileName==0
    warndlg({'Project not saved!!','Changes made will be lost permanently'},'Warning','modal');
    return;
end
[~,filename,~]=fileparts(fileName); % Notice small n and N in filename
handles.ProjectInformation.ProjName=string(filename);
handles.ProjectInformation.SavedStatus="Saved";
save(fullfile(pathName, fileName),'handles','-mat');
guidata(hObject,handles);
msgbox('Project Saved!!','Project Save Status','modal');


