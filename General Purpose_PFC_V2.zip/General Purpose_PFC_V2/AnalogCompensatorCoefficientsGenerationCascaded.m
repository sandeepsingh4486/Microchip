function AnalogCompensatorCoefficientsGenerationCascaded(hObject)
handles=guidata(hObject);
%% Outerloop Analog Cascaded Controller
s=tf('s');
OLAnalogCompensatorCascaded = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Analog;

OLNumTf = length(OLAnalogCompensatorCascaded);
OLAnalogCoeff = zpk(minreal(OLAnalogCompensatorCascaded));  % Outer loop compensator in pole Zero form only for display

OLAnalogCoeff.DisplayFormat = 'frequency';             % Outerer loop compensator in pole Zero form
% OLAnalogCoeff.K = evalfr(minreal(zpk((OLAnalogCompensatorCascaded))),0);          % to find the gain of the equation

testK = evalfr(minreal(OLAnalogCoeff*s),0 );          % to find the gain of the equation
for count = 1:OLNumTf
    if(testK(count) == 0)
        OLAnalogCoeff.K(count) = evalfr(OLAnalogCoeff(count),0);
    else
        OLAnalogCoeff.K(count) = testK(count);
    end
end

% OLZerosNum = length(OLAnalogCoeff.Z);
% OLPolesNum = length(OLAnalogCoeff.P);
% OLGain = length(OLAnalogCoeff.K);

switch OLNumTf
    case 1
        
        OLN1 = [OLAnalogCoeff.Z(1)];
        OLN1{1}(isempty(OLN1{1})) = 0;
        OLD1 = [OLAnalogCoeff.P(1)];
        OLD1{1}(isempty(OLD1{1})) = 0;
        OLG1 = [OLAnalogCoeff.K(1)];
        OLG1(isempty(OLG1)) = 0;
        
        OLN2 = [0];
        OLD2 = [0];
        OLG2 = [1];
        
        OLN3 = [0];
        OLD3 = [0];
        OLG3 = [1];
        
        OLCascaded1AnalogCoeff.Z1 = OLN1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.P1 = OLD1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.Kdc1 = OLG1;
        
        OLCascaded2AnalogCoeff.Z2 = OLN2;
        OLCascaded2AnalogCoeff.P2 = OLD2;
        OLCascaded2AnalogCoeff.Kdc2 = OLG2;
        
        OLCascaded3AnalogCoeff.Z3 = OLN3;
        OLCascaded3AnalogCoeff.P3 = OLD3;
        OLCascaded3AnalogCoeff.Kdc3 = OLG3;
        
    case 2
        
        OLN1 = [OLAnalogCoeff.Z(1)];
        OLN1{1}(isempty(OLN1{1})) = 0;
        OLD1 = [OLAnalogCoeff.P(1)];
        OLD1{1}(isempty(OLD1{1})) = 0;
        OLG1 = [OLAnalogCoeff.K(1)];
        OLG1(isempty(OLG1)) = 0;
        
        
        OLN2 = [OLAnalogCoeff.Z(2)];
        OLN2{1}(isempty(OLN2{1})) = 0;
        OLD2 = [OLAnalogCoeff.P(2)];
        OLD2{1}(isempty(OLD2{1})) = 0;
        OLG2 = [OLAnalogCoeff.K(2)];
        OLG2(isempty(OLG2)) = 0;
        
        
        OLN3 = [0];
        OLD3 = [0];
        OLG3 = [1];
        
        
        OLCascaded1AnalogCoeff.Z1 = OLN1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.P1 = OLD1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.Kdc1 = OLG1;
        
        OLCascaded2AnalogCoeff.Z2 = OLN2{1}./(-2*pi);
        OLCascaded2AnalogCoeff.P2 = OLD2{1}./(-2*pi);
        OLCascaded2AnalogCoeff.Kdc2 = OLG2;
        
        OLCascaded3AnalogCoeff.Z3 = OLN3;
        OLCascaded3AnalogCoeff.P3 = OLD3;
        OLCascaded3AnalogCoeff.Kdc3 = OLG3;
    case 3
        
        OLN1 = [OLAnalogCoeff.Z(1)];
        OLN1{1}(isempty(OLN1{1})) = 0;
        OLD1 = [OLAnalogCoeff.P(1)];
        OLD1{1}(isempty(OLD1{1})) = 0;
        OLG1 = [OLAnalogCoeff.K(1)];
        OLG1(isempty(OLG1)) = 0;
        
        OLN2 = [OLAnalogCoeff.Z(2)];
        OLN2{1}(isempty(OLN2{1})) = 0;
        OLD2 = [OLAnalogCoeff.P(2)];
        OLD2{1}(isempty(OLD2{1})) = 0;
        OLG2 = [OLAnalogCoeff.K(2)];
        OLG2(isempty(OLG2)) = 0;
        
        OLN3 = [OLAnalogCoeff.Z(3)];
        OLN3{1}(isempty(OLN3{1})) = 0;
        OLD3 = [OLAnalogCoeff.P(3)];
        OLD3{1}(isempty(OLD3{1})) = 0;
        OLG3 = [OLAnalogCoeff.K(3)];
        OLG3(isempty(OLG3)) = 0;
        
        OLCascaded1AnalogCoeff.Z1 = OLN1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.P1 = OLD1{1}./(-2*pi);
        OLCascaded1AnalogCoeff.Kdc1 = OLG1;
        
        OLCascaded2AnalogCoeff.Z2 = OLN2{1}./(-2*pi);
        OLCascaded2AnalogCoeff.P2 = OLD2{1}./(-2*pi);
        OLCascaded2AnalogCoeff.Kdc2 = OLG2;
        
        OLCascaded3AnalogCoeff.Z3 = OLN3{1}./(-2*pi);
        OLCascaded3AnalogCoeff.P3 = OLD3{1}./(-2*pi);
        OLCascaded3AnalogCoeff.Kdc3 = OLG3;
end

handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded1Abs = OLCascaded1AnalogCoeff;
handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded2Abs = OLCascaded2AnalogCoeff;
handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded3Abs = OLCascaded3AnalogCoeff;

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded1Abs.P1,0);
handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded1Abs.Z1,0);
if handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1.String=='0'
    set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1,'String','-');
end
handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded1Abs.Kdc1;

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded2Abs.P2,0);
if handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2.String=='0'
    set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2,'String','-');
end

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded2Abs.Z2,0);
if handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2.String=='0'
    set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2,'String','-');
end

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded2Abs.Kdc2;

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded3Abs.P3,0);
if handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3.String=='0'
    set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3,'String','-');
end

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3.String = round(handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded3Abs.Z3,0);
if handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3.String=='0'
    set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3,'String','-');
end

handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.AnalogCoefficientsCascaded3Abs.Kdc3;

%% %% Inerloop Analog Cascaded Controller

ILAnalogCompensatorCascaded = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog;
ILNumTf = length(ILAnalogCompensatorCascaded);
ILAnalogCoeff = zpk(minreal(ILAnalogCompensatorCascaded));

ILAnalogCoeff.DisplayFormat = 'frequency';             % Inner loop compensator in pole Zero form

testK = evalfr(minreal(ILAnalogCoeff*s),0 );          % to find the gain of the equation
for count = 1:ILNumTf
    if(testK(count) == 0)
        ILAnalogCoeff.K(count) = evalfr(ILAnalogCoeff(count),0);
    else
        ILAnalogCoeff.K(count) = testK(count);
    end
end
% ILZerosNum = length(ILAnalogCoeff.Z);
% ILPolesNum = length(ILAnalogCoeff.P);
% ILGain = length(ILAnalogCoeff.K);

switch ILNumTf
    case 1
        
        ILN1 = [ILAnalogCoeff.Z(1)];
        ILN1{1}(isempty(ILN1{1})) = 0;
        ILD1 = [ILAnalogCoeff.P(1)];
        ILD1{1}(isempty(ILD1{1})) = 0;
        ILG1 = [ILAnalogCoeff.K(1)];
        ILG1(isempty(ILG1)) = 0;
        
        ILN2 = [0];
        ILD2 = [0];
        ILG2 = [1];
        
        ILN3 = [0];
        ILD3 = [0];
        ILG3 = [1];
        
        ILCascaded1AnalogCoeff.Z1 = ILN1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.P1 = ILD1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.Kdc1 = ILG1;
        
        ILCascaded2AnalogCoeff.Z2 = ILN2;
        ILCascaded2AnalogCoeff.P2 = ILD2;
        ILCascaded2AnalogCoeff.Kdc2 = ILG2;
        
        ILCascaded3AnalogCoeff.Z3 = ILN3;
        ILCascaded3AnalogCoeff.P3 = ILD3;
        ILCascaded3AnalogCoeff.Kdc3 = ILG3;
        
    case 2
        
        ILN1 = [ILAnalogCoeff.Z(1)];
        ILN1{1}(isempty(ILN1{1})) = 0;
        ILD1 = [ILAnalogCoeff.P(1)];
        ILD1{1}(isempty(ILD1{1})) = 0;
        ILG1 = [ILAnalogCoeff.K(1)];
        ILG1(isempty(ILG1)) = 0;
        
        
        ILN2 = [ILAnalogCoeff.Z(2)];
        ILN2{1}(isempty(ILN2{1})) = 0;
        ILD2 = [ILAnalogCoeff.P(2)];
        ILD2{1}(isempty(ILD2{1})) = 0;
        ILG2 = [ILAnalogCoeff.K(2)];
        ILG2(isempty(ILG2)) = 0;
        
        ILN3 = [0];
        ILD3 = [0];
        ILG3 = [1];
        
        ILCascaded1AnalogCoeff.Z1 = ILN1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.P1 = ILD1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.Kdc1 = ILG1;
        
        ILCascaded2AnalogCoeff.Z2 = ILN2{1}./(-2*pi);
        ILCascaded2AnalogCoeff.P2 = ILD2{1}./(-2*pi);
        ILCascaded2AnalogCoeff.Kdc2 = ILG2;
        
        ILCascaded3AnalogCoeff.Z3 = ILN3;
        ILCascaded3AnalogCoeff.P3 = ILD3;
        ILCascaded3AnalogCoeff.Kdc3 = ILG3;
        
    case 3
        
        ILN1 = [ILAnalogCoeff.Z(1)];
        ILN1{1}(isempty(ILN1{1})) = 0;
        ILD1 = [ILAnalogCoeff.P(1)];
        ILD1{1}(isempty(ILD1{1})) = 0;
        ILG1 = [ILAnalogCoeff.K(1)];
        ILG1(isempty(ILG1)) = 0;
        
        ILN2 = [ILAnalogCoeff.Z(2)];
        ILN2{1}(isempty(ILN2{1})) = 0;
        ILD2 = [ILAnalogCoeff.P(2)];
        ILD2{1}(isempty(ILD2{1})) = 0;
        ILG2 = [ILAnalogCoeff.K(2)];
        ILG2(isempty(ILG2)) = 0;
        
        ILN3 = [ILAnalogCoeff.Z(3)];
        ILN3{1}(isempty(ILN3{1})) = 0;
        ILD3 = [ILAnalogCoeff.P(3)];
        ILD3{1}(isempty(ILD3{1})) = 0;
        ILG3 = [ILAnalogCoeff.K(3)];
        ILG3(isempty(ILG3)) = 0;
        
        ILCascaded1AnalogCoeff.Z1 = ILN1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.P1 = ILD1{1}./(-2*pi);
        ILCascaded1AnalogCoeff.Kdc1 = ILG1;
        
        ILCascaded2AnalogCoeff.Z2 = ILN2{1}./(-2*pi);
        ILCascaded2AnalogCoeff.P2 = ILD2{1}./(-2*pi);
        ILCascaded2AnalogCoeff.Kdc2 = ILG2;
        
        ILCascaded3AnalogCoeff.Z3 = ILN3{1}./(-2*pi);
        ILCascaded3AnalogCoeff.P3 = ILD3{1}./(-2*pi);
        ILCascaded3AnalogCoeff.Kdc3 = ILG3;
end

handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded1Abs = ILCascaded1AnalogCoeff;
handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded2Abs = ILCascaded2AnalogCoeff;
handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded3Abs = ILCascaded3AnalogCoeff;

handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded1Abs.P1,0);
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded1Abs.Z1,0);
if handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1.String=='0'
    set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1,'String','-');
end
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded1Abs.Kdc1;

handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded2Abs.P2,0);
if handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2.String=='0'
    set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2,'String','-');
end
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded2Abs.Z2,0);
if handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2.String=='0'
    set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2,'String','-');
end
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded2Abs.Kdc2;

handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded3Abs.P3,0);
if handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3.String=='0'
    set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3,'String','-');
end
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3.String = round(handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded3Abs.Z3,0);
if handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3.String=='0'
    set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3,'String','-');
end
handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.AnalogCoefficientsCascaded3Abs.Kdc3;

