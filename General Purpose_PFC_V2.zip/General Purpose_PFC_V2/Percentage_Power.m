function Percentage_Power(hObject,~)
handles=guidata(hObject);

set(handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts,'Enable','off');
set(handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts,'Enable','off');
set(handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts,'Enable','off');



OutputPower=str2double(handles.General_test.CommonSpecs.Pout.String);
BurstModeEnableLimit=str2double(handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String);
PhaseSheddingIPFCTextBox=str2double(handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String);
HysPhaseSheddingIPFCTextBox=str2double(handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String);
% PhaseSheddingIPFCTextBoxWatts=str2double(handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String);



% if handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value==1
    if ~isnan(handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String)
        Percent_BurstModeEnableLimit=(OutputPower*BurstModeEnableLimit)/100;
        
        handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String=Percent_BurstModeEnableLimit;
    else
        handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String='';
    end
% else
%     handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String='';



if handles.IPT6.FeaturesConfiguration.PhaseShedding.Value==1
    if ~isnan(PhaseSheddingIPFCTextBox)&& ~isnan(OutputPower)
        
        Percent_PhaseShedding=(OutputPower*PhaseSheddingIPFCTextBox)/100;
        handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String=Percent_PhaseShedding;
        
    else
        handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String='';
    end
    % else
    %     handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String='';
end


% if handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value==1
    PhaseSheddingIPFCTextBoxWatts=str2double(handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String);
    if ~isnan(HysPhaseSheddingIPFCTextBox) && ~isnan(PhaseSheddingIPFCTextBoxWatts) 

        Percent_HysPhaseShedding = (OutputPower*HysPhaseSheddingIPFCTextBox)/100;
        Percent_HysPhaseShedding_Limit = Percent_HysPhaseShedding;
        handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String = Percent_HysPhaseShedding_Limit;
    else
        handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String='';
    end
% else
%     handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String='';
end

