%% manual ILcomp and OLcomp is calculated in the respective files and loop gain will be computed here.
function CMCLoopGainComputation_PFC(hObject,~)
handles=guidata(hObject);
handles.Menu.OutputReport.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='off';

ILFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Enable;
OLFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable;
ILPlantEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILPlantPlot.Enable;
ILCompensatorEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable;
ControlMethod=handles.General_test.SelectionDropdowns.ControlMethodSelection.Value;

 s = tf('s');

%% Feedback Networks and getting base values
if (isequal(ILFBEntered,'off') || isequal(ILPlantEntered,'off') || isequal(ILCompensatorEntered,'off') || isequal(ILFBEntered,'off')||isequal(OLFBEntered,'off'))
    PlotGeneration(hObject);
    return;
else
    ADCVolt = str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String);
    Vadc = ADCVolt;
    CMSel = (handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio);
    
    Rfb7=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String)*1e3;             % Burden resistor
    Rfb8=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String)*1e3;             % LPF
    Cfb5=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String)*1e-12;           % LPF
    Ns=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String);
    Ns(isnan(Ns))=100;
    Np=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String);
    Np(isnan(Np))=1; 
    
    Rfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String)*1e3;
    Rfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String)*1e3;
    Rfb3 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String)*1e3;
    Cfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String)*1e-12;
    Cfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String)*1e-12;
    
    Rfb4 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
    Rfb5 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
    Rfb6 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String)*1e3;
    Cfb3 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String)*1e-12;
    Cfb4 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String)*1e-12;
    
    Rfb9 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String)*1e3;
    Rfb10 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String)*1e3;
    Rfb11 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String)*1e3;
    Cfb6 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String)*1e-12;
    Rfb12 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String)*1e3;
    Cfb7 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String)*1e-12;    

    %% Current measurement feedback calculations
    if (CMSel.CurrentTransformer.Value == 1)&& (isequal(isnan([Rfb7 Rfb8 Cfb5 Ns Np]),zeros(1,5))) 
        n=Ns/Np;                                             % CT turns ratio 
        Kcfilter = Rfb7 /n ;                       
        Kcfilter(isnan(Kcfilter))=1;
        Ibase = Vadc / Kcfilter;
        CS_LPF = 1/((Rfb7+Rfb8)*Cfb5*s+1);                   % CS LPF T/F
        
    elseif(CMSel.ShuntResistor.Value == 1)
        Kcfilter = (Rfb9 * (1 + (Rfb11 / Rfb10)));
        Ibase = Vadc / Kcfilter; 
        CS_LPF = 1/(1+s*Rfb12*Cfb7);                       % LPF T/F
    end
        
    Vinbase = Vadc/(Rfb2/(Rfb2+Rfb1));                   % Vbase input feedback network
    Voutbase = Vadc /(Rfb5/(Rfb4+Rfb5));                 % Vbase Output feedback network  
    OPfilter = 1 /(1+s*Rfb6*Cfb4);                       % LPF T/F  
    
    ILFBTF=handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;    
    OLFBTF=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;  % is it same as OPfilter = 1 /(1+s*Rfb6*Cfb4);  % LPF T/F
end

OLPlantEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Enable;
OLCompensatorEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable;

GateDriverDelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String);
GateDriverDelay(isnan(GateDriverDelay))=0;
Fsw=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String);
Tsw=1/Fsw;
FsOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
Tsv=1/FsOL;
FsIL=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String);
FsIL(isnan(FsIL))= Fsw;
Tsi = 1/FsIL;
OLADClatency=str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String)*1e-9;
OLADClatency(isnan(OLADClatency))=0;
OLComputationaldelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String)*1e-9;
OLComputationaldelay(isnan(OLComputationaldelay))=0;
ILComputationaldelay=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String)*1e-9;
ILComputationaldelay(isnan(ILComputationaldelay)|| isequal(ControlMethod,3))=0;
PWMshold = ((1-(1-(s*Tsi)/2)/(1+(s*Tsi)/2))/(s*Tsi));

Delay_innerloop_Forwardpath = GateDriverDelay + ILComputationaldelay;
Delay_innerloop_Feedbackpath = OLADClatency;
Delay_innerloop = (Delay_innerloop_Forwardpath + Delay_innerloop_Feedbackpath);
GdelayIL =(1-s*(Delay_innerloop/2))/(1+s*(Delay_innerloop/2)); 

Delay_outerloop_Forwardpath =  OLComputationaldelay;
Delay_outerloop_Feedbackpath = OLADClatency;
Delay_outerloop = Delay_outerloop_Forwardpath + Delay_outerloop_Feedbackpath;
GdelayOL = (1-s*(Delay_outerloop/2))/(1+s*(Delay_outerloop/2));

if (isnan(Tsv) || isnan(Tsi) || (isreal(Delay_outerloop)==0)|| isnan(Delay_outerloop) )
    PlotGeneration(hObject);
    return;
else
    
    ILCompensatorTF = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog; % Compensator T/F cal in ILmanualCompDesign_PFC
    ILPlantTF = handles.General_test.PlantInfo.IL.PlantTF;    % Gid 
    GidN = (ILPlantTF / Ibase);                        % Current loop pant normalized
    Gi = GidN * GdelayIL * PWMshold * CS_LPF;          % Current loop pant normalized with delays; 
    ILLGAnalog = Gi * ILCompensatorTF;
    ILLGDigital = c2d(ILLGAnalog,Tsi,'tustin');               % Loop-Gain in discontinuious domain (Z-domain)

%     ILLGAnalog = (ILPlantTF / Ibase)*ILCompensatorTF*CS_LPF ;  
%     ILLGDigital=(ILPlantTF / Ibase)*ILCompensatorTF*H_InnerLoopDelay*PWMshold*CS_LPF*H_InnerLoopDelay_Feedback;
    
    ILCLTFAnalog = minreal(feedback((ILLGAnalog/CS_LPF),(CS_LPF))); % inner closed loop T/F

    handles.General_test.PlantInfo.IL.LoopGainAnalogTF=ILLGAnalog;
    handles.General_test.PlantInfo.IL.LoopGainDigitalTF=ILLGDigital;
    handles.General_test.PlantInfo.IL.ILCLTFAnalog=ILCLTFAnalog;
%     handles.General_test.PlantInfo.IL.ILCLTFDigital=ILCLTFDigital;
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='on';
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='on';

    guidata(hObject,handles); % Even if the Outer Loop parameters are not enetered, after this line inner loop parameters can be plotted
    
end

if (isequal(OLPlantEntered,'off') || isequal(OLCompensatorEntered,'off') )
    PlotGeneration(hObject);
    return;
else
    %% Outer Loop Delay calculation    
    Rc=str2double(handles.General_test.CommonSpecs.Capacitor.ESR.String)*1e-3;
    C=str2double(handles.General_test.CommonSpecs.Capacitor.Capacitance.String)*1e-6;
    Vout=str2double(handles.General_test.CommonSpecs.Vout.String);
    Gc = (1/Vout);                                              % DC gain of Control-to-output transfer function
    Gvc = Gc*(1+Rc*C*s)/(s*C);                                  % Control-to-output transfer function with C and ESR, This is Gvc
    GcN = Gvc * Ibase * ILCLTFAnalog * Vinbase / Voutbase;            % Normalized plant
    Gvcp = GcN * GdelayOL * OPfilter ;                          % Gvcp plant transfer function with all delays
   
    %% Control-to-Output Transfer Function Computation
    
    OLCompensatorTF = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog ; % Compensator T/F cal in OLmanualCompDesign_PFC
        
    OLLGAnalog = OLCompensatorTF * Gvcp;    
    OLLGDigital = c2d(OLLGAnalog,Tsv,'tustin');
    CLTFAnalog = (OLLGAnalog / OPfilter)/(1+OLLGAnalog) ; % total system Closed Loop               

    CLTFDigital = c2d(CLTFAnalog,Tsv,'tustin');    
        
    handles.General_test.CLTF.Analog=CLTFAnalog;
    handles.General_test.CLTF.Analog_with_Delay=CLTFDigital;
    handles.General_test.PlantInfo.OL.LoopGainAnalogTF=OLLGAnalog;
    handles.General_test.PlantInfo.OL.LoopGainDigitalTF=OLLGDigital;
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='on';
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='on';   
    guidata(hObject,handles);
end
handles.Menu.OutputReport.Enable='on';
PlotGeneration(hObject);    
