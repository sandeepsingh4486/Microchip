function PlotGeneration(hObject,~)
handles=guidata(hObject);

% Bode Options
bOptions=bodeoptions;
bOptions.Grid='on';
bOptions.FreqUnits='Hz';
bOptions.PhaseWrapping = 'on' ;
bOptions.MagUnits = 'dB';
bplot=handles.PlotsTab.PlotsAxes.BodePlotAx;
hold(bplot,'off');
bode(bplot,tf(1,1),bOptions);

% RootLocus
rplot=handles.PlotsTab.PlotsAxes.RLPlotAx;
rplotOptions=getoptions(rlocusplot(rplot,tf(1,1)));
rplotOptions.FreqUnits='Hz';
rplotOptions.Grid='on';
hold(rplot,'off');
rlocusplot(rplot,tf(1,1));

%Nyquist Plot
nplot=handles.PlotsTab.PlotsAxes.NPlotAx;
hold(nplot,'off');
nyquistplot(nplot,tf(1,1));

% Step Response
splot=handles.PlotsTab.PlotsAxes.SRPlotAx;
hold(splot,'off');
stepplot(splot,tf(1,1));

PlotSel=handles.PlotsTab.Configuration.PlotDisplaySelections;


ILACPDisplay=PlotSel.ILCompensatorPlotAnalog; % Analog Compensator Plot
ILDCPDisplay=PlotSel.ILCompensatorPlotDigital; % Digital Comepensator Plot
ILPPDisplay=PlotSel.ILPlantPlot; % Inner Loop Plant Plot Display
ILFBPDisplay=PlotSel.ILFBPlot; % Inner Loop FB Plot Display
ILALGPDisplay=PlotSel.ILLoopGainPlotAnalog; % Inner loop Analog Loop Gain Plot Display
ILDLGPDisplay=PlotSel.ILLoopGainPlotDigital; % Inner loop Digital Loop Gain Plot Display
OLACPDisplay=PlotSel.OLCompensatorPlotAnalog; % Analog Compensator Plot
OLDCPDisplay=PlotSel.OLCompensatorPlotDigital; % Digital Comepensator Plot
OLPPDisplay=PlotSel.OLPlantPlot; % Outer Loop Plant Plot Display
OLFBPDisplay=PlotSel.OLFBPlot;
OLALGPDisplay=PlotSel.OLLoopGainPlotAnalog; % Outer Loop Analog Loop Gain Plot Display
OLDLGPDisplay=PlotSel.OLLoopGainPlotDigital; % Outer Loop Digital Loop Gain Plot Display

% Plotting

% Outer loop Plant Transfer function Plot

if (isequal(OLPPDisplay.Enable,'on') && OLPPDisplay.Value==1)
Gvd =  handles.General_test.PlantInfo.OL.PlantTF;
    bodeplot(bplot,Gvd,bOptions);
    hold(bplot,'on');
    legend('show');

    %rlocusplot(rplot,OLTF,rplotOptions)
    %nyquistplot(nplot,OLTF);
    %hold(nplot,'on');
    %hold(rplot,'on');
end

% Outer Loop Feedback TF

if (isequal(OLFBPDisplay.Enable,'on') && OLFBPDisplay.Value==1)
    OuterLoopFeedback=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
    bodeplot(bplot,OuterLoopFeedback,'b',bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,OLFBTF,'b',rplotOptions)
    %nyquistplot(nplot,OLFBTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Outer Loop Compansator Analog
if (isequal(OLACPDisplay.Enable,'on') && OLACPDisplay.Value==1)
    OuterLoopCompensatorAnalog=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog; 
    bodeplot(bplot,OuterLoopCompensatorAnalog,bOptions);
    hold(bplot,'on');
    legend('show');
    %rlocusplot(rplot,OLCATF,rplotOptions);
    %nyquistplot(nplot,OLCATF);
    %hold(nplot,'on');
    %hold(rplot,'on');
end

% Outer Loop Compansator Digital
if (isequal(OLDCPDisplay.Enable,'on') && OLDCPDisplay.Value==1)
    OuterLoopCompensatorDigital=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital;
    bodeplot(bplot,OuterLoopCompensatorDigital,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,OLCDTF,rplotOptions);
   % nyquistplot(nplot,OLCDTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Inner Loop Plant Transfer function plot 
if (isequal(ILPPDisplay.Enable,'on') && ILPPDisplay.Value==1)
    Gid=handles.General_test.PlantInfo.IL.PlantTF;
    bodeplot(bplot,Gid,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,ILTF,rplotOptions);
    %nyquistplot(nplot,ILTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Outer Loop Feedback TF

if (isequal(ILFBPDisplay.Enable,'on') && ILFBPDisplay.Value==1)
    InnerLoopFeedback=handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;
    bodeplot(bplot,InnerLoopFeedback,bOptions);
    hold(bplot,'on');
    legend('show');
    
    
   % rlocusplot(rplot,ILFBTF,rplotOptions);
   % nyquistplot(nplot,ILFBTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Outer Loop LoopGain Analog

if (isequal(OLALGPDisplay.Enable,'on') && OLALGPDisplay.Value==1)
    OuterLoopGainAnalog=handles.General_test.PlantInfo.OL.LoopGainAnalogTF;
    bodeplot(bplot,OuterLoopGainAnalog,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,OLLGATF,rplotOptions);
    %nyquistplot(nplot,OLLGATF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Outer Loop LoopGain Digital

if (isequal(OLDLGPDisplay.Enable,'on') && OLDLGPDisplay.Value==1)
    OuterLoopGainDigital=handles.General_test.PlantInfo.OL.LoopGainDigitalTF;
    bodeplot(bplot,OuterLoopGainDigital,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,OLLGDTF,rplotOptions);
    %nyquistplot(nplot,OLLGDTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Inner Loop Compensator Analog

if (isequal(ILACPDisplay.Enable,'on') && ILACPDisplay.Value==1)
    InnerLoopCompensatorAnalog=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;
    bodeplot(bplot,InnerLoopCompensatorAnalog,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,ILCATF,rplotOptions);
   % nyquistplot(nplot,ILCATF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Inner Loop Compansator Digital
if (isequal(ILDCPDisplay.Enable,'on') && ILDCPDisplay.Value==1)
    InnerLoopCompensatorDigital=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital;
    bodeplot(bplot,InnerLoopCompensatorDigital,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,ILCDTF,rplotOptions);
   % nyquistplot(nplot,ILCDTF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Inner Loop Loop gain  Analog
if (isequal(ILALGPDisplay.Enable,'on') && ILALGPDisplay.Value==1)
    InnerLoopGainAnalog=handles.General_test.PlantInfo.IL.LoopGainAnalogTF;
    bodeplot(bplot,InnerLoopGainAnalog,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,ILLGATF,rplotOptions);
   % nyquistplot(nplot,ILLGATF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end

% Inner Loop Loop gain  Digital
if (isequal(ILDLGPDisplay.Enable,'on') && ILDLGPDisplay.Value==1)
    InnerLoopGainDigital=handles.General_test.PlantInfo.IL.LoopGainAnalogTF;
    bodeplot(bplot,InnerLoopGainDigital,bOptions);
    hold(bplot,'on');
    legend('show');
    
    %rlocusplot(rplot,ILLGATF,rplotOptions);
   % nyquistplot(nplot,ILLGATF);
    %hold(nplot,'on');
    
    %hold(rplot,'on');
end


%Figure Image Adjustments
if(handles.GUIProcesses.ResizingDone==1)
    FigureImageAdjusments (handles.ParentFigure);
end

%Step Response and Nyquist Plot


if (isequal(OLPPDisplay.Enable,'on') && isequal(OLACPDisplay.Enable,'on') && isequal(OLFBPDisplay.Enable,'on'))
    if((isequal(ILPPDisplay.Enable,'off') || isequal(ILFBPDisplay.Enable,'off')) || (handles.General_test.SelectionDropdowns.ControlMethodSelection.Value==2 && isequal(ILACPDisplay.Enable,'off')))
        return;
    end    
    ClosedLoopSystem=handles.General_test.CLTF.Analog_with_Delay;
    OuterLoopGainAnalog=handles.General_test.PlantInfo.OL.LoopGainDigitalTF;
    rlocusplot(rplot,OuterLoopGainAnalog,rplotOptions);
    legend('show');
    nyquistplot(nplot,OuterLoopGainAnalog);
    legend('show');
   % stepplot(splot,ClosedLoopSystem);
       legend('show');
end


