function OLIPVSamFreqCalc(hObject,~) % IPT3, OL, Input Voltage Sampling Freq Calculations
handles=guidata(hObject);


Fswitching = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String)*1e3;     % Switching frequency in Hz
SampRatioOL = round(str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String),0);
if ~isnan(Fswitching)&& ~isnan(SampRatioOL)

FsampOL = Fswitching/SampRatioOL;
PWMSamplFreqOL = string(FsampOL/1000);
set(handles.ControllerDesignTab.PWMConfiguration.OL.PTPER, 'String', PWMSamplFreqOL);
handles.ControllerDesignTab.PWMConfiguration.OL.PTPER=FsampOL;

% OL_CrossOver_Frequency=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String);
% if OL_CrossOver_Frequency> 20
% errordlg('Recommended to choose Crossover Frequency less than 1/5 th of the rectified AC line frequency ','Warning');
% end

else
    
set(handles.ControllerDesignTab.PWMConfiguration.OL.PTPER, 'String', ' ');    
end