function PTPERCalculation(hObject,~)
handles=guidata(hObject)
dsPICDSCSel = handles.dsPICDSCTab.DeviceSelection.DeviceSelectionDropdown.Value;
if (dsPICDSCSel==0)||(dsPICDSCSel==1)||(dsPICDSCSel==2)||(dsPICDSCSel==3)||(dsPICDSCSel==4)||(dsPICDSCSel==5)||(dsPICDSCSel==6)||(dsPICDSCSel==7)||(dsPICDSCSel==8)||(dsPICDSCSel==9)||(dsPICDSCSel==10)||(dsPICDSCSel==11)||(dsPICDSCSel==12)||(dsPICDSCSel==13)||(dsPICDSCSel==14)
    set(handles.dsPICDSCTab.IPCommonPanel.DeviceClock,'String','70');
    set(handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1,'Enable','on');
    set(handles.dsPICDSCTab.Peripheralselection.PWMResolutionText2,'Enable','off');
    
    PWMSwitchingFrequency = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String);
    PWMSwitchingPeriod=1/(PWMSwitchingFrequency*1e3); 
    
% PWM_Switch_freqC =str2double(PWMSwitchingFrequency);
PWM_Res=handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1.Value;
switch PWM_Res

    case 1
        PWM_Res=2.08e-9;
    case 2
        PWM_Res=4.16e-9;
    case 3
        PWM_Res=8.32e-9;
end
% PWM_ResC=str2double(PWM_Res);
if ~isnan(PWMSwitchingFrequency)
PTPER=(PWMSwitchingPeriod)/(PWM_Res);
PTPERCal=round(PTPER,0);
handles.dsPICDSCTab.PTPERCalculated=PTPERCal;
handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String=handles.dsPICDSCTab.PTPERCalculated;
else
  handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String='';
end
% handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String=handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String;
else
    set(handles.dsPICDSCTab.IPCommonPanel.DeviceClock,'String','100');
    set(handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1,'Enable','on');
    set(handles.dsPICDSCTab.Peripheralselection.PWMResolutionText2,'Enable','on');
    
    PWMSwitchingFrequency = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String);
    PWMSwitchingPeriod=1/(PWMSwitchingFrequency*1e3); 
    
% PWM_Switch_freqC =str2double(PWMSwitchingFrequency);
PWM_Res=handles.dsPICDSCTab.Peripheralselection.PWMResolutionText2.Value;
switch PWM_Res

    case 1
        PWM_Res=2.08e-9;
    case 2
        PWM_Res=4.16e-9;
    case 3
        PWM_Res=8.32e-9;
end
% PWM_ResC=str2double(PWM_Res);
if ~isempty(PWMSwitchingFrequency)
PTPER=(PWMSwitchingPeriod)/(PWM_Res);
PTPERCal=round(PTPER,0);
handles.dsPICDSCTab.PTPERCalculated=PTPERCal;
handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String=handles.dsPICDSCTab.PTPERCalculated;
else
 handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String='';   
% handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String=handles.ControllerDesignTab.PWMConfiguration.IL.PTPER.String;
end
end
%% end