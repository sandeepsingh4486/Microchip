function GenerateProjectReport_GP(hObject,~)
handles=guidata(hObject);
makeDOMCompilable();
import mlreportgen.report.*
import mlreportgen.dom.*
fileContents = fileread('Chap2_1.txt');

%% standard equations
TwoP2Zstring= '\frac{K_{dc}(1+ \frac{s}{2\pi f_{z1}})}{s(1+\frac{s}{2\pi f_{p1}})}';
Cascadedstring='\frac{K_{dcx}(1+\frac{s}{2\pi f_{zx}})}{(1+\frac{s}{2\pi f_{px}})}';
ThreeP3Zstring= '\frac{K_{dc}(1+\frac{s}{2\pi f_{z1}})(1+\frac{s}{2\pi f_{z2}})}{s(1+\frac{s}{2\pi f_{p1}})(1+\frac{s}{2\pi f_{p2}})}';
Diffeq_DF1=' {y}={b_{0}*e[n]+b_{1}}*e[n-1]+.....+b_{N}*e[n-N]+..{a_{1}*y[n-1]+....a_{M}}*y[n-M]';
Zdomain_DF1='\frac{y_1}{e}=\frac{b_{10}-b_{11}z^{-1}}{1-a_{11}z^{-1}},\frac{y_2}{y_1}=\frac{b_{20}-b_{21}z^{-1}}{1-a_{21}z^{-1}},\frac{y}{y_2}=\frac{b_{30}-b_{31}z^{-1}}{1-a_{31}z^{-1}}';
Zdomain_Cascaded ='\frac{y_1}{e}=\frac{b_{10}+b_{11}z^{-1}}{1+a_{11}z^{-1}},\frac{y_2}{y_1}=\frac{b_{20}+b_{21}z^{-1}}{1+a_{21}z^{-1}},\frac{y}{y_2}=\frac{b_{30}+b_{31}z^{-1}}{1+a_{31}z^{-1}}';
Diffeq_DF1_Cascaded1='{y_1}[n]={b_{10}*e[n]+b_{11}*e[n-1]+a_{11}*y_1[n-1]}';
Diffeq_DF1_Cascaded2='{y_2}[n]={b_{20}*y_1[n]+b_{21}}*y_1[n-1]+a_{21}*y_2[n-1]';
Diffeq_DF1_Cascaded3='{y}[n]={b_{30}*y_2[n]+b_{31}}*y_2[n-1]+a_{31}*y_1[n-1]';
%% IPT1 Handles
%%IPT1 HANDLES

OLAO=handles.General_test.PlantInfo.OL.UDPPolynomialForm.OLPolyData.a0.String;

ILPOLES=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.PolesAtOrigin.String;
 ILP1=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.p1.String;
 ILP2=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.p2.String;
 ILP3=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.p3.String;
 ILP4=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.p4.String;
 ILP5=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.p5.String;
 ILGain=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.Kdc.String;
 ILZ1=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.z1.String;
 ILZ2=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.z2.String;
 ILZ3=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.z3.String;
 ILZ4=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.z4.String;
 ILZ5=handles.General_test.PlantInfo.IL.UDPPZForm.PZData.z5.String;

 OLPOLES=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.PolesAtOrigin.String;
 OLP1=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.p1.String;
 OLP2=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.p2.String;
 OLP3=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.p3.String;
 OLP4=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.p4.String;
 OLP5=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.p5.String;
 OLGain=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.Kdc.String;
 OLZ1=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.z1.String;
 OLZ2=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.z2.String;
 OLZ3=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.z3.String;
 OLZ4=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.z4.String;
 OLZ5=handles.General_test.PlantInfo.OL.UDPPZForm.PZData.z5.String;

NeutralEnable =  handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageSelection.Radio.VoltageEnable;
NeutralDisable = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageSelection.Radio.VoltageDisable;
CurrentTransformer = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer;
ShuntResistor  = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor;
CurrentMeas_sel=handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value;

% PWMSwitchingFreq = handles.SpecificationsTab.CommonSpecs.PWMSwitchingFreq.Fsw.String;

FilePath = handles.SpecificationsTab.FilePath.BodeFilePath.String;
UserSel = handles.SpecificationsTab.SelectionDropdowns.UserSelection.Value;

% OuterLoopPlant=handles.SpecificationsTab.PlantInfo.OL.PlantTF;

% Testbode = handles.bodeplot(bplot,OuterLoopPlant,bOptions);


%% IPT2 Handles

ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
ADCLat = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String;

Rfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String;
Rfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String;
Rfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String;
Cfb1 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String;
Cfb2 = handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String;

Rfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String;
Rfb5 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String;
Rfb6 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String;
Cfb3 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String;
Cfb4 = handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String;

Rfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String;
Rfb8 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String;
Cfb5 = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String;
PrimaryTurnsRatioNp = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String;
SecondaryTurnsRatioNs = handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String;

Rfb9 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String;
Rfb10 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String;
Rfb11 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String;
Cfb6 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String;
Rfb12 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String;
% Cfb7 = handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String;
Rfb13 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.String;
Rfb14 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.String;
Rfb15 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.String;
Cfb8 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.String;
Cfb9 = handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.String;



%% IPT3 Handles
%Controller type selection dropdown
CTSelection.OLControllerType= handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType;
CTSelection.ILControllerType=handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType;
ILCTSel=handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
OLCTSel=handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;

ILPWMFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String;
ILSampRatio = handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String;
ILPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String;
% ILMaxPWMSwitchingFreq = handles.ControllerDesignTab.PWMConfiguration.IL.MaxPWMSwitchingFreq.String;
% ILPWMResolution = handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String;
ILComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String;
ILGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String;
ILCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String;
ILPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String;
ILMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String;
ILMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String;

OLPWMFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String;
OLSampRatio = handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String;
OLPWMSampFreq = handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String;
%OLMaxPWMSwitchingFreq = handles.ControllerDesignTab.PWMConfiguration.OL.MaxPWMSwitchingFreq.String;
% OLPWMResolution = handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String;
OLComputationalDelay = handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String;
OLGateDriveDelay = handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String;
OLCrossOverFreq = handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String;
OLPhaseMargin = handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String;
OLMinControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String;
OLMaxControlOutput = handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String;
FsampOL= handles.ControllerDesignTab.PWMConfiguration.OL.PTPER.String;
% Ki=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;

ILCompensatorSel =handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
ILCompensator = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.String(ILCompensatorSel));
ILGain = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain.String;
ILPole1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1.String;
ILPole2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2.String;
% ILPole3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole3.String;
ILZero1 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1.String;
ILZero2 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2.String;
% ILZero3 = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero3.String;

ILP1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1.String;
ILZ1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1.String;
ILKdc1_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1.String;

ILP2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2.String;
ILZ2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2.String;
ILKdc2_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2.String;

ILP3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3.String;
ILZ3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3.String;
ILKdc3_cascaded = handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3.String;

OLCompensatorSel = handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;
OLCompensator = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.String(OLCompensatorSel));
OLGain = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain.String;
OLPole1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1.String;
OLPole2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2.String;
% OLPole3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole3.String;
OLZero1 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1.String;
OLZero2 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2.String;
% OLZero3 = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero3.String;

OLP1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1.String;
OLZ1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1.String;
OLKdc1_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1.String;

OLP2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2.String;
OLZ2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2.String;
OLKdc2_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2.String;

OLP3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3.String;
OLZ3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3.String;
OLKdc3_cascaded = handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3.String;


%% handles for GPT3
if isempty(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1.String)
    
    errordlg('"Run" the application before chosing "Generate Project Report" ','Error');
    
    return;
    
end

% Absolute Coefficients IL
B0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B0);
B1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B1);
B2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B2);
B3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B3);
B4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A0);
A1_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A1);
A2_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A2);
A3_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A3);
A4_Abs_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsAbs.A4);
%
% % Normalized Coefficients IL
B0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B0);
B1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B1);
B2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B2);
B3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B3);
B4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.B4);

% A0_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A0);
A1_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A1);
A2_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A2);
A3_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A3);
A4_Norm_IL_H = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsNorm.A4);
%
%% Cascaded Coefficients IL
%% the following handles are create for header file genaration
%%
% A10_IL_C = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_IL_C =  string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostShift);
PSC_IL_C=  string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostScalar);
%
% A20_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A20);
A21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_IL = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A30);
A31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_IL_C = string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B31);

%IL Normalized Q15 Parameters
IL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.Normal);
IL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostShift);
IL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsQ15Parameters.PostScalar);

%%
% % Absolute Coefficients OL
B0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B0);
B1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B1);
B2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B2);
B3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B3);
B4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.B4);

% A0_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A0);
A1_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A1);
A2_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A2);
A3_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A3);
A4_Abs_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsAbs.A4);

%% Normalized Coefficients OL
B0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B0);
B1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B1);
B2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B2);
B3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B3);
B4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.B4);

% A0_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A0);
A1_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A1);
A2_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A2);
A3_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A3);
A4_Norm_OL_H = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsNorm.A4);


%% Cascaded Coefficients OL
%%
% A10_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A10;
A11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A11);
B10_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B10);
B11_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B11);
PS_OL_C  = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostShift);
PSC_OL_C= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostScalar);

% A20_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A20;
A21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A21);
B20_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B20);
B21_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B21);

% A30_OL_C = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A30;
A31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A31);
B30_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B30);
B31_OL_C = string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B31);

%OL Normalized Q15 Parameters
OL_Norm_Normal= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.Normal);
OL_Norm_PostShift= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostShift);
OL_Norm_PostScalar= string(handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsQ15Parameters.PostScalar);
%% from the PlantTFComputation_PFC.m, this is to print the equations in the report generation
Ki_Dz=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital_Zf;
Kv_Dz=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital_Zf ;
GvdP = handles.SpecificationsTab.PlantInfo.OL.PlantTF;
GvcP = handles.SpecificationsTab.PlantInfo.Gvc.PlantTF ;
GidP = handles.SpecificationsTab.PlantInfo.IL.PlantTF;
GvifilterP = handles.FeedbackNetworkTab.FeedbackParameters.OL.IPFilterTF;
GvofilterP = handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
GciP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;% =Ki;Inner Loop Analaog Compensator
Ki_c_cascadedP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog; % Inner Loop Analaog Cascaded Compensator
GcoP = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog;%  = Kv;Outer Loop Analaog Compensator
GifilterP = handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;% =GInnerLoopFilter; Current feedback TF
GCLI_AP = handles.SpecificationsTab.PlantInfo.IL.ILCLTFAnalog; % =GCLI_A; Closed loop T/F Inner current loop Analog
Gvl_D = handles.SpecificationsTab.PlantInfo.OL.LoopGainDigitalTF;
Ki_dP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital;%=Ki_d; Inner loop Digital Compensator
Ki_d_cascaded_sectionsP = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Digital;
Kv_dP =handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital;
Kv_c_cascadedP = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Analog;
Kv_d_cascaded_sections =handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Digital ;
%ILAnalogCompensatorCascaded = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog;

%% Appedning Transfer function in the project report Generation
% Equations in chapter 2
ch2eq1 = Equation;
ch2eq2 = Equation;
ch2eq3 = Equation;
ch2eq4 = Equation;
ch2eq5 = Equation;
ch2eq6 = Equation;
ch2eq7 = Equation;
ch2eq8 = Equation;
ch2eq9 = Equation;
ch2eq10 = Equation;
Ch2OL_eq1 = Equation;
Ch2OL_eq2 = Equation;
Ch2OL_eq3 = Equation;
Ch2IL_eq1 = Equation;
Ch2IL_eq2 = Equation;
Ch2IL_eq3 = Equation;
% Equations in chapter 3
Ch3OL_eq1 = Equation;
Ch3OL_eq2 = Equation;
Ch3OL_eq3 = Equation;
Ch3IL_eq1 = Equation;
Ch3IL_eq2 = Equation;
Ch3IL_eq3 = Equation;
ch3eq1 = Equation;
ch3eq2=Equation;
%% Standard equations
eq1=Equation;   %2P2Z 
eq2=Equation;   %CASCADED
eq3=Equation;   %3P3Z
eq4=Equation;   % Diffeq_DF1
eq5=Equation;   %Zdomain_DF1;
eq6=Equation;   %Zdomain_Cascaded;
eq7=Equation;   %Diffeq_DF1_Cascaded1;
eq8=Equation;   %Diffeq_DF1_Cascaded2;
eq9=Equation;   %Diffeq_DF1_Cascaded3;

%% Standard equations content : Can be replaced with the images of standard equation
eq1.Content=TwoP2Zstring;
eq2.Content=Cascadedstring;
eq3.Content=ThreeP3Zstring;
eq4.Content=Diffeq_DF1;
eq5.Content=Zdomain_DF1;
eq6.Content=Zdomain_Cascaded;
eq7.Content=Diffeq_DF1_Cascaded1;
eq8.Content=Diffeq_DF1_Cascaded2;
eq9.Content=Diffeq_DF1_Cascaded3;

%%
[numer,denom] = Append_TF_sys(GidP);
ch2eq1.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvcP);
ch2eq2.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvdP);
%[numer,denom] = Append_TF1(GvdP);
ch2eq3.Content = ['\frac{' numer '}{' denom '}'] ;
% Gvifilter, I/P Voltage Measurement Network T/F
[numer,denom] = Append_TF_sys(GvifilterP);
ch2eq5.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GvofilterP);
ch2eq6.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GciP);
ch2eq8.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF_sys(GcoP);
ch2eq10.Content = ['\frac{' numer '}{' denom '}'];
[numer,denom] = Append_TF_sys(GifilterP);
ch2eq7.Content = ['\frac{' numer '}{' denom '}'];
[numer,denom]= Append_TF_sys (GCLI_AP);
ch2eq9.Content = ['\frac{' numer '}{' denom '}'] ;
ch2eq9.FontSize = 27;
GvcP_ZPK = zpk(GvcP);                                % T/F in S domain ZPK
GvcP_ZPK.DisplayFormat = 'frequency';               % T/F ZPK
[numer,denom]= Append_TF1(GvcP_ZPK);
ch2eq4.Content = ['\frac{' numer '}{' denom '}']; % In LaTex format

switch ILCTSel
    case 1
        [numer1 denom1 numer2 denom2]= Append_TF_CASCADED_2eq(Ki_c_cascadedP);
        Ch2IL_eq1.Content = ['\frac{' numer1 '}{' denom1 '}'];% In LaTex format
        Ch2IL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        [numer1 denom1 numer2 denom2]= Append_TF_CASCADED_2eq(Ki_d_cascaded_sectionsP);
        Ch2IL_eq3.Content = ['\frac{' numer1 '}{' denom1 '}'];% In LaTex format
        Ch3IL_eq1.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format;
        
    case 2
        [numer1 denom1 numer2 denom2 numer3 denom3]= Append_TF_CASCADED(Ki_c_cascadedP);
        Ch2IL_eq1.Content = ['\frac{' numer1 '}{' denom1 '}'];% In LaTex format
        Ch2IL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        Ch2IL_eq3.Content = ['\frac{' numer3 '}{' denom3 '}'];% In LaTex format
        [numer1 denom1 numer2 denom2 numer3 denom3 ]= Append_TF_CASCADED(Ki_d_cascaded_sectionsP);
        Ch3IL_eq1.Content = ['\frac{' numer1 '}{' denom2 '}'];% In LaTex format
        Ch3IL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        Ch3IL_eq3.Content = ['\frac{' numer3 '}{' denom3 '}'];% In LaTex format
end
switch OLCTSel
    case 1
        
        [numer1 denom1 numer2 denom2 ]= Append_TF_CASCADED_2eq(Kv_c_cascadedP);
        Ch2OL_eq1.Content = ['\frac{' numer1 '}{' denom2 '}'];% In LaTex format
        Ch2OL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        [numer1 denom1 numer2 denom2 ]= Append_TF_CASCADED_2eq(Kv_d_cascaded_sections);
        Ch2OL_eq3.Content = ['\frac{' numer1 '}{' denom2 '}'];% In LaTex format
        Ch3OL_eq1.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        
        
    case 2
        [numer1 denom1 numer2 denom2 numer3 denom3]= Append_TF_CASCADED(Kv_c_cascadedP);
        Ch2OL_eq1.Content = ['\frac{' numer1 '}{' denom1 '}'];% In LaTex format
        Ch2OL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        Ch2OL_eq3.Content = ['\frac{' numer3 '}{' denom3 '}'];% In LaTex format
        [numer1 denom1 numer2 denom2 numer3 denom3]= Append_TF_CASCADED(Kv_d_cascaded_sections);
        Ch3OL_eq1.Content = ['\frac{' numer1 '}{' denom1 '}'];% In LaTex format
        Ch3OL_eq2.Content = ['\frac{' numer2 '}{' denom2 '}'];% In LaTex format
        Ch3OL_eq3.Content = ['\frac{' numer3 '}{' denom3 '}'];% In LaTex format
end
[numer,denom] = Append_TF1(Ki_Dz);
ch3eq1.Content = ['\frac{' numer '}{' denom '}'] ;
[numer,denom] = Append_TF1(Kv_Dz);
ch3eq2.Content = ['\frac{' numer '}{' denom '}'] ;

%%
%% Table contents
%% chapter 2 tables
%% Table1 Power Stage Parameters

ch2table1 = Table(4);
ch2table1.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table1.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table1,row);

for i=1:7
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Input AC Voltage (Vin)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',MinVoltage)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Vrms']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Output DC Voltage (Vdc)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OutputVoltage)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Vdc']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Output Power (Po)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OutputPower)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Watts']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Inductance (L1 = L2) ']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Inductance)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['uH']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['DC Resistance (DCR)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Inductor_DCR)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['mOhm']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Capacitance (Co)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Capacitance)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['uF']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Capacitor(Co)ESR']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Capacitor_ESR)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['mOhm']));
        append(row,te);
        
        append(ch2table1,row);
    end
    
end
ch2table2 = Table(4);
ch2table2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table2.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table2,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb1)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table2,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb2)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table2,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb3)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table2,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C1 ']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb1)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table2,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb2)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table2,row);
    end
end
ch2table3 = Table(4);
ch2table3.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table3.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table3,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R13']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb13)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table3,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R14']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb14)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table3,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R15']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb15)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table3,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C8 ']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb8)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table3,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C9']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb9)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table3,row);
    end
end
ch2table4 = Table(4);
ch2table4.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table4.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table4,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb4)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table4,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R5']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb5)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table4,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R6']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb6)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table4,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C3 ']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb3)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table4,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb4)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table4,row);
    end
end
ch2table5 = Table(4);
ch2table5.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table5.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table5,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R7']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb7)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table5,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R8']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb8)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table5,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C5']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb5)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table5,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Primary Turns Ratio']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',PrimaryTurnsRatioNp)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['-']));
        append(row,te);
        
        append(ch2table5,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Secondary Turns Ratio']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',SecondaryTurnsRatioNs)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['-']));
        append(row,te);
        
        append(ch2table5,row);
    end
end
ch2table5_2 = Table(4);
ch2table5_2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table5_2.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table5_2,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R9']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb9)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['mOhm']));
        append(row,te);
        
        append(ch2table5_2,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R10']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb10)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table5_2,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R11']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb11)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table5_2,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['C6 ']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Cfb6)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['pF']));
        append(row,te);
        
        append(ch2table5_2,row);
    end
    
    
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['R12']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',Rfb12)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kOhm']));
        append(row,te);
        
        append(ch2table5_2,row);
    end
end

ch2table6 = Table(4);
ch2table6.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table6.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table6,row);

for i=1:9
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['PWM Switching frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPWMFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kHz']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Sampling Ratio']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILSampRatio)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['-']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['PWM Sampling Frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPWMSampFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kHz']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    %         if i == 4
    %             row = TableRow();
    %
    %             te = TableEntry();
    %             append(te,Text([num2str(i) ]));
    %             append(row,te);
    %
    %             te = TableEntry();
    %             append(te,Text(['Maximum Voltage Switching Frequency']));
    %             append(row,te);
    %
    %             te = TableEntry();
    %             append(te,Paragraph(sprintf('%s',FsampOL)));
    %             append(row,te);
    %
    %             te = TableEntry();
    %             append(te,Text(['kHz']));
    %             append(row,te);
    %
    %             append(table4,row);
    %         end
    %
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Computational Delay']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILComputationalDelay)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['ns']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gate Drive Delay']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILGateDriveDelay)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['ns']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Cross Over Frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILCrossOverFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Hz']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Phase Margin']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPhaseMargin)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['deg']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Control Output(Min)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILMinControlOutput)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Control Output(Max)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILMaxControlOutput)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['']));
        append(row,te);
        
        append(ch2table6,row);
    end
    
end
ch2table7 = Table(3);
ch2table7.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table7.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table7,row);


for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILGain )));
        append(row,te);
        append(ch2table7,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPole1)));
        append(row,te);
        append(ch2table7,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPole2)));
        append(row,te);
        append(ch2table7,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZero1)));
        append(row,te);
        append(ch2table7,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZero2)));
        append(row,te);
        append(ch2table7,row);
    end
end
ch2table7_2 = Table(3);
ch2table7_2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table7_2.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table7_2,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILGain )));
        append(row,te);
        append(ch2table7_2,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILPole1)));
        append(row,te);
        append(ch2table7_2,row);
    end
    
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZero1)));
        append(row,te);
        append(ch2table7_2,row);
    end
    
end

ch2table8 = Table(4);
ch2table8.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table8.TableEntriesInnerMargin = '10px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(row, TableEntry('Units'));
append(ch2table8,row);

for i=1:10
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['PWM Switching frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPWMFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kHz']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Sampling Ratio']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLSampRatio)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['PWM Sampling Frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPWMSampFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kHz']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Maximum Voltage Switching Frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',FsampOL)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['kHz']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Computational Delay']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLComputationalDelay)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['ns']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gate Drive Delay']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLGateDriveDelay)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['ns']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Cross Over Frequency']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLCrossOverFreq)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Hz']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Phase Margin']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPhaseMargin)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['deg']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Control Output(Min)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLMinControlOutput)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
    if i == 10
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Control Output(Max)']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLMaxControlOutput)));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['']));
        append(row,te);
        
        append(ch2table8,row);
    end
    
end

ch2table9_1 = Table(3);
ch2table9_1.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table9_1.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table9_1,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLGain )));
        append(row,te);
        append(ch2table9_1,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPole1)));
        append(row,te);
        append(ch2table9_1,row);
    end
    
    
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZero1)));
        append(row,te);
        append(ch2table9_1,row);
    end
end

ch2table9_2 = Table(3);
ch2table9_2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table9_2.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table9_2,row);

for i=1:5
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLGain )));
        append(row,te);
        append(ch2table9_2,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPole1)));
        append(row,te);
        append(ch2table9_2,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLPole2)));
        append(row,te);
        append(ch2table9_2,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZero1)));
        append(row,te);
        append(ch2table9_2,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZero2)));
        append(row,te);
        append(ch2table9_2,row);
    end
end

ch2table10 = Table(3);
ch2table10.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table10.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table10,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILKdc1_cascaded)));
        append(row,te);
        append(ch2table10,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILP1_cascaded)));
        append(row,te);
        append(ch2table10,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZ1_cascaded)));
        append(row,te);
        append(ch2table10,row);
    end
end




ch2table11 = Table(3);
ch2table11.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table11.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table11,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILKdc2_cascaded)));
        append(row,te);
        append(ch2table11,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILP2_cascaded)));
        append(row,te);
        append(ch2table11,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZ2_cascaded)));
        append(row,te);
        append(ch2table11,row);
    end
end
ch2table12 = Table(3);
ch2table12.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table12.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table12,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILKdc3_cascaded)));
        append(row,te);
        append(ch2table12,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILP3_cascaded)));
        append(row,te);
        append(ch2table12,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',ILZ3_cascaded)));
        append(row,te);
        append(ch2table12,row);
    end
end

ch2table13 = Table(3);
ch2table13.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table13.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table13,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLKdc1_cascaded)));
        append(row,te);
        append(ch2table13,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLP1_cascaded)));
        append(row,te);
        append(ch2table13,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZ1_cascaded)));
        append(row,te);
        append(ch2table13,row);
    end
end



para103  = Paragraph(sprintf('Cascaded Controller2'));


ch2table14 = Table(3);
ch2table14.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table14.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table14,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLKdc2_cascaded)));
        append(row,te);
        append(ch2table14,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLP2_cascaded)));
        append(row,te);
        append(ch2table14,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZ2_cascaded)));
        append(row,te);
        append(ch2table14,row);
    end
end

ch2table15 = Table(3);
ch2table15.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch2table15.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch2table15,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Gain']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLKdc3_cascaded)));
        append(row,te);
        append(ch2table15,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Pole']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLP3_cascaded)));
        append(row,te);
        append(ch2table15,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Zero']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OLZ3_cascaded)));
        append(row,te);
        append(ch2table15,row);
    end
end


%% Text data for Chapter 2

ch2para1 = Paragraph(sprintf('This chapter discusses about the design values given by the user for power factor correction.'));
ch2para2 = Paragraph(sprintf('Chosen Power factor Correction Topology is %s ', Topology));
ch2para3 = Paragraph(sprintf('Chosen Control Method is %s',ControlMethod));
ch2para3.WhiteSpace='preserve';
ch2para4 = Paragraph(sprintf('Table2.1 shows the user entered design inputs'));
ch2para5 = Paragraph(sprintf('Power stage parameters are listed below in Table2.1'));
ch2para5.WhiteSpace='preserve';
ch2para6 = Paragraph(sprintf('Transfer Functions for the Power stage parameters listed in Table2.1'));
ch2para4.WhiteSpace='preserve';
ch2para7 = Paragraph(sprintf(' Transfer Function between Duty to Inductor Current , Inner Loop Transfer Function (Gid), '));
ch2para6.WhiteSpace='preserve';
ch2para8 = Paragraph(sprintf(' Transfer Function between Control to Output Voltage, Outer Loop Transfer Function (Gvc), '));
ch2para7.WhiteSpace='preserve';
ch2para9 = Paragraph(sprintf(' Transfer Function between Duty to Output Voltage, Outer Loop Transfer Function (Gvd), '));
ch2para8.WhiteSpace='preserve';
ch2para10 = Paragraph(sprintf(' Bode Plot of Outer Loop Transfer Function (Gvd)'));
ch2para10.Bold = true;
ch2para9.WhiteSpace='preserve';
ch2para11 = Paragraph(sprintf(' Bode Plot of Inner Loop Transfer Function (Gid)'));
ch2para11.Bold = true;
ch2para10.WhiteSpace='preserve';
ch2para12 = Paragraph(sprintf(' Bode Plot of Control to Output Voltage Loop Transfer Function (Gvc)'));
ch2para12.Bold = true;
ch2para11.WhiteSpace='preserve';
ch2para13 = Paragraph(sprintf(' Bode Plot of IputVoltage Sensing network (Gvifilter)'));
ch2para13.Bold = true;
ch2para12.WhiteSpace='preserve'
ch2para14 = Paragraph(sprintf(' Bode Plot of OutputVoltage Sensing network (Gvofilter)'));
ch2para14.Bold = true;
ch2para13.WhiteSpace='preserve'
ch2para15 = Paragraph(sprintf(' Bode Plot of Current Sensing network (GifilterP)'));
ch2para15.Bold = true;
ch2para14.WhiteSpace='preserve'
ch2para16 = Paragraph(sprintf(' Chosen Topology High Level Circuit Schematic'));
ch2para16.Bold = true;
ch2para15.WhiteSpace='preserve'
ch2para17 = Paragraph(sprintf(' Closed Loop Transfer Function - Inner Loop Analog'));
ch2para17.Bold = true;
ch2para16.WhiteSpace='preserve'
ch2para18 = Paragraph(sprintf('Outer Loop Transfer Function (Gvc) in Pole Zero form'));
ch2para18.Bold = true;
ch2para17.WhiteSpace='preserve'
ch2para19 = Paragraph(sprintf('Bode plot of Closed Loop Transfer Function - Inner Loop Analog'));
ch2para19.Bold = true;
ch2para18.WhiteSpace='preserve'
if CurrentMeas_sel==1
    ch2para20= Paragraph(sprintf('The Current Measurement Technique is Current Transformer'));
else
    ch2para20= Paragraph(sprintf('The Current Measurement Network is Shunt'));
end
if NeutralEnable.Value==1
    ch2para21= Paragraph(sprintf('The AC Line and Neutral  Voltage Measurement is Chosen'));
else
    ch2para21= Paragraph(sprintf('The AC Line Voltage Measurement is Chosen'));
end

ch2para21 = Paragraph(sprintf('User Entered Feedback Network Parameters'));
ch2para22 = Paragraph(sprintf('PFC control system needs Input Voltage measurement, Output Voltage measurement and Current measurement values and Table2.2 shows the user entered feedback network design parameters'));
ch2para23 = Paragraph(sprintf('Input Voltage Measurement network parameters are listed below in Table 2.2'));
ch2para24 = Paragraph(sprintf('Input Voltage Measurement Network Transfer Function (Gvifilter)'));
ch2para25 = Paragraph(sprintf('Output voltage measurement network parameters are listed below in Table2.3'));
ch2para26 = Paragraph(sprintf('Output Voltage Measurement Network Transfer Function (Gvofilter)'));
ch2para27 = Paragraph(sprintf('\n Here current measurement is done by current transformer and the parameters are as shown in Table2.4'));
ch2para28 = Paragraph(sprintf('Current Measurement Network Transfer Function (Gifilter)'));
ch2para29 = Paragraph(sprintf('Here current measurement is done by shunt resistor and the parameters are as shown in Table2.4'));
ch2para30 = Paragraph(sprintf('The Control System Design Parameters'));
ch2para31 = Paragraph(sprintf('The control system design inputs chosen by user for the innerloop compensator are listed below in Table2.5'));
ch2para32 = Paragraph(sprintf('The Inner Loop Continious Time Domain Compensator Transfer Function'));
ch2para33 = Paragraph(sprintf('\n The control system inputs for the outerloop are listed below in Table2.5\n\n\n'));
ch2para34  = Paragraph(sprintf('The transfer function parameters for outer loop compensator are as follows'));
ch2para35 = Paragraph(sprintf('Cascaded Continious Time Domain Compensator Transfer Functions'));
ch2para36  = Paragraph(sprintf('Inner loop Continious Cascaded Controller Transfer Functions'));
ch2para37  = Paragraph(sprintf('Cascaded Controller2'));
ch2para38  = Paragraph(sprintf('Pole, Zero and Gain Parameters for inner loop cascaded controller are as follows'));
ch2para39  = Paragraph(sprintf('Cascaded Controller1'));
ch2para40  = Paragraph(sprintf('Cascaded Controller3'));
ch2para41  = Paragraph(sprintf('Outer loop Continious Cascaded Controller Transfer Functions'));
ch2para42  = Paragraph(sprintf('The transfer function parameters for outer loop cascaded controller are as follows'));
ch2para43  = Paragraph(sprintf('Cascaded Controller1'));
ch2para44  = Paragraph(sprintf('Cascaded Controller3'));

%% Table and Text data for Chapter 3
%%Chapter 3 tables

ch3table1 = Table(3);
ch3table1.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table1.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table1,row);

for i=1:9
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A1_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A2_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A3_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A4_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b0']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B0_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B1_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B2_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B3_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B4_Abs_IL_H)));
        append(row,te);
        append(ch3table1,row);
    end
    
end

ch3table2 = Table(3);
ch3table2.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table2.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table2,row);

for i=1:9
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A1_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A2_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A3_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A4_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b0']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B0_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B1_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B2_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B3_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B4_Norm_IL_H)));
        append(row,te);
        append(ch3table2,row);
    end
end

ch3table3 = Table(3);
ch3table3.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table3.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table3,row);
for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Normal']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',IL_Norm_Normal)));
        append(row,te);
        append(ch3table3,row);
    end
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Shift']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',IL_Norm_PostShift)));
        append(row,te);
        append(ch3table3,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Scalar']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',IL_Norm_PostScalar)));
        append(row,te);
        append(ch3table3,row);
    end
end

ch3table4 = Table(3);
ch3table4.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table4.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table4,row);

for i=1:9
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A1_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A2_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A3_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A4_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b0']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B0_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B1_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B2_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B3_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B4_Abs_OL_H)));
        append(row,te);
        append(ch3table4,row);
    end
    
end

ch3table5 = Table(3);
ch3table5.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table5.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table5,row);

for i=1:9
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A1_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A2_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A3_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 4
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A4_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 5
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b0']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B0_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 6
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b1']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B1_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 7
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b2']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B2_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 8
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b3']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B3_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
    
    if i == 9
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b4']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B4_Norm_OL_H)));
        append(row,te);
        append(ch3table5,row);
    end
end

ch3table6 = Table(3);
ch3table6.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table6.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table6,row);
for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Normal']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OL_Norm_Normal)));
        append(row,te);
        append(ch3table6,row);
    end
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Shift']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OL_Norm_PostShift)));
        append(row,te);
        append(ch3table6,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Scalar']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',OL_Norm_PostScalar)));
        append(row,te);
        append(ch3table6,row);
    end
end
ch3table7 = Table(3);
ch3table7.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table7.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table7,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a11']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A11_IL_C)));
        append(row,te);
        append(ch3table7,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b10']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B10_IL_C)));
        append(row,te);
        append(ch3table7,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b11']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B11_IL_C)));
        append(row,te);
        append(ch3table7,row);
    end
end
ch3table8 = Table(3);
ch3table8.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table8.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table8,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a21']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A21_IL_C)));
        append(row,te);
        append(ch3table8,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b20']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B20_IL_C)));
        append(row,te);
        append(ch3table8,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b21']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B21_IL_C)));
        append(row,te);
        append(ch3table8,row);
    end
end

ch3table9 = Table(3);
ch3table9.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table9.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table9,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a31']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A31_IL_C)));
        append(row,te);
        append(ch3table9,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b30']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B30_IL_C)));
        append(row,te);
        append(ch3table9,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b31']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B31_IL_C)));
        append(row,te);
        append(ch3table9,row);
    end
end

ch3table10 = Table(3);
ch3table10.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table10.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table10,row);

for i=1:2
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Shift']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',PS_IL_C)));
        append(row,te);
        append(ch3table10,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Scalar']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',PSC_IL_C)));
        append(row,te);
        append(ch3table10,row);
    end
    
    
end
ch3table11 = Table(3);
ch3table11.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table11.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table11,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a11']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A11_OL_C)));
        append(row,te);
        append(ch3table11,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b10']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B10_OL_C)));
        append(row,te);
        append(ch3table11,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b11']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B11_OL_C)));
        append(row,te);
        append(ch3table11,row);
    end
end

ch3table12 = Table(3);
ch3table12.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table12.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table12,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a21']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A21_OL_C)));
        append(row,te);
        append(ch3table12,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b20']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B20_OL_C)));
        append(row,te);
        append(ch3table12,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b21']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B21_OL_C)));
        append(row,te);
        append(ch3table12,row);
    end
end

ch3table13 = Table(3);
ch3table13.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table13.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table13,row);

for i=1:3
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['a31']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',A31_OL_C)));
        append(row,te);
        append(ch3table13,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b30']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B30_OL_C)));
        append(row,te);
        append(ch3table13,row);
    end
    
    if i == 3
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['b31']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',B31_OL_C)));
        append(row,te);
        append(ch3table13,row);
    end
end

ch3table14 = Table(3);
ch3table14.Style = {Border('solid'),RowSep('solid'),ColSep('solid')};
ch3table14.TableEntriesInnerMargin = '6px';
row = TableRow;
append(row, TableEntry('S.No'));
append(row, TableEntry('Parameter'));
append(row, TableEntry('Value'));
append(ch3table14,row);

for i=1:2
    if i == 1
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Shift']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',PS_OL_C)));
        append(row,te);
        append(ch3table14,row);
    end
    
    if i == 2
        row = TableRow();
        
        te = TableEntry();
        append(te,Text([num2str(i) ]));
        append(row,te);
        
        te = TableEntry();
        append(te,Text(['Post Scalar']));
        append(row,te);
        
        te = TableEntry();
        append(te,Paragraph(sprintf('%s',PSC_OL_C)));
        append(row,te);
        append(ch3table14,row);
    end
    
end
%%
%Text
ch3para1  = Paragraph(sprintf('Discretization of controller'));
ch3para2  = Paragraph(sprintf('In order to translate the S- Domain transfer function of the controller to a form acceptable to a digital controller the bilinear, or �Tustin� transformation is used. Using this transformation, the S � domain transfer function can be converter to Z- domain transfer function. By taking inverse Z � Transform of this Z - domain transfer function we obtain the equation of the compensator which can be programmed into the Digital Signal Controller (DSC).'));
ch3para3  = Paragraph(sprintf('The expression relating the complex frequencies �S� and �Z� is given by   Z = e^(s*Ts)and This expression can be approximated using Pade�s approximation,' ));
ch3para4  = Paragraph(sprintf('Substituting the Tustin transformation equation into  Continious Time Domain Compensator Transfer Function' ));
ch3para5  = (sprintf('e = present voltage error\n\n     y = present output    e[n-1] = previous error      e[n-2] = Error previous to e[n-1]    e[n-3] = Error previous to e[n-2]       y[n-1]  = previous output     y[n-2] = Output previous to y[n-1]    y[n-3] = Output previous to y[n-2]      a0, a1, a2, a3, b1, b2, b3 are coefficients of the digital compensator'));
ch3para6  = Paragraph(sprintf('Innerloop Digital Coefficients - Direct Form 1'));
ch3para7  = Paragraph(sprintf('Absolute Coefficients are '));
ch3para8  = Paragraph(sprintf('Normalized Coefficients are '));
ch3para9  = Paragraph(sprintf('Scaling factor'));
ch3para10  = Paragraph(sprintf('Outerloop Digital Coeficients - Direct Form 1'));
ch3para11  = Paragraph(sprintf('Absolute Coefficients are '));
ch3para12  = Paragraph(sprintf('Normalized Coefficients are '));
ch3para13  = Paragraph(sprintf('Scaling factor'));
ch3para14 = Paragraph(sprintf('The Inner Loop Compensator Digital Cascaded Transfer Function is '));
ch3para15  = Paragraph(sprintf('Inner Loop-Cascaded Coefficients are '));
ch3para16  = Paragraph(sprintf('Cascaded Compensator1'));
ch3para17  = Paragraph(sprintf('Cascaded Compensator2'));
ch3para18  = Paragraph(sprintf('Cascaded Compensator3'));
ch3para19  = Paragraph(sprintf('Scaling Factor (Inner Loop - Cascaded)'));
ch3para20 = Paragraph(sprintf('The Inner Loop Cascaded compensator1 Transfer functions are '));
ch3para21  = Paragraph(sprintf('Outer Loop - Cascaded Coefficients are '));
ch3para22  = Paragraph(sprintf('Cascaded Compensator1'));
ch3para23  = Paragraph(sprintf('Cascaded Compensator2'));
ch3para24  = Paragraph(sprintf('Cascaded Compensator3'));
ch3para25  = Paragraph(sprintf('Scaling Factors (Outer loop Cascaded)'));
ch3para26  = Paragraph(sprintf('Outer loop digital Cascaded Controller Transfer Functions'));
ch3para27 = Paragraph(sprintf('Control Loop diagram is given as '));

%%
rpt = Report('PSDS','pdf');
% getMainPartPath(rpt)
NL = newline();

add(rpt,TitlePage ('Title','PowerSmart� Development Suite',...
    'Author','Microchip Technology Inc'))

% NL = newline();
% add(rpt,mlreportgen.report.TitlePage('Title','PowerSmart� Development Suite',...
%                                      'Author','Microchip Technology Inc'))

image = FormalImage();
image.Image = which('MCHPTitle.png');
add(rpt,image);

% image = FormalImage();
% image.Image = which('Testbode');
% add(rpt,image);

add(rpt,mlreportgen.report.TableOfContents)
%% Chapter1

ch1 = mlreportgen.report.Chapter('Title','Introduction');
% add(ch1,mlreportgen.dom.Text...
%    ('Power Factor Correction - an important concept imposed by regulatory standards'))

%% Adding text in Chapter 1

fid = fopen('Introduction.txt','rt');
Introduction = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
add(ch1,Introduction );
add(rpt,ch1);

%% Chapter2

ch2 = mlreportgen.report.Chapter('Title','User Design Inputs');

%
%% Comment: Selected Topology and Control Method
add(ch2,ch2para1);
add(ch2,ch2para2);
add(ch2,ch2para3);
add(ch2,ch2para20);
append(ch2para3,NL);
add(ch2,ch2para16);
ch2para16.Bold = true;
append(ch2para16,NL);
switch TopologySel
    case 1
        if NeutralEnable.Value==1 && CurrentTransformer.Value==1
            img9 = FormalImage();
            img9.Image = which('SingleLNCT.png');
            add(ch2, img9);
        elseif NeutralEnable.Value==1 && ShuntResistor.Value==1
            img9 = FormalImage();
            img9.Image = which('SingleLNShunt.png');
            add(ch2, img9);
        elseif NeutralDisable.Value==1 && CurrentTransformer.Value==1
            img9 = FormalImage();
            img9.Image = which('SingleLCT.png');
            add(ch2, img9);
            
        elseif NeutralDisable.Value==1 && ShuntResistor.Value==1
            img9 = FormalImage();
            img9.Image = which('SingleLShunt.png');
            add(ch2, img9);
        else
            img9 = FormalImage();
            img9.Image = which('SingleLCT.png');
            add(ch2, img9);
        end
    case 2
        if NeutralEnable.Value==1 && CurrentTransformer.Value==1
            
            img10 = FormalImage();
            img10.Image = which('InterleavedLNCT.png');
            add(ch2, img10);
            
        elseif NeutralEnable.Value==1 && ShuntResistor.Value==1
            img10 = FormalImage();
            img10.Image = which('InterleavedLNShunt.png');
            add(ch2, img10);
        elseif NeutralDisable.Value==1 && CurrentTransformer.Value==1
            img10 = FormalImage();
            img10.Image = which('InterleavedLCT.png');
            add(ch2, img10);
            
        elseif NeutralDisable.Value==1 && ShuntResistor.Value==1
            img10 = FormalImage();
            img10.Image = which('InterleavedLShunt.png');
            add(ch2, img10);
        else
            img10 = FormalImage();
            img10.Image = which('InterleavedLCT.png');
            add(ch2, img10);
        end
    case 3
        if NeutralEnable.Value==1 && CurrentTransformer.Value==1
            
            img11 = FormalImage();
            img11.Image = which('SemiLNCT.png');
            add(ch2, img11);
            
        elseif NeutralEnable.Value==1 && ShuntResistor.Value==1
            img11 = FormalImage();
            img11.Image = which('SemiLNShunt.png');
            add(ch2, img11);
        elseif NeutralDisable.Value==1 && CurrentTransformer.Value==1
            img11 = FormalImage();
            img11.Image = which('SemiLCT.png');
            add(ch2, img11);
            
        else
            img11 = FormalImage();
            img11.Image = which('SemiLCT.png');
            add(ch2, img11);
        end
end

ch2para3.WhiteSpace='preserve';
add(ch2,ch2para4);
add(ch2,ch2para5);
ch2para5.WhiteSpace='preserve';
append(ch2para3,NL);
%% Comment: User Entered Design Specifications in tabel format (Table 1)

add (ch2, ch2table1);
add (ch2,ch2para7);
add (ch2,ch2eq1);          % Gid T.F
add (ch2,ch2para9);
add (ch2,ch2eq3);          % Gvd T.F
add (ch2,ch2para8);
add (ch2,ch2eq2);          % Gvc T.F
add (ch2,ch2para10);
add(ch2,ch2eq4);          % Gvc in ZPK

%% Plant TF Bode plot
%% Bode Options
bOptions=bodeoptions;
bOptions.Grid='on';
bOptions.FreqUnits='Hz';
bOptions.PhaseWrapping = 'on' ;
bOptions.MagUnits = 'dB';

fig3 = figure;
GvdPBode = bodeplot(GvdP,bOptions);
%  h1 = findobj(handles.UserBodeResponseTab.Subplot1.axis,'type','axes');
%  h3 = bodeplot(bplot,GvdP,bOptions); % GvdPBode
h3 = findobj(GvdPBode,'type','axes');
% h3 = findobj(handles.PlotsTab.PlotsAxes.BodePlotAx,'type','axes');
% h4 = findobj(handles.PlotsTab.PlotsAxes.BodePlotAx,'type','axes');
copyobj(h3,fig3);
saveas(fig3,'Outer_Loop_Bode_Plot(Gvd).png');
close(fig3);
img3 = Image('Outer_Loop_Bode_Plot(Gvd).png');
img3.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para10);
add(ch2, img3);
fig4 = figure;
GidPBode = bodeplot(GidP,bOptions);
h4 = findobj(GidPBode,'type','axes');
copyobj(h4,fig4);
saveas(fig4,'Inner_Loop_Bode_Plot(Gid).png');
close(fig4);
img4 = Image('Inner_Loop_Bode_Plot(Gid).png');
img4.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para11);
add(ch2, img4);
fig5 = figure;
GvcPBode = bodeplot(GvcP,bOptions);
h5 = findobj(GvcPBode,'type','axes');
copyobj(h5,fig5);
saveas(fig5,'GvcPBodeplot.png');
close(fig5);
img5 = Image('GvcPBodeplot.png');
img5.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para18);
add(ch2, img5);

%% Plant Bode end
%%
add(ch2,ch2para21);
ch2para21.Bold = true;
add(ch2,ch2para22);

%% Table2 Input voltage measurements feedback parameters
add(ch2,ch2para23);
append(ch2para23,NL);
add (ch2, ch2table2);
NL = newline();

ch2para24 = Paragraph(sprintf('Input Voltage Measurement Network Transfer Function (Gvifilter)'));
add(ch2,ch2para24);
add (ch2,ch2eq5);          % Gvifilter T.F

fig6 = figure;
GvifilterPBode = bodeplot(GvifilterP,bOptions);
h6 = findobj(GvifilterPBode,'type','axes');
copyobj(h6,fig6);
saveas(fig6,'Gvifilter.png');
close(fig6);
img6 = Image('Gvifilter.png');
img6.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para13);
add(ch2, img6);


if NeutralEnable.Value==1
    
    add (ch2, ch2table3);
end
%% Table3 Output voltage measurements(feedback parameters)

add(ch2,ch2para25)
append(ch2para25,NL);
add (ch2, ch2table4);
add(ch2,ch2para26);
add (ch2,ch2eq6);          % Gvofilter T.F
fig7 = figure;
GvofilterPBode = bodeplot(GvofilterP,bOptions);
h7 = findobj(GvofilterPBode,'type','axes');
copyobj(h7,fig7);
saveas(fig7,'Gvofilter.png');
close(fig7);
img7 = Image('Gvofilter.png');
img7.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para26);
add(ch2, img7);

if  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value==1
    
    add(ch2,ch2para27)
    append(ch2para27,NL);
    add (ch2, ch2table5);
    add(ch2,ch2para28);
    add (ch2,ch2eq7);          % Gifilter T.F
    fig8 = figure;
    GifilterPBode = bodeplot(GifilterP,bOptions);
    h8 = findobj(GifilterPBode,'type','axes');
    copyobj(h8,fig8);
    saveas(fig8,'GifilterP.png');
    close(fig8);
    img8 = Image('GifilterP.png');
    img8.Style = {Height('3.5in'),Width('7in')};
    add (ch2,ch2para15);
    add(ch2, img8);
    
    
elseif  handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value==1
    
    
    %     para119 = Paragraph(sprintf('Current measurement can be done either by current transformer or by shunt resistor'));
    %     add (ch2,para119);
    add(ch2,ch2para29)
    append(ch2para29,NL);
    add (ch2, ch2table5_2);
    add(ch2,ch2para28);
    add (ch2,ch2eq7);          % Gifilter T.F
    fig8 = figure;
    GifilterPBode = bodeplot(GifilterP,bOptions);
    h8 = findobj(GifilterPBode,'type','axes');
    copyobj(h8,fig8);
    saveas(fig8,'GifilterP.png');
    close(fig8);
    img8 = Image('GifilterP.png');
    img8.Style = {Height('3.5in'),Width('7in')};
    add (ch2,para212);
    add(ch2, img8);
    
end

%% Table4 Control system inputs for the innerloop

ch2para30.Bold = true;
add(ch2,ch2para30)
append(ch2para30,NL);

add(ch2,ch2para31)
append(ch2para31,NL);

add (ch2, ch2table6);

ch2para32.Bold = true;
add(ch2,ch2para32)
append(ch2para32,NL);
switch ILCTSel
    case 1
        para274 = Paragraph(sprintf('Selected Design - 2P2Z'));
        add(ch2,para274)
        add(ch2,eq1);
%         image2 = FormalImage();
%         image2.Image = which('2P2ZGP.png');
%         add(ch2, image2);
    case 2
        para274 = Paragraph(sprintf('Selected Design - 3P3Z'));
        add(ch2,para274);
        add(ch2,eq3);
%         image2 = FormalImage();
%         image2.Image = which('3P3ZGP.png');
%         add(ch2, image2);
end

%% Inner Loop Compensator Pole, Zero and Gain values In Table format


switch ILCTSel
    case 1
        para27 = Paragraph(sprintf('Computed Inner Loop Continious Time Domain Compensator Transfer Function'));
        add(ch2,para27)
        append(para27,NL);
        add (ch2,ch2eq8);
        para45  = Paragraph(sprintf('The Pole, Zero and Gain parameters for inner loop compensator are as follows'));
        add(ch2,para45);
        append(para45,NL);
        add (ch2, ch2table7_2);
    case 2
        para27 = Paragraph(sprintf('Computed Inner Loop Continious Time Domain Compensator Transfer Function'));
        add(ch2,para27)
        append(para27,NL);
        add (ch2,ch2eq8);
        para45  = Paragraph(sprintf('The Pole, Zero and Gain parameters for inner loop compensator are as follows'));
        add(ch2,para45);
        append(para45,NL);
        add (ch2, ch2table7);
end
% para27 = Paragraph(sprintf('Computed Inner Loop Continious Time Domain Compensator Transfer Function'));
% add(ch2,para27)
% append(para27,NL);
% add (ch2,eq6);
add (ch2,ch2para17);
append(ch2para17,NL);
add (ch2,ch2eq9);
fig12 = figure;         % Bode plot of Closed Loop Transfer Function - Inner Loop Analog
GCLI_APBode = bodeplot(GCLI_AP,bOptions);
h12 = findobj(GCLI_APBode,'type','axes');
copyobj(h12,fig12);
saveas(fig12,'GCLI_AP.png');
close(fig12);
img12 = Image('GCLI_AP.png');
img12.Style = {Height('3.5in'),Width('7in')};
add (ch2,ch2para19);
add(ch2, img12);

%% Table5 Outer loop Design input parameters
% break = PageBreak();         %% creates a page break object.
ch2para33.Bold = true;
add(ch2,ch2para33);
append(ch2para33,NL);
add (ch2, ch2table8);
ch2para34.Bold = true;
add(ch2,ch2para34);
append(ch2para34,NL);

switch OLCTSel
    case 1
        add(ch2,eq1);
        
    case 2
        add(ch2,eq3);
        
        
end
switch OLCTSel
    case 1
        para27 = Paragraph(sprintf('Computed Outer Loop Continious Time Domain Compensator Transfer Function'));
        add(ch2,para27)
        append(para27,NL);
        add (ch2,ch2eq10);
        para45  = Paragraph(sprintf('The Pole, Zero and Gain parameters for Outer loop compensator are as follows'));
        add(ch2,para45);
        append(para45,NL);
        add (ch2, ch2table9_1);
    case 2
        para27 = Paragraph(sprintf('Computed Outer Loop Continious Time Domain Compensator Transfer Function'));
        add(ch2,para27)
        append(para27,NL);
        add (ch2,ch2eq10);
        para45  = Paragraph(sprintf('The Pole, Zero and Gain parameters for Outer loop compensator are as follows'));
        add(ch2,para45);
        append(para45,NL);
        add (ch2, ch2table9_2);
end

%% Inner Loop Cascaded Compensator Pole, Zero and Gain values in Table
ch2para35.Bold = true;
add(ch2,ch2para35)
append(ch2para35,NL);
add(ch2,eq2);
ch2para36.Bold = true;
add(ch2,ch2para36);
switch ILCTSel
    case 1
        add(ch2, im1);
        add(ch2,Ch2IL_eq1);
        add(ch2,Ch2IL_eq2); 
    case 2
        add(ch2,Ch2IL_eq1);
        add(ch2,Ch2IL_eq2);
        add(ch2,Ch2IL_eq3); 
end

add (ch2, ch2table10);
add(ch2,ch2para37);
append(ch2para37,NL);
ch2para38.Bold = true;
add(ch2,ch2para38);
add(ch2,ch2para39);
append(ch2para39,NL);
append(ch2para38,NL);
add (ch2, ch2table11);
add(ch2,ch2para40);
append(ch2para40,NL);
append(ch2para38,NL);
add (ch2, ch2table12);
% switch ILCTSel
%     case 1
%        image1 = FormalImage();
%        image1.Image = which('2P2ZGP.png');
%          add(ch2, image1);
%     case 2
%         image1 = FormalImage();
%        image1.Image = which('3P3ZGP.png');
% 	    add(ch2, image1);
% end
% switch OLCTSel
%      image2 = FormalImage();
%        image2.Image = which('2P2ZGP.png');
%         add(ch2, image2);
%     case 2
%         image2 = FormalImage();
%        image2.Image = which('3P3ZGP.png');
% 	   add(ch2, image2);
% end

%%  cascaded equations Analog Outer loop
ch2para41.Bold = true;
add(ch2,ch2para41);
add(ch2,eq2);
switch OLCTSel
    case 1
        add(ch2,Ch2OL_eq1);
        add(ch2,Ch2OL_eq2);
        
    case 2
        add(ch2,Ch2OL_eq1);
        add(ch2,Ch2OL_eq2);
        add(ch2,Ch2OL_eq3);
        
end
ch2para42.Bold = true;
add(ch2,ch2para42);
add(ch2,ch2para43);
append(ch2para43,NL);
append(ch2para42,NL);
add (ch2, ch2table13);
add (ch2, ch2table14);
add(ch2,ch2para44);
append(ch2para44,NL);
append(ch2para42,NL);
add (ch2, ch2table15);
add(rpt,ch2);


%% Chapter3

ch3 = mlreportgen.report.Chapter('Title','Digital Coefficients');

%% Table6 Digital coefficients (Inner loop)

ch3para1.Bold = true;
add(ch3,ch3para2);
add(ch3,ch3para3);
img13 = FormalImage();
img13.Image = which('PadeApprox.png');
add(ch3, img13);
img14 = FormalImage();
img14.Image = which('Tustin.png');
add(ch3, img14);
add(ch3,ch3para4);
% add(ch3,eq7);
% add(ch3,eq8);
% add(ch3,eq9);
add(ch3,ch3para5);
para31 = Paragraph(sprintf('Direct form -I Difference equation is'));
add(ch3,para31);
add(ch3,eq4);
para32 = Paragraph(sprintf('Direct form -I Difference equation in Z domain is'));
add(ch3,para32)
add(ch3,eq5);
ch3para6.Bold = true;
ch3para7.Bold = true;
add(ch3,ch3para7);
append(ch3para6,NL);
append(ch3para7,NL);
add(ch3,ch3eq1);
add(ch3,ch3para6);
add (ch3, ch3table1);
ch3para8.Bold = true;
add(ch3,ch3para8);
append(ch3para8,NL);

add (ch3, ch3table2);

ch3para9.Bold = true;
add(ch3,ch3para9);
append(ch3para9,NL);


add (ch3, ch3table3);
%% Table11 Digital coefficients (Outer loop)
ch3para10.Bold = true;
ch3para11.Bold = true;
add(ch3,ch3para10);
append(ch3para10,NL);
append(ch3para11,NL);
add(ch3,ch3eq2);
add(ch3,ch3para11);
add (ch3, ch3table4);
ch3para12.Bold = true;
add(ch3,ch3para12);
append(ch3para12,NL);
add (ch3, ch3table5);
ch3para13.Bold = true;
add(ch3,ch3para13);
append(ch3para13,NL);


add (ch3, ch3table6);

%% Adding equation image
ch3para14.Bold = true;
add(ch3,ch3para14)
% append(para43,NL);
% append(para43,NL);
add(ch3,eq6);
add(ch3,eq7);
add(ch3,eq8);
add(ch3,eq9);
add(ch3,ch3para20)
switch ILCTSel
    case 1
        add(ch3,Ch2IL_eq3);%z
        add(ch3,Ch3IL_eq1);%z
    case 2
        add(ch3,Ch3IL_eq1);%z
        add(ch3,Ch3IL_eq2);%z
        add(ch3,Ch3IL_eq3);%z
end
ch3para15.Bold = true;
ch3para16.Bold = true;
add(ch3,ch3para15);
add(ch3,ch3para16);
append(ch3para15,NL);
append(ch3para16,NL);
add (ch3, ch3table7);

%%
ch3para17.Bold = true;
add(ch3,ch3para17);
append(ch3para17,NL);
add (ch3, ch3table8);

%%
ch3para18.Bold = true;
add(ch3,ch3para18);
append(ch3para18,NL);

add (ch3, ch3table9);
ch3para19.Bold = true;
add(ch3,ch3para19);
append(ch3para19,NL);
add (ch3, ch3table10);
ch3para21.Bold = true;
ch3para22.Bold = true;
add(ch3,ch3para21);
add(ch3,ch3para22);
append(ch3para21,NL);
append(ch3para22,NL);
switch OLCTSel
    case 1
        add(ch3,Ch2OL_eq3);
        add(ch3,Ch3OL_eq1);
        
        
    case 2
        
        add(ch3,Ch3OL_eq1);
        add(ch3,Ch3OL_eq2);
        add(ch3,Ch3OL_eq3);
end
add (ch3, ch3table11);

%%
ch3para23.Bold = true;
add(ch3,ch3para23);
append(ch3para23,NL);
add (ch3, ch3table12);

%%
ch3para24.Bold = true;
add(ch3,ch3para24);
append(ch3para24,NL);

add (ch3, ch3table13);
ch3para25.Bold = true;
add(ch3,ch3para25);
append(ch3para25,NL);

add (ch3, ch3table14);
ch3para26.Bold = true;
add(ch3,ch3para26);

add(ch3,ch3para27)
ch3para27.Bold = true;
append(ch3para27,NL);
image53 = FormalImage();
image53.Image = which('PowerReferencePFCDiagram.png');
add(ch3,image53)
%% end of chapter 3
add(rpt,ch3);
%% CH 4 ----- Plots
%% User defined Bode plot
% if ~isempty(handles.SpecificationsTab.FilePath.BodeFilePath.String)
    
if UserSel ==1 
ch4 = mlreportgen.report.Chapter('Title','User defined Bode plot');
% fig1 = figure;
% fig2 = figure;


    if handles.GPT4.Userbode.Radio.ILLoopPlantPlot.Value == 1
       ch4para1  = Paragraph(sprintf('The bode plot of the Inner loop plant for the user data is shown below '));
    elseif handles.GPT4.Userbode.Radio.OLLoopPlantPlot.Value == 1
        ch4para1  = Paragraph(sprintf('The bode plot of the Outer loop plant for the user data is shown below '));
    elseif handles.GPT4.Userbode.Radio.OLLoopGainDigPlot.Value ==1
        ch4para1  = Paragraph(sprintf('The bode plot of the Outer loop gain for the user data is shown below '));
     elseif handles.GPT4.Userbode.Radio.ILLoopGainDigPlot.Value ==1
        ch4para1  = Paragraph(sprintf('The bode plot of the Inner loop gain for the user data is shown below '));
    
    end
elseif UserSel ==2
    ch4para1  = Paragraph(sprintf('The bode plot by Bode Analyzer for the user data is shown below '));
end
ch4para1.Bold = true;
add(ch4,ch4para1);
append(ch4para1,NL);



fig = figure;
%h = findobj(handles.BODEPLOT,'type','axes');
h1 = findobj(handles.UserBodeResponseTab.Subplot1.axis,'type','axes');
h2 = findobj(handles.UserBodeResponseTab.Subplot2.axis,'type','axes');
% copyobj(h1,fig1);
% copyobj(h2,fig2);
copyobj(h1,fig);
copyobj(h2,fig);
saveas(fig,'User_Define_BPLOT.png');
%saveas(fig,'Phase.png');
% saveas(fig1,'Magnitude.png');
% saveas(fig2,'Phase.png');
%print(fig,'MySavedPlot','-dpng');
% close(fig1);
% close(fig2);
close(fig);
img = Image('User_Define_BPLOT.png');
%img2 = Image('Phase.png');
img.Style = {Height('5in'),Width('5in')};

add(ch4,img)

add(rpt,ch4);

% end

%% CH 5 ----- cascaded equations


%%  end of total report
close(rpt);
delete Outer_Loop_Bode_Plot(Gvd).png;
delete Inner_Loop_Bode_Plot(Gid).png;
delete GCLI_AP.png,
delete GifilterP.png;
delete Gvifilter.png;
delete Gvofilter.png;
delete User_Define_BPLOT.png;
delete GvcPBodeplot.png;
%delete PSDS.pdf
rptview(rpt);

