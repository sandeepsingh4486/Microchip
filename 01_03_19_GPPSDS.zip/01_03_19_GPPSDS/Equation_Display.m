function Equation_Display(hObject,~)
handles=guidata(hObject);
ILEQTEXT = handles.ControllerDesignTab.Panes.VariablePanes.EquationImagePane.IL.Equation;
OLEQTEXT = handles.ControllerDesignTab.Panes.VariablePanes.OLEquationImagePane.OL.Equation;
% ZILEQTXT=handles.ControlLoopDiagramTab.Panes.DigitalImagePanel.Equation.DigitalCompensatorImagePanel4;
Ki=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog ;
Kv=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog ;
Ki_d=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital;
FsampIL=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String)*1e3;
FsampOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String)*1e3;
Tsi = 1/(FsampIL);                             % Sampling time in sec for Current Loop
Tsv = 1/(FsampOL);                             % Sampling time in sec for Voltage Loop
% ThreeP3ZEquationImageAX.Parent = ILEquationImagePane.Equation;
% handles.ControllerDesignTab.axis = ThreeP3ZEquationImageAX;
hic= zpk(Ki);
hic.DisplayFormat = 'frequency';
hvc= zpk(Kv);
hvc.DisplayFormat = 'frequency';
[numCC,denCC] = tfdata(Ki_d,'v');              % To get the num, den of a inner loop compensator polynomial
Ki_Dz  = filt(numCC,denCC,Tsi);
Text_Ki=evalc('hic');
Text_Kv=evalc('hvc');
Text_KiDz=evalc('Ki_Dz');
delete(ILEQTEXT.Children);
delete(OLEQTEXT.Children);
EquationImageAX=axes(ILEQTEXT,'Position',[0 0 1 1]);
axis(EquationImageAX,'off');
t1 = text(EquationImageAX,...
    'string',Text_Ki,...
    'fontsize',10,...
    'units','norm',...
    'pos',[0.10 0.45]);
%     'interpreter','latex',...
%     'FontWeight','bold',... 
%  EquationImageAX.Parent=handles.ControllerDesignTab.Panes.VariablePanes.EquationImagePane.IL.Equation;
%  cla(handles.ControllerDesignTab.Panes.VariablePanes.EquationImagePane.IL.Equation.axis);
OLThreeP3ZEquationImageAX=axes(OLEQTEXT,'Position',[0 0 1 1]);
axis(OLThreeP3ZEquationImageAX,'off');

t2 = text(OLThreeP3ZEquationImageAX,...
    'string',Text_Kv,...
    'fontsize',10,...
    'units','norm',...
    'pos',[0.10 0.45]);
%     'interpreter','latex',...
% EquationImageAX=axes(ZILEQTXT,'Position',[0 0 1 1]);
% axis(EquationImageAX,'off');
% cla(EquationImageAX);
% t2 = text(EquationImageAX,...
%     'string',Text_Kv,...
%     'interpreter','latex',...
%     'fontsize',12,...
%     'units','norm',...
%     'pos',[0.1 0.2]);