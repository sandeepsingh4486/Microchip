function varargout = PowerSmart_Developement_Suite_GP(varargin)
% POWERSMART_DEVELOPEMENT_SUITE_GP MATLAB code for PowerSmart_Developement_Suite_GP.fig
%      POWERSMART_DEVELOPEMENT_SUITE_GP, by itself, creates a new POWERSMART_DEVELOPEMENT_SUITE_GP or raises the existing
%      singleton
%      H = POWERSMART_DEVELOPEMENT_SUITE_GP returns the handle to a new POWERSMART_DEVELOPEMENT_SUITE_GP or the handle to
%      the existing singleton
%      POWERSMART_DEVELOPEMENT_SUITE_GP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK n POWERSMART_DEVELOPEMENT_SUITE_GP.M with the given input arguments.
%
%      POWERSMART_DEVELOPEMENT_SUITE_GP('Property','Value',...) creates a new POWERSMART_DEVELOPEMENT_SUITE_GP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PowerSmart_Developement_Suite_GP_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PowerSmart_Developement_Suite_GP_OpeningFcn via varargin.
%
%      See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
% Edit the above text to modify the response to help PowerSmart_Developement_Suite_GP
% Last Modified by GUIDE
% Begin initialization code - DO NOT EDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @PowerSmart_Developement_Suite_GP_OpeningFcn, ...
    'gui_OutputFcn',  @PowerSmart_Developement_Suite_GP_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PowerSmart_Developement_Suite_GP is made visible.
function PowerSmart_Developement_Suite_GP_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PowerSmart_Developement_Suite_GP (see VARARGIN)

% Choose default command line output for PowerSmart_Developement_Suite_GP
clc
%% to get the full screen / maximuze window
% screensize =  get(0, 'Screensize');
% set(gcf, 'Position', screensize);


%% Creation of Tabs in Input Panel
tbgrp1=uitabgroup(handles.InputPanelPFC);
IPT1=uitab('Parent',tbgrp1,'Title','Plant T/F','ForegroundColor','[0 0 0]'); % Input Panel Specs Tab
IPT2=uitab('Parent',tbgrp1,'Title','Feedback','ForegroundColor','[0 0 0]'); % Input Panel Feedback Network Tab
IPT3=uitab('Parent',tbgrp1,'Title','Compensator','ForegroundColor','[0 0 0]'); % Input Panel Controller Design Tab
IPT4=uitab('Parent',tbgrp1,'Title','dsPIC� DSC','ForegroundColor','[0 0 0]'); % Input Panel dsPIC DSC Design Tab
IPT5=uitab('Parent',tbgrp1,'Title','Protections','ForegroundColor','[0 0 0]'); % Input Panel Protections Tab
IPT6=uitab('Parent',tbgrp1,'Title','Features','ForegroundColor','[0 0 0]'); % Input Panel BLPFC features

%% Creation of Tabs in Graphics Panel
tbgrp2=uitabgroup(handles.GraphicsPanelPFC);
GPT1=uitab('Parent',tbgrp2,'Title','Circuit','ForegroundColor','[0 0 0]'); % Graphics panel Circuit Tab
GPT2=uitab('Parent',tbgrp2,'Title','Plots','ForegroundColor','[0 0 0]'); % Graphics panel Plots Tab
GPT6=uitab('Parent',tbgrp2,'Title',' Cascaded Compensator Coefficients','ForegroundColor','[0 0 0]');
GPT3=uitab('Parent',tbgrp2,'Title','Compensator Coefficients (DF-I)','ForegroundColor','[0 0 0]'); % Graphics panel Compensator Coefficients Tab
GPT4=uitab('Parent',tbgrp2,'Title','User Bode Data Plot'); %
%% Updating Handles

%  date = datestr(now, 'dd/mm/yy-HH:MM');
%  set(handles.edit,'String',date);

TempData.ParentFigure=hObject;
TempData.ParentFigure.Name="PowerSmart� Development Suite-GP";
TempData.GUIProcesses.terminateFurtherExecution=0;
TempData.ProjectInformation.ProjName="BlankProj";
TempData.ProjectInformation.SavedStatus="";
TempData.GUIProcesses.terminateFurtherExecution=0;
TempData.Menu.File=handles.Menu_Files;
% TempData.Menu.Tools=handles.Menu_Tools;
TempData.Menu.OutputReport=handles.Menu_OutputReport;
TempData.Menu.Help=handles.Menu_Help;
TempData.Sliders.InputPaneSlider=handles.InputPaneSlider;
TempData.Sliders.GraphicsPaneSlider=handles.GraphicsPaneSlider;
handles=TempData;
%handles.output=hObject;
guidata(hObject,handles);

%% Tabs Designing

%% Input Pane Tabs Design
IPT1_GP_Design(IPT1, hObject)  % Input Panel Tab1 Design
IPT2_GP_Design(IPT2, hObject);  % Input Panel Tab2 Design
IPT3_GP_Design(IPT3, hObject);  % Input Panel Tab3 Design%
IPT4_GP_Design(IPT4, hObject);  % Input Panel Tab4 Design%
IPT5_GP_Design(IPT5, hObject);  % Input Panel Tab5 Design%
IPT6_GP_Design(IPT6, hObject);  % Input Panel Tab5 Design%


%% Graphics Pane Tabs Design

GPT1_GP_Design(GPT1, hObject);
GPT2_GP_Design(GPT2,hObject); % Graphics panel Tab2 Design
GPT3_GP_Design(GPT3,hObject); % Graphics panel Tab3 Design
GPT4_GP_Design(GPT4,hObject); % Graphics panel Tab4 Design
GPT6_GP_Design(GPT6,hObject); % Control loop diagram

handles=guidata(hObject);
GUIImages=findall(handles.ParentFigure,'type','Image');
Ax=GUIImages(1).Parent;
ImAxes(1:length(GUIImages))=Ax;
ImData=cell(1,length(GUIImages));
for i=1:length(GUIImages)
    ImAxes(i)=GUIImages(i).Parent;
    ImData{1,i}=GUIImages(i).CData;
end
handles.GUIProcesses.GUIImageData=ImData;
handles.GUIProcesses.GUIImagesAxes=ImAxes;
%handles.GUIProcesses.Figure_Max_Width_In_Pixels=1280;
handles.GUIProcesses.ResizingDone=0;
guidata(hObject,handles);


% UIWAIT makes PowerSmart_Developement_Suite_GP wait for user response (see UIRESUME)
% uiwait(handles.figure1);


%% Outputs from this function are returned to the command line.
function varargout = PowerSmart_Developement_Suite_GP_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.ParentFigure;


%% --- Executes on slider movement.
function InputPaneSlider_Callback(hObject, eventdata, handles)
% hObject    handle to InputPaneSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% pposIPT1=handles.SpecificationsTab.Panes.MovablePane.Position; % Movable Panes Position (All Movable panes)
pposIPT3=handles.ControllerDesignTab.Panes.MovablePane.Position;
% pposIPT4 = handles.dsPICDSCTab.Panes.MovablePane.Position;
% pposIPT5 = handles.FeaturesConfigurationParametersTab.Panes.MovablePane.Position;
spos=handles.Sliders.InputPaneSlider.Value;

% set(handles.SpecificationsTab.Panes.MovablePane,'Position',[pposIPT1(1) -1*spos pposIPT1(3) pposIPT1(4)]); % Changing IPT1 Movable Panel Position with Slider
set(handles.ControllerDesignTab.Panes.MovablePane,'Position',[pposIPT3(1) -1.115000*spos pposIPT3(3) pposIPT3(4)]); % Changing IPT3 Movable Panel Position with Slider
% set(handles.dsPICDSCTab.Panes.MovablePane,'Position',[pposIPT4(1) -1*spos pposIPT4(3) pposIPT4(4)]); % Changing IPT4 Movable Panel Position with Slider
% set(handles.FeaturesConfigurationParametersTab.Panes.MovablePane,'Position',[pposIPT5(1) -1*spos pposIPT5(3) pposIPT5(4)]); % Changing IPT5 Movable Panel Position with Slider
% set(handles.ControllerDesignTab.Panes.MovablePane,'Position',[pposIPT3(1) -1.944*spos pposIPT3(3) pposIPT3(4)]); % Changing IPT3 Movable Panel Position with Slider

% set(handles.MovablePanes.IPT2MovablePanel,'Position',[ppos(1) -0.75*spos ppos(3) ppos(4)]); % Changing IPT2 Movable Panel Position with Slider

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%% --- Executes during object creation, after setting all properties.
function InputPaneSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InputPaneSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%% --- Executes on slider movement.
function GraphicsPaneSlider_Callback(hObject, eventdata, handles)
% hObject    handle to GraphicsPaneSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pposGPT2=handles.PlotsTab.Panes.MovablePane.Position;
pposGPT3=handles.CompensatorCoefficientsTab.Panes.MovablePane.Position;
% pposGPT4=handles.test.Panes.MovablePane.Position;

spos=handles.Sliders.GraphicsPaneSlider.Value;
% set(handles.PlotsTab.Panes.MovablePane,'Position',[pposGPT2(1) -0.75*spos pposGPT2(3) pposGPT2(4)]);
% set(handles.CompensatorCoefficientsTab.Panes.MovablePane,'Position',[pposGPT3(1) -0.7690*spos  pposGPT3(3) pposGPT3(4)]);
% set(handles.CompensatorCoefficientsTab.Panes.MovablePane,'Position',[pposGPT3(1) 1.9450*spos  pposGPT3(3) pposGPT3(4)]);

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


%% --- Executes during object creation, after setting all properties.
function GraphicsPaneSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GraphicsPaneSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%%
function Menu_Files_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Files (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%%
function Menu_Tools_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Tools (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%% --------------------------------------------------------------------
function Menu_OutputReport_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_OutputReport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%% --------------------------------------------------------------------
function Menu_Help_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function About_Callback(hObject, eventdata, handles)
% hObject    handle to About (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen AboutPSDS.pdf        % this is the file name and to be named as "About PowerSamrt Development Suite"



% --------------------------------------------------------------------
function License_Callback(hObject, eventdata, handles)
% hObject    handle to License (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

winopen License.pdf     % This is the file name and to be named as "License"
% --------------------------------------------------------------------
function Bug_Callback(hObject, eventdata, handles)
% hObject    handle to Bug (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

f = msgbox('Please mail your query to psds.support@microchip.com','Bug Report');

% --------------------------------------------------------------------
function GenerateHeaderFile_Callback(hObject, eventdata, handles)
% hObject    handle to GenerateHeaderFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

OLPWMParam = handles.ControllerDesignTab.PWMConfiguration.OL;
ILPWMParam = handles.ControllerDesignTab.PWMConfiguration.IL;
if all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))&&(all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))&&~isempty(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String)
    
    if handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value==1
        if ~isempty(ILPWMParam.PWMFrequency.String)&&~isempty(ILPWMParam.SamplingRatio.String)&&~isempty(ILPWMParam.ComputationalDelay.String)&&~isempty(ILPWMParam.GateDriveDelay.String)&&~isempty(ILPWMParam.CrossOverFrequency.String)&&~isempty(ILPWMParam.PhaseMargin.String)&&~isempty(ILPWMParam.MinControlOutput.String)&&~isempty(ILPWMParam.MaxControlOutput.String)
            if ~isempty(OLPWMParam.SamplingRatio.String)&&~isempty(OLPWMParam.ComputationalDelay.String)&&~isempty(OLPWMParam.CrossOverFrequency.String)&&~isempty(OLPWMParam.PhaseMargin.String)&&~isempty(OLPWMParam.MinControlOutput.String)&&~isempty(OLPWMParam.MaxControlOutput.String)
                GenerateHeaderFile_GP(hObject);
            end
        else
            errordlg('Enter values in `Compensator` tab','Error')
            
        end
        
    elseif handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual.Value==1
        if ~isempty(ILPWMParam.PWMFrequency.String)&&~isempty(ILPWMParam.SamplingRatio.String)&&~isempty(ILPWMParam.ComputationalDelay.String)&&~isempty(ILPWMParam.GateDriveDelay.String)&&~isempty(ILPWMParam.MinControlOutput.String)&&~isempty(ILPWMParam.MaxControlOutput.String)
            if ~isempty(OLPWMParam.SamplingRatio.String)&&~isempty(OLPWMParam.ComputationalDelay.String)&&~isempty(OLPWMParam.MinControlOutput.String)&&~isempty(OLPWMParam.MaxControlOutput.String)
                GenerateHeaderFile_GP(hObject);
            end
            
        else
            errordlg('Enter values in `Compensator` tab','Error')
            
        end
    end
    else
    errordlg('Enter values in `Feedback` and `Compensator` tabs','Error')
end
% else
%     errordlg('Enter values in `Specifications`, `Feedback` and `Compensator` tabs','Error')
% end
%%
%%
function GenerateProjectReport_Callback(hObject, eventdata, handles)
% hObject    handle to GenerateProjectReport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OLPWMParam = handles.ControllerDesignTab.PWMConfiguration.OL;
ILPWMParam = handles.ControllerDesignTab.PWMConfiguration.IL;
if all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))&&(all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))&&~isempty(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String)
    
    if handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value==1
        if ~isempty(ILPWMParam.PWMFrequency.String)&&~isempty(ILPWMParam.SamplingRatio.String)&&~isempty(ILPWMParam.ComputationalDelay.String)&&~isempty(ILPWMParam.GateDriveDelay.String)&&~isempty(ILPWMParam.CrossOverFrequency.String)&&~isempty(ILPWMParam.PhaseMargin.String)&&~isempty(ILPWMParam.MinControlOutput.String)&&~isempty(ILPWMParam.MaxControlOutput.String)
            if ~isempty(OLPWMParam.SamplingRatio.String)&&~isempty(OLPWMParam.ComputationalDelay.String)&&~isempty(OLPWMParam.CrossOverFrequency.String)&&~isempty(OLPWMParam.PhaseMargin.String)&&~isempty(OLPWMParam.MinControlOutput.String)&&~isempty(OLPWMParam.MaxControlOutput.String)
                GenerateProjectReport_GP(hObject);
            end
        else
            errordlg('Enter values in `Compensator` tab','Error')
            
        end
        
    elseif handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual.Value==1
        if ~isempty(ILPWMParam.PWMFrequency.String)&&~isempty(ILPWMParam.SamplingRatio.String)&&~isempty(ILPWMParam.ComputationalDelay.String)&&~isempty(ILPWMParam.GateDriveDelay.String)&&~isempty(ILPWMParam.MinControlOutput.String)&&~isempty(ILPWMParam.MaxControlOutput.String)
            if ~isempty(OLPWMParam.SamplingRatio.String)&&~isempty(OLPWMParam.ComputationalDelay.String)&&~isempty(OLPWMParam.MinControlOutput.String)&&~isempty(OLPWMParam.MaxControlOutput.String)
                GenerateProjectReport_GP(hObject);
            end
            
        else
            errordlg('Enter values in `Compensator` tab','Error')
            
        end
    end
    
else
    errordlg('Enter values in `Specifications`, `Feedback` and `Compensator` tabs','Error')
end

% --------------------------------------------------------------------
function NewProject_Callback(hObject, eventdata, handles)
% hObject    handle to NewProject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))|| any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))||(any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
    WarningBeforeClosing(hObject,handles);
end
handles=guidata(hObject);
if handles.GUIProcesses.terminateFurtherExecution==1
    return;
else
    delete(handles.ParentFigure);
    PowerSmart_Developement_Suite_GP;
end

% --------------------------------------------------------------------
function OpenProject_Callback(hObject, eventdata, handles)
% hObject    handle to OpenProject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CurrentProj=handles.ProjectInformation.ProjName;

if(exist(strcat(CurrentProj,'.psds'),'file')==0 || isequal(CurrentProj,"BlankProj")) % This means that current project is not saved and thats why file with its name is not present in current directory
    if any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))||(any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
        WarningBeforeClosing(hObject,handles);
    end
    if handles.GUIProcesses.terminateFurtherExecution==1
        return;
    end
end

%% Opening Project
%%
[datafileName, pathName]=uigetfile('*.psds','Open Project');
try
    load(fullfile(pathName, datafileName),'-mat');
catch ErrorInOpening
    if ErrorInOpening.identifier=='MATLAB:load:pathIsDirectory'
        return;
    end
end
delete(gcbf);

% To make bode plot proper, it is required that axes is to be created
% again, otherwise as soon as plot generation function will be called
% magnitude plot will be split into 2 parts, one being magnitude other is
% phase plot
% bplotTab=handles.PlotsTab.PlotsAxes.BodePlotAx.Parent.Parent;
% rplotTab=handles.PlotsTab.PlotsAxes.RLPlotAx.Parent.Parent;
% nplotTab=handles.PlotsTab.PlotsAxes.NPlotAx.Parent.Parent;
% splotTab=handles.PlotsTab.PlotsAxes.SRPlotAx.Parent.Parent;
% uplotTab=handles.PlotsTab.PlotsAxes.URPlotAx.Parent.Parent;
%
% delete(handles.PlotsTab.PlotsAxes.BodePlotAx.Parent);
% delete(handles.PlotsTab.PlotsAxes.RLPlotAx.Parent);
% delete(handles.PlotsTab.PlotsAxes.NPlotAx.Parent);
% delete(handles.PlotsTab.PlotsAxes.SRPlotAx.Parent);
% delete(handles.PlotsTab.PlotsAxes.URPlotAx.Parent);
%
% bplotpane=uipanel(bplotTab);
% rplotpane=uipanel(rplotTab);
% nplotpane=uipanel(nplotTab);
% splotpane=uipanel(splotTab);
% uplotpane=uipanel(uplotTab);
%
% handles.PlotsTab.PlotsAxes.BodePlotAx=axes(bplotpane);
% handles.PlotsTab.PlotsAxes.RLPlotAx=axes(rplotpane);
% handles.PlotsTab.PlotsAxes.NPlotAx=axes(nplotpane);
% handles.PlotsTab.PlotsAxes.SRPlotAx=axes(splotpane);
% handles.PlotsTab.PlotsAxes.URPlotAx=axes(uplotpane);
%
guidata(handles.ParentFigure,handles);
OLManualCompDesign_GP(handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot,0);


function ExProject_Callback(hObject, eventdata, handles)
% hObject    handle to ExProject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%
function SaveAs_Callback(hObject, eventdata, handles)
% hObject    handle to SaveAs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
MenuSaveAs_Callback(hObject,handles)


% --------------------------------------------------------------------
function Save_Callback(hObject, eventdata, handles)
% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SaveProject_Callback(hObject,0);

% --------------------------------------------------------------------
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))||(any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
    WarningBeforeClosing(hObject,handles);
end
handles=guidata(hObject);
if handles.GUIProcesses.terminateFurtherExecution==1
    return;
else
    delete(handles.ParentFigure);
end

% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles=guidata(hObject);
handles.GUIProcesses.ResizingDone=1;
guidata(hObject,handles);

%% added by Ramesh to get the number of lines of code
% https://in.mathworks.com/matlabcentral/answers/106431-calculating-total-number-of-lines-in-a-file-opened-in-matlab

% fid = fopen('PowerSmart_Developement_Suite_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% PowerSmart_Developement_Suite_GP = numel(res)
% %%
% fid = fopen('IPT1_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% IPT1_GP_Design = numel(res)
% %%
% fid = fopen('IPT2_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% IPT2_GP_Design = numel(res)
% %%
% fid = fopen('IPT3_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% IPT3_GP_Design = numel(res)
% %%
% fid = fopen('IPT4_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% IPT4_GP_Design = numel(res)
% %%
% fid = fopen('GPT1_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% GPT1_GP_Design = numel(res)
% %%
% fid = fopen('GPT2Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% GPT2Design = numel(res)
% %%
% fid = fopen('GPT3_GP_Design.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% GPT3_GP_Design = numel(res)
% %%
% fid = fopen('BLGPAutoCompensatorDesign.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% BLGPAutoCompensatorDesign = numel(res)
% %%
% fid = fopen('AnalogCompensatorCoefficientsGeneration_GP_Cascaded.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% AnalogCompensatorCoefficientsGeneration_GP_Cascaded = numel(res)
% %%
% fid = fopen('bugRep.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% bugRep = numel(res)
% %%
% fid = fopen('cascaded_continuous_control_function.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% cascaded_continuous_control_function = numel(res)
% %%
% fid = fopen('cascaded_control_function.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% cascaded_control_function = numel(res)
% %%
% fid = fopen('CMCLoopGainComputation_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% CMCLoopGainComputation_GP = numel(res)
% %%
% fid = fopen('DigitalCompensatorCoefficientsGeneration_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% DigitalCompensatorCoefficientsGeneration_GP = numel(res)
% %%
% fid = fopen('DigitalCompensatorCoefficientsGeneration_GP_Cascaded.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% DigitalCompensatorCoefficientsGeneration_GP_Cascaded = numel(res)
% %%
% fid = fopen('FigureImageAdjusments.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% FigureImageAdjusments = numel(res)
% %%
% fid = fopen('GenerateHeaderFile_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% GenerateHeaderFile_GP = numel(res)
% %%
% fid = fopen('ILFBTFComputation_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% ILFBTFComputation_GP = numel(res)
% %%
% fid = fopen('ILManualCompDesign_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% ILManualCompDesign_GP = numel(res)
% %%
% fid = fopen('k_factor_function.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% k_factor_function = numel(res)
% %%
% fid = fopen('MenuSaveAs_Callback.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% MenuSaveAs_Callback = numel(res)
% %%
% fid = fopen('OLFBTFComputation_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% OLFBTFComputation_GP = numel(res)
% %%
% fid = fopen('OLManualCompDesign_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% OLManualCompDesign_GP = numel(res)
% %%
% fid = fopen('PlantTFComputation_GP.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% PlantTFComputation_GP = numel(res)
% %%
% fid = fopen('PlotGeneration.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% PlotGeneration = numel(res)
% %%
% fid = fopen('SaveProject_Callback.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% SaveProject_Callback = numel(res)
% %%
% fid = fopen('WarningBeforeClosing.m');
% res={};
% while ~feof(fid)
%   thisline = fgetl(fid);
%   if ~ischar(thisline);
%       break;
%   end
%   res{end+1,1} = thisline;
% end
% fclose(fid);
% WarningBeforeClosing = numel(res);


% --------------------------------------------------------------------



% --------------------------------------------------------------------
function Run_Callback(hObject, eventdata, handles)
% hObject    handle to Run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole3,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero3,'String','');
%
%              set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1,'String','');
%              set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2,'String','');

set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b0,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b1,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b2,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b3,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b4,'String','');
%     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a0,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a2,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a3,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a4,'String','');

% Normalized Coefficients Display
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b0,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b1,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b2,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b3,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b4,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a1,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a2,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a3,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a4,'String','');

set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b10,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b11,'String','');
%     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a10,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a11,'String','');
%set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.PostShift,'String','');

set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b20,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b21,'String','');
%     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a20,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a21,'String','');

set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b30,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b31,'String','');
%     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a30,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a31,'String','');

set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.Normal,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostShift,'String','');
set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostScalar,'String','');

set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b0,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b1,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b2,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b3,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b4,'String','');
%     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a0,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a1,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a2,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a3,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a4,'String','');

% Normalized Coefficients Display
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b0,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b1,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b2,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b3,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b4,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a1,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a2,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a3,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a4,'String','');

% cascaded
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b10,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b11,'String','');
%     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a10,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a11,'String','');
%set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.PostShift,'String','');

set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b20,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b21,'String','');
%     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a20,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a21,'String','');

set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b30,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b31,'String','');
%     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a30,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a31,'String','');

set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.Normal,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostShift,'String','');
set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostScalar,'String','');

%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1,'String','');
%
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2,'String','');
%
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3,'String','');
%             set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3,'String','');
%
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1,'String','');
%
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2,'String','');
%
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3,'String','');
%             set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3,'String','');



pause(0.0000001) % Do something important

% msgbox('Note: Digital Compensator calculations are in progress. this may take a few minutes .....','modal');
RunMessageBox = msgbox('Note: Power Smart Development Suite - GP Computations are in progress,This may take a few minutes.');

% disp(['Note: Digital Compensator calculations are in progress. this may take a few minutes .....']);

OLPWMParam = handles.ControllerDesignTab.PWMConfiguration.OL;
ILPWMParam = handles.ControllerDesignTab.PWMConfiguration.IL;
OLControllertype = handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;
ILControllertype = handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
OLPZComp = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData;
ILPZComp = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData;
if handles.General_test.SelectionDropdowns.TopologySelection.Value==1 && handles.General_test.SelectionDropdowns.ILPlantTopologySelection.Value==1 
DEGO1=handles.OLDEG_NUM.dego1;
DEGO2=handles.OLDEG_DEN.dego2;
DEGI1= handles.ILDEG_NUM.degi1;
DEGI2=  handles.ILDEG_DEN.degi2;
if DEGO2<DEGO1 
   errordlg('Outer Loop-Degree of Numerator polynomial should be lesser than Denominator Polynomial');
   return;  
 end
if DEGI2<DEGI1
   errordlg('Inner Loop-Degree of Numerator polynomial should be lesser than Denominator Polynomial');
   return;  
end
end

% if all(~isnan(str2double(get(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'String'))))
    if all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))&&(all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))&&~isempty(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String)
        
        if handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value==1
            if ~isempty(ILPWMParam.PWMFrequency.String)||~isempty(ILPWMParam.SamplingRatio.String)||~isempty(ILPWMParam.ComputationalDelay.String)||~isempty(ILPWMParam.GateDriveDelay.String)||~isempty(ILPWMParam.CrossOverFrequency.String)||~isempty(ILPWMParam.PhaseMargin.String)||~isempty(ILPWMParam.MinControlOutput.String)||~isempty(ILPWMParam.MaxControlOutput.String)
                if ~isempty(OLPWMParam.SamplingRatio.String)||~isempty(OLPWMParam.ComputationalDelay.String)||~isempty(OLPWMParam.CrossOverFrequency.String)||~isempty(OLPWMParam.PhaseMargin.String)||~isempty(OLPWMParam.MinControlOutput.String)||~isempty(OLPWMParam.MaxControlOutput.String)
                    
                    
                    DAC_Calculation_GP(hObject);
%                     Percentage_Power_GP(hObject);
%                     SoftStartCallRate_GP(hObject);
%                     OverPower_GP(hObject);
                    OLIPVSamFreqCalc_GP(hObject);
                    ILIPVSamFreqCalc_GP(hObject);
%                     XCapCompenCalc_GP(hObject);
                    PlantTFComputation_GP(hObject);
                    BLPFCAutoCompensatorDesign_GP(hObject);
                end
            else
                errordlg('Enter values in `Compensator` tab','Error')
            end
            
        elseif handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual.Value==1
            if ~isempty(ILPWMParam.PWMFrequency.String)||~isempty(ILPWMParam.SamplingRatio.String)||~isempty(ILPWMParam.ComputationalDelay.String)||~isempty(ILPWMParam.GateDriveDelay.String)||~isempty(ILPWMParam.MinControlOutput.String)||~isempty(ILPWMParam.MaxControlOutput.String)
                if ~isempty(OLPWMParam.SamplingRatio.String)||~isempty(OLPWMParam.ComputationalDelay.String)||~isempty(OLPWMParam.MinControlOutput.String)||~isempty(OLPWMParam.MaxControlOutput.String)
                    switch ILControllertype
                        case 1
                            if ~isempty(ILPZComp.Gain.String)&&~isempty(ILPZComp.Pole1.String)&&~isempty(ILPZComp.Zero1.String)
                                ILManualCompDesign_GP(hObject,0);
                            else
                                errordlg('Enter inner loop poles and zeros','Error');
                            end
                        case 2
                            if ~isempty(ILPZComp.Gain.String)&&~isempty(ILPZComp.Pole1.String)&&~isempty(ILPZComp.Pole2.String)&&~isempty(ILPZComp.Zero1.String)&&~isempty(ILPZComp.Zero2.String)
                                ILManualCompDesign_GP(hObject,0);
                            else
                                errordlg('Enter inner loop poles and zeros','Error');
                            end
                    end
                    switch OLControllertype
                        case 1
                            if ~isempty(OLPZComp.Gain.String)&&~isempty(OLPZComp.Pole1.String)&&~isempty(OLPZComp.Zero1.String)
                               
%                                 DAC_Calculation_GP(hObject);
%                                 Percentage_Power_GP(hObject);
%                                 SoftStartCallRate_GP(hObject);
%                                 OverPower_GP(hObject);
                                OLIPVSamFreqCalc_GP(hObject);
                                ILIPVSamFreqCalc_GP(hObject);
%                                 XCapCompenCalc_GP(hObject);
                                OLManualCompDesign_GP(hObject,0);
                            else
                                errordlg('Enter outer loop poles and zeros','Error');
                            end
                        case 2
                            if ~isempty(OLPZComp.Gain.String)&&~isempty(OLPZComp.Pole1.String)&&~isempty(OLPZComp.Pole2.String)&&~isempty(OLPZComp.Zero1.String)&&~isempty(OLPZComp.Zero2.String)
                                
%                                 DAC_Calculation_GP(hObject);
%                                 Percentage_Power_GP(hObject);
%                                 SoftStartCallRate_GP(hObject);
%                                 OverPower_GP(hObject);
                                OLIPVSamFreqCalc_GP(hObject);
                                ILIPVSamFreqCalc_GP(hObject);
%                                 XCapCompenCalc_GP(hObject);
                                OLManualCompDesign_GP(hObject,0);
                            else
                                errordlg('Enter outer loop poles and zeros','Error');
                            end
                    end
                end
            else
                errordlg('Enter values in `Compensator` tab','Error')
            end
        end
    else
        errordlg('Enter values in `Feedback` tab','Error')
    end
% else
%     errordlg('Enter values in `Specifications`, `Feedback` and `Compensator` tabs','Error')
%     
% end
delete(RunMessageBox);
RunMessageBoxComplete =    msgbox('Note: Power Smart Development Suite - GP Computations Completed.');
pause(1) % Do something important
delete(RunMessageBoxComplete);
