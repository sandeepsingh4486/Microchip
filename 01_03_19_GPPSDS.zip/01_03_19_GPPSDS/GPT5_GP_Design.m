function GPT5_PFC_Design(GPT5,hObject)
handles=guidata(hObject);

GPT5MovablePanel = uipanel('Parent',GPT5,'Tag','GPT5MovablePanel');

ControlLoopDiagramPanel= uipanel(...
'Parent',GPT5MovablePanel,...
'FontUnits',get(0,'defaultuipanelFontUnits'),...
'Units',get(0,'defaultuipanelUnits'),...
'FontSize',11,...
'Tag','Control Loop Diagram',...
'Title','Control Loop Diagram',...
'Position',[0.00001 0.6 1.0 0.4],...
'CreateFcn', blanks(0) );


ControlLoopImageAx=axes(ControlLoopDiagramPanel,'Position',[0 0 1 1]); 
% ControlLoopImage=imread('PowerReferencePFCDiagram.png');
% imshow(ControlLoopImage,'Parent',ControlLoopImageAx);

%% Updating Handles
handles.ControlLoopDiagramTab.Panes.MovablePanes="Not Applicable";
handles.ControlLoopDiagramTab.Panes.ImagePanels=ControlLoopDiagramPanel;
handles.ControlLoopDiagramTab.Panes.ImageAxes = ControlLoopImageAx;

%% To show the Control loop diagram Image
ControlLoopImageAx = handles.ControlLoopDiagramTab.Panes.ImagePanels.Children;
% set(ControlLoopImageAx,'Units','pixels');
% ControlLoopImageAxPos=get(ControlLoopImageAx,'Position');
% set(ControlLoopImageAx,'Units','normalized');
% ResizedControlLoopImage=imresize(ControlLoopImage, [ControlLoopImageAxPos(4) ControlLoopImageAxPos(3)]);
% imshow(ResizedControlLoopImage,'Parent',ControlLoopImageAx);

        ControlLoopImage=imread('PowerReferencePFCDiagram.png');
%         imshow(ControlLoopImage,'Parent',handles.ControlLoopDiagramTab.Panes.ImageAxes);
        imshow(ControlLoopImage,'Parent',ControlLoopImageAx);
        ControlLoopDiagramImage=imread('PowerReferencePFCDiagram.png');
        ControlLoopDiagramImageAx = handles.ControlLoopDiagramTab.Panes.ImagePanels.Children;
        set(ControlLoopDiagramImageAx,'Units','pixels');
        ControlLoopDiagramImageAxPos=get(ControlLoopDiagramImageAx,'Position');
        set(ControlLoopDiagramImageAx,'Units','normalized');
        ResizedControlLoopDiagramImage=imresize(ControlLoopDiagramImage, [ControlLoopDiagramImageAxPos(4) ControlLoopDiagramImageAxPos(3)]);
        imshow(ResizedControlLoopDiagramImage,'Parent',ControlLoopDiagramImageAx); 

% TransferFunctionPanel = uipanel(...
% 'Parent',GPT5MovablePanel,...
% 'FontUnits',get(0,'defaultuipanelFontUnits'),...
% 'Units',get(0,'defaultuipanelUnits'),...
% 'Tag','TransferFunction',...
% 'Title','TransferFunctions',...
% 'Position',[0.00001 0.004 1.0 0.89],...
% 'CreateFcn', blanks(0));

% 'BorderType','none',...

guidata(hObject,handles);