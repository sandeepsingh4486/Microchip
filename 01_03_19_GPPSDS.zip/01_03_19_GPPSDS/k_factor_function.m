function controller = k_factor_function(G, fc, pm)

s = tf('s');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Program calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wc = 2*pi*fc;
sc = 2*pi*j*fc;

G_wc = evalfr(G,sc);  % Plant response at the desired crossover frequency.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  NOTE!!!  In instances where the phase of the plant is near 180 degrees,
%  the sign of the phase will be incorrect (+/-).  This will result in
%  incorrect controller selection.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
G_phase = atan2(imag(G_wc), real(G_wc));  %atan(imag(G_wc)/real(G_wc));  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Based on the comment above, if the phase is greater than +120 degrees, it
%  is assumed to be a phase lag (change the sign).  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if G_phase > 2.0944                 % 3.141 * 120 / 180
    G_phase = -G_phase;
end

G_mag = sqrt(real(G_wc)^2 + imag(G_wc)^2);

required_phase_boost = (-90 - G_phase*180/pi + pm);

if required_phase_boost < 0 & -90<required_phase_boost
    %     L_init = G/s;
    %     L_init_wc = evalfr(L_init, sc);
    %     kc = 1/abs(L_init_wc);
    %
    %     controller = kc/s;
    %     if -90<required_phase_boost<0
    k = 1/(tan((required_phase_boost/2 + 45)*pi/180)) ;
    wz = wc*k;
    wp = wc/k;
    L_init = G*(1 + s/wz)/(s*(1 + s/wp));
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)/(s*(1 + s/wp));
    
elseif required_phase_boost<= -90
    
    k = 1/(tan((required_phase_boost/4 + 45)*pi/180)) ;
    wz = wc * k ;
    wp = wc / k ;
    L_init = G*(1 + s/wz)^2/(s*(1 + s/wp)^2);
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)^2/(s*(1 + s/wp)^2);
end

if required_phase_boost >= 0 & required_phase_boost < 90 % 2P2Z compensator
    k = tan((required_phase_boost/2 + 45)*pi/180);
    wz = wc/k;
    wp = k*wc;
    L_init = G*(1 + s/wz)/(s*(1 + s/wp));
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)/(s*(1 + s/wp));
end

if required_phase_boost >= 90     % 3P3Z compensator
    k = (tan((required_phase_boost/4 + 45)*pi/180)) ;
    wz = wc/k;
    wp = k*wc;
    L_init = G*(1 + s/wz)^2/(s*(1 + s/wp)^2);
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)^2/(s*(1 + s/wp)^2);
end
% controller1 = controller;
% controller = minreal(controller);

end