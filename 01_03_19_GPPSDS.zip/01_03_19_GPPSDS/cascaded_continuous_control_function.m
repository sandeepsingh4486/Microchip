function cascaded_continuous_controller = cascaded_continuous_control_function(Kv_d_cascaded_sections, Kv_d_cascaded_rshift)


z = tf('z');
s = tf('s');

Kv_d_cascaded_sections(1) = Kv_d_cascaded_sections(1)*2^-Kv_d_cascaded_rshift;
cascaded_continuous_controller = d2c(Kv_d_cascaded_sections, 'tustin');