 function ClearValues_GP(hObject,~)
handles=guidata(hObject);   

        if any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))||any( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))||(any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| any(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
            WarningBeforeClosing_GP(hObject,handles);
        end

 %% Radio Button clearence in IPT1       
%         set(handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.BLPFCOption,'Value',0);           
%         set(handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.LVPFCOption,'Value',0);
%         set(handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.IPFCOption,'Value',0);
%         set(handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.PlatinumIPFCOption,'Value',0);

%% IPT1 Edit box clearance
%         
%         set(handles.SpecificationsTab.CommonSpecs.VinMin,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Vout,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Pout,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.XCap,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Inductor.Inductance,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Inductor.DCR,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Capacitor.Capacitance,'String','');
%         set(handles.SpecificationsTab.CommonSpecs.Capacitor.ESR,'String','');
%         set(handles.SpecificationsTab.FilePath.BodeFilePath,'String','');

handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a0.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a1.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a2.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a3.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a4.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a5.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b0.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b1.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b2.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b3.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b4.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b5.String='';

handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a0.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a1.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a2.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a3.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a4.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a5.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b0.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b1.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b2.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b3.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b4.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b5.String='';
handles.General_test.Panes.VariablePanes.MCHPrefvalues.BLPFCOption.Value=0;
handles.General_test.Panes.VariablePanes.MCHPrefvalues.V2.Value=0;
handles.General_test.Panes.VariablePanes.MCHPrefvalues.V3.Value=0;
handles.General_test.Panes.VariablePanes.MCHPrefvalues.V4.Value=0;

        %% IPT2 Editbox clearance
%         set(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2,'String','');
        
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.String='';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.String='';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.String='';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.String='';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.String='';
        
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.Enable='off';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.Enable='off';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.Enable='off';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.Enable='off';
        handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.Enable='off';
        
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4,'String','');
        
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs,'String','');
        
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6,'String','');
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7,'String','');
        
        set(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer,'Value',1);
        
%% IPT3        

        set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.PTPER,'Style','edit','Enable','off');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.PTPER,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin,'String','');
%         set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput, 'String','');
        
        handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String ='';
        set(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.PTPER,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput,'String','');
        set(handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput, 'String','');
        
        % handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value = 1;
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole3,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero3,'String','');
        
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1,'String','');
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2,'String','');
        
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b0,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b1,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b2,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b3,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.b4,'String','');
        %     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a0,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a1,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a2,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a3,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Absolute.a4,'String','');
        
        % Normalized Coefficients Display
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b0,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b1,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b2,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b3,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.b4,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a1,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a2,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a3,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Normalized.a4,'String','');
        
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b10,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b11,'String','');
        %     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a10,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a11,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.PostShift,'String','');
        
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b20,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b21,'String','');
        %     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a20,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a21,'String','');
        
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b30,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b31,'String','');
        %     set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a30,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a31,'String','');
        
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.Normal,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostShift,'String','');
        set(handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.Q15Parameters.PostScalar,'String','');
        
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b0,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b1,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b2,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b3,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.b4,'String','');
        %     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a0,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a1,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a2,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a3,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Absolute.a4,'String','');
        
        % Normalized Coefficients Display
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b0,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b1,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b2,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b3,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.b4,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a1,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a2,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a3,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Normalized.a4,'String','');
        
        % cascaded
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b10,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b11,'String','');
        %     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a10,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a11,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.PostShift,'String','');
        
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b20,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b21,'String','');
        %     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a20,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a21,'String','');
        
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b30,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b31,'String','');
        %     set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a30,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a31,'String','');
        
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.Normal,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostShift,'String','');
        set(handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.Q15Parameters.PostScalar,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole1,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero1,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain1,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole2,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero2,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain2,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Pole3,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Zero3,'String','');
        set(handles.ControllerDesignTab.CascadedController.OuterLoop.ZPKData.Gain3,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole1,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero1,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain1,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole2,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero2,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain2,'String','');
        
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Pole3,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Zero3,'String','');
        set(handles.ControllerDesignTab.CascadedController.InnerLoop.ZPKData.Gain3,'String','');
        
%% IPT4
set(findobj(handles.dsPICDSCTab.Panes.MovablePane,'Style','popupmenu'),'Value',1);

         set(handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC,'String','');
         set(handles.dsPICDSCTab.IPCommonPanel.DeviceClock,'String','70');
         handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.Enable='off';
         handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.Value=1;
         set(handles.dsPICDSCTab.Peripheralselection.EnableText,'Enable','on');
         set(handles.dsPICDSCTab.Peripheralselection.Enable_drive,'Enable','on');
         
      %% PFC, implementation needs measurement of one phase current / total current
%        set(findobj(handles.dsPICDSCTab.ADC_PFCCurrentEnable.BLPFCCurrent,'Style','radiobutton'),'Enable','off');
%        handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrentText.Enable='off';
       handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrentText.Value=1;
       handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent2Text.Enable='off';
       handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent1Text.Enable='off';
       handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent1Text.Value=1;
       handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrent2Text.Value=1;
         
         
        %% IPT5 Single Phase PFC
        %%
        set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','off');
        handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value = 0;
        handles.IPT5.FeaturesConfig.IPUnderVoltageLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.IPUnderVoltageHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultenableTextBox.String='';
        handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultdisableTextBox.String='';
        
        handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value = 0;
        handles.IPT5.FeaturesConfig.IPOverVoltageLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.IPOverVoltageHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.IPoverVoltage.FaultenableTextBox.String='';
        handles.IPT5.FeaturesConfig.IPoverVoltage.FaultdisableTextBox.String='';
        
        handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value = 0;
        handles.IPT5.FeaturesConfig.OPUnderVoltageLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultenableTextbox.String='';
        handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox.String='';
        
        handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value = 0;
        handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPOverVoltageHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPOverVoltage.FaultenableTextbox.String='';
        handles.IPT5.FeaturesConfig.OPOverVoltage.FaultdisableTextbox.String='';
        
        handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value = 0;           % this is for output over power
        handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPOverCurrentLimitHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.OPOverCurrent.FaultEnableTextbox.String='';
        handles.IPT5.FeaturesConfig.OPOverCurrentLimitFaultDisableTextBox.String='';        
        
        handles.IPT5.FeaturesConfig.OverTemperatureLimit.Value = 0;
        handles.IPT5.FeaturesConfig.OverTemperatureLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.OverTemperatureLimitHysTextBox.String ='';
        handles.IPT5.FeaturesConfig.OverTemperaturefaultenableTextbox.String='';
        handles.IPT5.FeaturesConfig.OverTemperatureLimitFaultdisableTextbox.String='';        
        
        handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value = 0;
        handles.IPT5.FeaturesConfig.LineUnderFrequencyLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.LineUnderFreqHysTextBox .String ='';
        handles.IPT5.FeaturesConfig.LineUnderFreqfaultenableTextbox.String='';
        handles.IPT5.FeaturesConfig.LineUnderFreqFaultdisableTextBox.String='';        
        
        handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value = 0;
        handles.IPT5.FeaturesConfig.LineOverFrequencyLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.LineOverFrequencyHysTextBox.String='';
        handles.IPT5.FeaturesConfig.LineOverFrequencyLimitFaultenableTextBox.String='';
        handles.IPT5.FeaturesConfig.LineOverFrequencyLimitfaultdisableTextBox.String='';        
        
        handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value = 0;
        handles.IPT5.FeaturesConfig.RelayTurnONLimitTextBox.String ='';
        handles.IPT5.FeaturesConfig.RelayTurnONLimitHysTextBox .String ='';
        handles.IPT5.FeaturesConfig.RelayTurnONLimitfaultenableTextBox.String='';
        handles.IPT5.FeaturesConfig.RelayTurnONLimitFaultdisableTextBox.String='';
        
        handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value=0;
        handles.IPT5.FeaturesConfig.GenericParameter1LimitTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter1LimitHysTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter1FaultEnableTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter1FaultDisableTextBox.String='';
        
        handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value=0;
        handles.IPT5.FeaturesConfig.GenericParameter2LimitTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter2LimitHysTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultEnableTextBox.String='';
        handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultDisableTextBox.String='';
        
%% IPT6 Default Values Single Phase PFC
        %%
        set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','off');
        handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value =0;
        handles.IPT6.FeaturesConfiguration.SoftStartDurationLimitTextBox.String ='';
        handles.IPT6.FeaturesConfiguration.SoftStartCallRate.Value = 0;
        handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.String ='';
        handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value = 0;
        handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String ='';
%         handles.IPT6.FeaturesConfiguration.BurstModeDisableLimit.Value = 0;
        handles.IPT6.FeaturesConfiguration.BurstModeDisableLimitTextBox.String ='';
        set(handles.IPT6.FeaturesConfiguration.BurstModeOffCyclesTextBox,'String','');
        handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value = 0;
        handles.IPT6.FeaturesConfiguration.PWMDitheringLimitTextBox.String ='';
        handles.IPT6.FeaturesConfiguration.PhaseShedding.Enable='off';
        handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Enable='off';
        handles.IPT6.FeaturesConfiguration.DCMCorrection.Value = 0;
        handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox.String ='DISABLED';
        handles.IPT6.FeaturesConfiguration.PhaseShedding.Value =0;
        handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String ='';
%         handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Value = 0;
        handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String ='';
        handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String='';
        handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String='';
        handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String='';
        
        handles.IPT6.FeaturesConfiguration.PFETControl.Value=0;
        set(handles.IPT6.FeaturesConfiguration.PFETControlTextBox,'String','DISABLED');
        
        handles.IPT6.FeaturesConfiguration.XCapCompensation.Value=0;
        set(handles.IPT6.FeaturesConfiguration.XCapCompensationTextBox,'String','DISABLED');
        set(handles.IPT6.FeaturesConfiguration.XCapFreqGainTextBox,'String','');
        set(handles.IPT6.FeaturesConfiguration.XCapCurrentMaxTextBox,'String','');
        set(handles.IPT6.FeaturesConfiguration.XCapVacArrayTextBox,'String','');
        
        set(handles.IPT6.FeaturesConfiguration.NeutralVoltageEnable,'Value',0);
        set(handles.IPT6.FeaturesConfiguration.NeutralVoltageEnable,'Enable','on');
        set(handles.IPT6.FeaturesConfiguration.NeutralVoltageEnableTextBox,'String','DISABLED');
        
        handles.IPT6.FeaturesConfiguration.OverOutputPowerEnable.Value=0;
        handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBoxWatts.String='';
        handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBox.String='';
        handles.IPT6.FeaturesConfiguration.EstimatedEfficiencyTextBox.String='';
        
        handles.IPT6.FeaturesConfiguration.AutomaticRestartEnable.Value=0;
        handles.IPT6.FeaturesConfiguration.AutomaticRestartTextBox.String='DISABLED';
        handles.IPT6.FeaturesConfiguration.MaxRestartAttemptsTextBox.String='';
        handles.IPT6.FeaturesConfiguration.SystemOperationalTextBox.String='';
        handles.IPT6.FeaturesConfiguration.SystemRestartTimeTextBox.String='';

        
        
%% GPT2 checkboxes  
        %%
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILPlantPlot.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Value = 0;
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Value = 0;
        
        set(findobj(handles.PlotsTab.Panes.MovablePane,'Style','checkbox'),'Enable','off');
%         PlotGeneration(hObject);
        cla(handles.PlotsTab.PlotsAxes.BodePlotAx);
        cla(handles.PlotsTab.PlotsAxes.RLPlotAx);
        cla(handles.PlotsTab.PlotsAxes.NPlotAx);
        cla(handles.PlotsTab.PlotsAxes.SRPlotAx);
        cla(handles.UserBodeResponseTab.Subplot1.axis);
        cla(handles.UserBodeResponseTab.Subplot2.axis);

        
%         set(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);
        set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);
        

% TopSel = handles.SpecificationsTab.SelectionDropdowns.TopologySelection.Value;
% switch TopSel
%     
%     case 1 
%         set(handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.LVPFCOption,'Enable','on');
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Enable='on';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Enable='on';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value=1;
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value=0;
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','Edit'),'Enable','off');
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','Edit'),'Enable','on');
%     case 2
%         handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.LVPFCOption.Enable = 'on';
%         handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.IPFCOption.Enable = 'on';
%         handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.PlatinumIPFCOption.Enable = 'on';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Enable='off';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Enable='off';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value=1;
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value=0;
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','Edit'),'Enable','off');
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','Edit'),'Enable','on')
%         
%     case 3
%         handles.SpecificationsTab.MicrochipRefDesign.Radiobuttons.BLPFCOption.Enable = 'on';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Enable='off';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Enable='off';
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.CurrentTransformer.Value=1;
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio.ShuntResistor.Value=0;
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','Edit'),'Enable','off');
%         set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','Edit'),'Enable','on')
% end

%% GPT4
handles.GPT4.Userbode.Radio.OLLoopGainDigPlot.Value = 0;
handles.GPT4.Userbode.Radio.ILLoopGainDigPlot.Value = 0;

       
