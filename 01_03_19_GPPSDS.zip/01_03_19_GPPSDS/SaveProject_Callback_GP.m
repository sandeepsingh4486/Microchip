function SaveProject_Callback(hObject,~)
handles=guidata(hObject);
ClassName=string(class(hObject));
if ClassName=='matlab.ui.control.UIControl'
    delete(gcbf);
    hObject=gcf;
    handles=guidata(hObject);
end
if (handles.ProjectInformation.SavedStatus=="")
    MenuSaveAs_Callback(hObject,handles);
    handles=guidata(hObject);
    if handles.ProjectInformation.ProjName=="BlankProj"
        handles.GUIProcesses.terminateFurtherExecution=1;
    end
    guidata(hObject,handles);
    return;
end
guidata(hObject,handles);
ProjName=handles.ProjectInformation.ProjName;
save(strcat(ProjName,'.psds'),'handles','-mat');
handles.ProjectInformation.SavedStatus="Saved";
msgbox('Project Saved!!','Project Save Status','modal');



