 function BLPFCDesignValues_GP(hObject,~)
handles=guidata(hObject);  

%% IPT1 750W BLPFC Design Values             
%             handles.SpecificationsTab.CommonSpecs.VinMin.String='110';
% %             handles.SpecificationsTab.CommonSpecs.VinMax.String='220';
%             handles.SpecificationsTab.CommonSpecs.Vout.String='400';
%             handles.SpecificationsTab.CommonSpecs.Pout.String='750';
%             handles.SpecificationsTab.CommonSpecs.XCap.String='0.2';
%             handles.SpecificationsTab.CommonSpecs.Inductor.Inductance.String='460';
%             handles.SpecificationsTab.CommonSpecs.Inductor.DCR.String='50';
%             handles.SpecificationsTab.CommonSpecs.Capacitor.Capacitance.String='1320';
%             handles.SpecificationsTab.CommonSpecs.Capacitor.ESR.String='25';

handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a0.String='1';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a1.String='2';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a2.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a3.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a4.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.a5.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b0.String='0.5';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b1.String='0.15';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b2.String='1';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b3.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b4.String='';
handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients.b5.String='';

handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a0.String='2';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a1.String='1';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a2.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a3.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a4.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.a5.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b0.String='3';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b1.String='4';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b2.String='1';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b3.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b4.String='';
handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients.b5.String='';

%% IPT2 750W BLPFC Design Values            
            handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String='310';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String='1410';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String='10';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String='0.01';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String='100';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String='1';
            
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.Enable='on';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.Enable='on';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.Enable='on';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.Enable='on';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.Enable='on';
            
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.String='1410';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.String='10';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.String='0.01';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.String='100';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.String='1';
            
            
            handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String='1410';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String='10';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String='0.01';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String='100';
            handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String='1';
            
            handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String='0.0165';
            handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String='0.001';
            handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String='1';
            handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String='1';
            handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String='100';
 
            %% IPT3 750W BLPFC Design Values             
            handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String='100';
            handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String='1';
            handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String='100';
            handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String='300';
            handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String='20000';
            handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String='60';
%           handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String='1.04';
            handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String='150';
            handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String = '0';
            handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String = '32767';
           
            handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String = handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String;
            handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String='2';
            set(handles.ControllerDesignTab.PWMConfiguration.OL.PTPER,'String','50'); % input voltage sampling frequency
            handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String='6.25';
            handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String='300';
            handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String='10';
            handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String='40';
%             handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String='1.04';
            handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String='150';
            handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String = '0';
            handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String = '32767';           

         
%% IPT5 Default Values 750W BLPFC Design Values 

            set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','on');
            handles.IPT5.FeaturesConfig.IPUnderVoltageLimit.Value = 1;
            handles.IPT5.FeaturesConfig.IPUnderVoltageLimitTextBox.String ='85';
            handles.IPT5.FeaturesConfig.IPUnderVoltageHysTextBox.String ='5';
            handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultenableTextBox.String='1';
            handles.IPT5.FeaturesConfig.IPUnderVoltage.FaultdisableTextBox.String='1';
            
            handles.IPT5.FeaturesConfig.IPOverVoltageLimit.Value = 1;
            handles.IPT5.FeaturesConfig.IPOverVoltageLimitTextBox.String ='275';
            handles.IPT5.FeaturesConfig.IPOverVoltageHysTextBox.String ='5';
            handles.IPT5.FeaturesConfig.IPoverVoltage.FaultenableTextBox.String='1';
            handles.IPT5.FeaturesConfig.IPoverVoltage.FaultdisableTextBox.String='1';
            
            handles.IPT5.FeaturesConfig.OPUnderVoltageLimit.Value = 1;
            handles.IPT5.FeaturesConfig.OPUnderVoltageLimitTextBox.String ='340';
%             handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox.String ='';
            set(handles.IPT5.FeaturesConfig.OPUnderVoltageHysTextBox,'Enable','off');
            handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultenableTextbox.String='5';
            set(handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox,'Enable','off');
%             handles.IPT5.FeaturesConfig.OPUnderVoltage.FaultdisableTextbox.String='';
            
            handles.IPT5.FeaturesConfig.OPOverVoltageLimit.Value = 1;
            handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String ='420';
            handles.IPT5.FeaturesConfig.OPOverVoltageHysTextBox.String ='5';
            handles.IPT5.FeaturesConfig.OPOverVoltage.FaultenableTextbox.String='1';
            handles.IPT5.FeaturesConfig.OPOverVoltage.FaultdisableTextbox.String='1';
            
            handles.IPT5.FeaturesConfig.OPOverCurrentLimit.Value = 1;
            handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.String ='';
            handles.IPT5.FeaturesConfig.OPOverCurrentLimitHysTextBox.String ='5';
            handles.IPT5.FeaturesConfig.OPOverCurrent.FaultEnableTextbox.String='1';
            handles.IPT5.FeaturesConfig.OPOverCurrentLimitFaultDisableTextBox.String='1';   
            handles.IPT5.FeaturesConfig.OPOverCurrentLimitTextBox.Enable ='off';
%             handles.IPT5.FeaturesConfig.OPOverCurrentLimitHysTextBox.Enable ='off';
            
            handles.IPT5.FeaturesConfig.OverTemperatureLimit.Value = 1;
            handles.IPT5.FeaturesConfig.OverTemperatureLimitTextBox.String = '100';
            handles.IPT5.FeaturesConfig.OverTemperatureLimitHysTextBox.String = '10';
            handles.IPT5.FeaturesConfig.OverTemperaturefaultenableTextbox.String='1';
            handles.IPT5.FeaturesConfig.OverTemperatureLimitFaultdisableTextbox.String='1';            
            
            handles.IPT5.FeaturesConfig.LineUnderFrequencyLimit.Value = 1;
            handles.IPT5.FeaturesConfig.LineUnderFrequencyLimitTextBox.String ='45';
            handles.IPT5.FeaturesConfig.LineUnderFreqHysTextBox .String ='3';
            handles.IPT5.FeaturesConfig.LineUnderFreqfaultenableTextbox.String='1'; 
            handles.IPT5.FeaturesConfig.LineUnderFreqFaultdisableTextBox.String='1';             
            
            handles.IPT5.FeaturesConfig.LineOverFrequencyLimit.Value = 1;
            handles.IPT5.FeaturesConfig.LineOverFrequencyLimitTextBox.String ='65';
            handles.IPT5.FeaturesConfig.LineOverFrequencyHysTextBox.String='3';
            handles.IPT5.FeaturesConfig.LineOverFrequencyLimitFaultenableTextBox.String='1';
            handles.IPT5.FeaturesConfig.LineOverFrequencyLimitfaultdisableTextBox.String='1';            
            
            handles.IPT5.FeaturesConfig.RelayTurnONLimit.Value = 1;
            handles.IPT5.FeaturesConfig.RelayTurnONLimitTextBox.String ='65';
            handles.IPT5.FeaturesConfig.RelayTurnONLimitHysTextBox .String ='5';
            handles.IPT5.FeaturesConfig.RelayTurnONLimitfaultenableTextBox.String='1';
            handles.IPT5.FeaturesConfig.RelayTurnONLimitFaultdisableTextBox.String='1';
            
            handles.IPT5.FeaturesConfig.GenericParameter1Limit.Value=1;
            handles.IPT5.FeaturesConfig.GenericParameter1LimitTextBox.String='19';
            handles.IPT5.FeaturesConfig.GenericParameter1LimitHysTextBox.String='20';
            handles.IPT5.FeaturesConfig.GenericParameter1FaultEnableTextBox.String='1'; 
            handles.IPT5.FeaturesConfig.GenericParameter1FaultDisableTextBox.String='1'; 
            
            handles.IPT5.FeaturesConfig.GenericParameter2Limit.Value=1;
            handles.IPT5.FeaturesConfig.GenericParameter2LimitTextBox.String='23'; 
            handles.IPT5.FeaturesConfig.GenericParameter2LimitHysTextBox.String='24'; 
            handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultEnableTextBox.String='1'; 
            handles.IPT5.FeaturesConfig.GenericParameter2LimitFaultDisableTextBox.String='1';      
            
            %% IPT4
%             handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String='3670'
%               OPOverVoltageLimit = handles.IPT5.FeaturesConfig.OPOverVoltageLimitTextBox.String;
%               OPOverVoltageLimitC = str2double(OPOverVoltageLimit);
% 
%               ADCVolt = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String;
%               Rfb4C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
%               Rfb5C = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
%               ADCVoltC = str2double(ADCVolt);
%               VoutbaseC = (ADCVoltC / (Rfb5C / (Rfb5C+Rfb4C)));
% 
% 
%                ADCRes = handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.BitSelection.String;
%                ADCResC = 2^str2double(ADCRes);
%                OPOVLimitCounts = round((ADCResC * OPOverVoltageLimitC / VoutbaseC),0);
%                handles.IPT5.DACCountValueCalculated=OPOVLimitCounts;
%                handles.dsPICDSCTab.Peripheralselection.DAC.ACMPDAC.String=handles.IPT5.DACCountValueCalculated;
%             DAC_Calculation_PFC(hObject);
%             PTPERCalculation(hObject);
            handles.dsPICDSCTab.DeviceSelection.DeviceSelectionDropdown.Value = 5;
            handles.dsPICDSCTab.IPCommonPanel.DeviceClock.String='70';
            
          
            handles.dsPICDSCTab.Peripheralselection.PWMGeneratorxText.Value = 2;  % PWM 
            handles.dsPICDSCTab.Peripheralselection.PWMGeneratoryText.Value = 3; % PWM 
            
            set(handles.dsPICDSCTab.Peripheralselection.EnableText,'Enable','on');  % PWM port Enable
            set(handles.dsPICDSCTab.Peripheralselection.Enable_drive,'Enable','on'); % PWM port Enable            
            set(handles.dsPICDSCTab.Peripheralselection.EnableText,'Value',3); % PWM port Enable
            set(handles.dsPICDSCTab.Peripheralselection.Enable_drive,'Value',15); % PWM port Enable
            
            handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1.Value = 2;
            set(handles.dsPICDSCTab.Peripheralselection.PWMResolutionText1,'Enable','on');
            
            handles.dsPICDSCTab.Peripheralselection.ADCPFCCurrentText.Value = 2;            
            handles.dsPICDSCTab.Peripheralselection.ADCLineVoltageText.Value = 4;
            handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.Enable='on';
            handles.dsPICDSCTab.Peripheralselection.ADCNeutralVoltageText.Value = 5;
            handles.dsPICDSCTab.Peripheralselection.ADCOutputVoltageText.Value = 3;
            handles.dsPICDSCTab.Peripheralselection.ACMPOutputVoltageProtectionText.Value = 8;
            handles.dsPICDSCTab.Peripheralselection.RelayDriveText.Value = 3;
            handles.dsPICDSCTab.Peripheralselection.RelayDrivePort.Value = 16;
            handles.dsPICDSCTab.Peripheralselection.GPIO1Text.Value = 3;
            handles.dsPICDSCTab.Peripheralselection.GPIO1Port.Value = 6;
            handles.dsPICDSCTab.Peripheralselection.GPIO2Text.Value = 3;
            handles.dsPICDSCTab.Peripheralselection.GPIO2Port.Value = 10;
            handles.dsPICDSCTab.Peripheralselection.GPIO3Text.Value = 3;
            handles.dsPICDSCTab.Peripheralselection.GPIO3Port.Value = 12;       
            
% set(handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratoryTextPWMH,'Enable','off');
% set(handles.dsPICDSCTab.PWMGeneratorSel.PWM.PWMGeneratoryTextPWML,'Enable','off');
% set(handles.dsPICDSCTab.Peripheralselection.PWMGeneratoryText,'Enable','off')

%% IPT6 Default Values 750W BLPFC Design Values 

            set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'Enable','on');
            
            handles.IPT6.FeaturesConfiguration.SoftStartDurationLimit.Value = 1;
            handles.IPT6.FeaturesConfiguration.SoftStartDurationLimitTextBox.String ='100';
            handles.IPT6.FeaturesConfiguration.SoftStartCallRate.Value = 1;
            handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.String ='0.64';
            handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.Enable ='off';
            
            handles.IPT6.FeaturesConfiguration.BurstModeEnableLimit.Value = 1;
            handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBox.String ='10';
            handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.Enable ='off';
            handles.IPT6.FeaturesConfiguration.BurstModeDisableLimitTextBox.String ='15';
            set(handles.IPT6.FeaturesConfiguration.BurstModeOffCyclesTextBox,'String','1');
            handles.IPT6.FeaturesConfiguration.BurstModeEnableLimitTextBoxWatts.String='';
            
            handles.IPT6.FeaturesConfiguration.PWMDitheringLimit.Value = 1;
            handles.IPT6.FeaturesConfiguration.PWMDitheringLimitTextBox.String ='15';

            handles.IPT6.FeaturesConfiguration.DCMCorrection.Value = 1;
            handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox.String ='ENABLED';
            set(handles.IPT6.FeaturesConfiguration.DCMCorrectionTextBox,'Style','edit','Enable','off'); 
            
            handles.IPT6.FeaturesConfiguration.PhaseShedding.Value = 0;
            handles.IPT6.FeaturesConfiguration.PhaseShedding.Enable='off';
            handles.IPT6.FeaturesConfiguration.HysPhaseShedding.Enable='off';             
            handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.String ='';
            handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.String ='';
            handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBox.Enable ='off';
            handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBox.Enable ='off';            
			handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.String='';
            handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.String='';
            handles.IPT6.FeaturesConfiguration.PhaseSheddingIPFCTextBoxWatts.Enable = 'off';
            handles.IPT6.FeaturesConfiguration.HysPhaseSheddingIPFCTextBoxWatts.Enable = 'off';
            
            handles.IPT6.FeaturesConfiguration.PFETControl.Value=1;
            set(handles.IPT6.FeaturesConfiguration.PFETControlTextBox,'String','ENABLED');
            handles.IPT6.FeaturesConfiguration.PFETControlTextBox.Enable = 'off';
            
            handles.IPT6.FeaturesConfiguration.XCapCompensation.Value=1;
            set(handles.IPT6.FeaturesConfiguration.XCapFreqGainTextBox,'Enable','off');
            set(handles.IPT6.FeaturesConfiguration.XCapCurrentMaxTextBox,'Enable','off');
            set(handles.IPT6.FeaturesConfiguration.XCapVacArrayTextBox,'Enable','off');
            handles.IPT6.FeaturesConfiguration.XCapCompensationTextBox.Enable = 'off';
            set(handles.IPT6.FeaturesConfiguration.XCapCompensationTextBox,'String','ENABLED')
            
            handles.IPT6.FeaturesConfiguration.NeutralVoltageEnable.Value = 1;
            handles.IPT6.FeaturesConfiguration.NeutralVoltageEnable.Enable = 'off';            
            set(handles.IPT6.FeaturesConfiguration.NeutralVoltageEnableTextBox,'String','ENABLED');
            handles.IPT6.FeaturesConfiguration.NeutralVoltageEnableTextBox.Enable = 'off';
            
            handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBox.String = '5';
            handles.IPT6.FeaturesConfiguration.EstimatedEfficiencyTextBox.String = '98';
            handles.IPT6.FeaturesConfiguration.OverOutputPowerTextBoxWatts.Enable = 'off';
            handles.IPT6.FeaturesConfiguration.OverOutputPowerEnable.Value = 1;
            
            set(handles.IPT6.FeaturesConfiguration.AutomaticRestartTextBox,'String','ENABLED');
            handles.IPT6.FeaturesConfiguration.AutomaticRestartEnable.Value = 1;
            handles.IPT6.FeaturesConfiguration.AutomaticRestartTextBox.Enable = 'off';
            handles.IPT6.FeaturesConfiguration.MaxRestartAttemptsTextBox.String='5';
            handles.IPT6.FeaturesConfiguration.SystemOperationalTextBox.String='600';
            handles.IPT6.FeaturesConfiguration.SystemRestartTimeTextBox.String='150000';        
            
            handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value = 1;
            
%             set(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.ControllerInfo.OuterLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PolesPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.ControllerDesignTab.ControllerInfo.InnerLoop.ZerosPanel,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeaturesConfigurationParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);
            set(findobj(handles.FeaturesParametersTab.Panes.FeaturesPane,'Style','edit'),'BackgroundColor',[1 1 1]);
            
PlantTFComputation_GP(hObject);

OLFBTFComputation_GP(hObject);

ILFBTFComputation_GP(hObject);