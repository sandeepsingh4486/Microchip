function GPT1_GP_Design(GPT1, hObject)
handles=guidata(hObject);
Control=handles.General_test.SelectionDropdowns.ControlMethodSelection;
% 
BLPFCImagePanel=uipanel(GPT1);
BLPFCImageAx=axes(BLPFCImagePanel,'Position',[0 0 1 1]);
%  if (Control.Value==1)
% 
% BLPFCImage=imread('SingleLoop.png');
% imshow(BLPFCImage,'Parent',BLPFCImageAx);
% BlockDiagramImage=imread('SingleLoop.png');
% elseif(Control.Value==2)
% BLPFCImage=imread('DualLoopSystem.png');
% imshow(BLPFCImage,'Parent',BLPFCImageAx);
% BlockDiagramImage=imread('DualLoopSystem.png');
% elseif(Control.Value==3)
% BLPFCImage=imread('PCMC.png');
% imshow(BLPFCImage,'Parent',BLPFCImageAx);
% BlockDiagramImage=imread('PCMC.png');
% end
BLPFCImage=imread('DualLoopSystem.png');
imshow(BLPFCImage,'Parent',BLPFCImageAx);

BlockDiagramImage=imread('DualLoopSystem.png');

%% Updating Handles
handles.CircuitTab.Panes.MovablePanes="Not Applicable";
handles.CircuitTab.Panes.ImagePanels=BLPFCImagePanel;
handles.CircuitTab.Panes.ImageAxes = BLPFCImageAx;

%% To show the block diagram Image
BlockDiagramImageAx=handles.CircuitTab.Panes.ImagePanels.Children;
set(BlockDiagramImageAx,'Units','pixels');
BlockDiagramImageAxPos=get(BlockDiagramImageAx,'Position');
set(BlockDiagramImageAx,'Units','normalized');
ResizedBlockDiagramImage=imresize(BlockDiagramImage, [BlockDiagramImageAxPos(4) BlockDiagramImageAxPos(3)]);
imshow(ResizedBlockDiagramImage,'Parent',BlockDiagramImageAx);
%%
% findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit')

guidata(hObject,handles);