function SoftStartCallRate(hObject,~)
handles=guidata(hObject);



OLPWMSampFreqC = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);

if OLPWMSampFreqC == 0
        errordlg('Please choose a non zero PWM Sampling Frequency','Warning');    
else
    SoftStartCallRate =  ((1/OLPWMSampFreqC)*4);
    handles.IPT6.FeaturesConfiguration.SoftStartCallRateTextBox.String = SoftStartCallRate;
end