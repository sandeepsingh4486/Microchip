function PWMxGenSelection(hObject,~)  % PWM Channel selection Disable - high side drive
handles=guidata(hObject);

PWM_GENx_Val =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratorxText.Value;
    PWM_GENx =  handles.dsPICDSCTab.Peripheralselection.PWMGeneratorxText.String{PWM_GENx_Val,1};
    if(PWM_GENx_Val ==2)            % PWM1H
        PWMPh1DrvCh = 1;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 3)        % PWM1L
        PWMPh1DrvCh = 1;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 4)            % PWM2H
        PWMPh1DrvCh = 2;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 5)           % PWM2L
        PWMPh1DrvCh = 2;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 6)            % PWM3H
        PWMPh1DrvCh = 3;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 7)           % PWM3L
        PWMPh1DrvCh = 3;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 8)            % PWM4H
        PWMPh1DrvCh = 4;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 9)           % PWM4L
        PWMPh1DrvCh = 4;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 10)            % PWM5H
        PWMPh1DrvCh = 5;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 11)           % PWM5L
        PWMPh1DrvCh = 5;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 12)            % PWM6H
        PWMPh1DrvCh = 6;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 13)           % PWM6L
        PWMPh1DrvCh = 6;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 14)            % PWM7H
        PWMPh1DrvCh = 7;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 15)           % PWM7L
        PWMPh1DrvCh = 7;
        PWMPh1ChLow = 'ENABLED';
        
    elseif(PWM_GENx_Val == 16)            % PWM8H
        PWMPh1DrvCh = 8;
        PWMPh1ChLow = 'DISABLED';
        
    elseif(PWM_GENx_Val == 17)           % PWM8L
        PWMPh1DrvCh = 8;
        PWMPh1ChLow = 'ENABLED';
        
%     handles.PWMGeneratorXChannelNum.Value = PWMPh1DrvCh;
%     handles.PWMGeneratorXChannelHLSide.String = PWMPh1ChLow;
      
handles.dsPICDSCTab.Peripheralselection.EnableText.Value = PWMPh1DrvCh;
handles.PWMxGenSelection.PWM_GENx_Val.Value = PWMPh1ChLow;
     
    end
