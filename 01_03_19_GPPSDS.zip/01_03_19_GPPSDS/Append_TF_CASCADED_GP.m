function [NUMER1,DENOM1,NUMER2,DENOM2,NUMER3,DENOM3]=Append_TF_CASCADED_GP(STRING)
str=evalc('STRING');
 splitted = strsplit(str,'\n'); % Splits the string
NUMER1 = splitted(5); % 4th line contains the NUMERator
NUMER1 = NUMER1{1}; % Converting cell to string
DENOM1 = splitted(7); % 6th line contains the DENOMinator
DENOM1 = DENOM1{1}; % Converting cell to string
NUMER2 = splitted(10); % 4th line contains the NUMERator
NUMER2 = NUMER2{1}; % Converting cell to string
DENOM2 = splitted(12); % 6th line contains the DENOMinator
DENOM2 = DENOM2{1}; % Converting cell to string
NUMER3 = splitted(15); % 4th line contains the NUMERator
NUMER3 = NUMER3{1}; % Converting cell to string
DENOM3 = splitted(17); % 6th line contains the DENOMinator
DENOM3 = DENOM3{1}; % Converting cell to string
end