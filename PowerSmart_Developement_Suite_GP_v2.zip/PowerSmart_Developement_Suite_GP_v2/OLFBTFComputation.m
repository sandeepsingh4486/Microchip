function OLFBTFComputation(hObject,~)
if (hObject.Style=="edit" && isnan(str2double(hObject.String)) && (isempty(hObject.String)==0) || isreal(str2double(hObject.String))==0 || (str2double(hObject.String)<0)) 
    hObject.BackgroundColor=[1 0.8 0.8];
    return;
elseif  (hObject.Style=="edit" || isempty(hObject.String))
    hObject.BackgroundColor=[1 1 1];
end
s=tf('s');
handles=guidata(hObject);

if ~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String')))
    set(handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot,'Enable','on');
else
    set(handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot,'Enable','off');
end

Rfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String)*1e3;
Rfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String)*1e3;
Rfb3 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String)*1e3;
Cfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String)*1e-12;
Cfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String)*1e-12;

Rfb13 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb13.String)*1e3;
Rfb14 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb14.String)*1e3;
Rfb15 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Rfb15.String)*1e3;
Cfb8 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb8.String)*1e-12;
Cfb9 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.NeutralVoltageMeasurementNetwork.Cfb9.String)*1e-12;

Rfb4=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
Rfb5=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
Cfb3=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String)*1e-12;
Rfb6=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String)*1e3;                                                % Filter Resistor
Cfb4=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String)*1e-12;                                                 % Filter Capacitor

ADCVolt = str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String);
Vadc = ADCVolt;

% DAC_Calculation_PFC(hObject);
%% Output Voltage feedback TF

    if (isnan(Rfb4)||isnan(Rfb5)||isnan(Cfb3)||isnan(Cfb4)||isnan(Rfb6))
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='off';
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='off';
        PlotGeneration(hObject,0);
        return;
    else
        Vout_sense = Rfb5/(Rfb4+Rfb5+s*Cfb3*Rfb4*Rfb5);       % Sensing network gain calculation
        OPfilter = 1/(1+s*Rfb6*Cfb4);                        % LPF
        Gvofilter = Vout_sense * OPfilter;                   % Sensing network overall transfer function
        Vbase  = Vadc / (Rfb5/(Rfb4+Rfb5));
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='on';       
    end
     handles.FeedbackNetworkTab.FeedbackParameters.OL.Vbase = Vbase; 
     
    %%    Input Voltage feedback TF, in the plots window there is only one option to showcase the feedback plot

    if (isnan(Rfb1)||isnan(Rfb2)||isnan(Cfb1)||isnan(Cfb2)||isnan(Rfb3))
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='off';
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';

        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='off';
        PlotGeneration(hObject,0);
        return;
    else
        Vin_sense = Rfb2/(Rfb1+Rfb2+s*Cfb1*Rfb1*Rfb2);       % Sensing network gain calculation
        IPfilter = 1/(1+s*Rfb3*Cfb2);                        % LPF
        Gvifilter = Vin_sense * IPfilter;                    % Sensing network overall transfer function
        Vinbase = Vadc/(Rfb2/(Rfb2+Rfb1)); 
        handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable='on';       
    end
        
try
    handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF = Gvofilter;
    handles.FeedbackNetworkTab.FeedbackParameters.OL.IPFilterTF = Gvifilter;
    handles.FeedbackNetworkTab.FeedbackParameters.OL.Vinbase = Vinbase; 
    guidata(hObject,handles);
end
%%
% XCapCompenCalc(hObject);

% if all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))&& all(~isnan(str2double(get(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'String'))))&&all( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))&&all( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))&&(all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
%     
%     if handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value==1
%         %     x = 0.6;
%         %     w = waitbar(x, ' Computing......');
%         BLPFCAutoCompensatorDesign(hObject);
%         %     waitbar(1, w, 'Done');
%     else
%         %     x = 0.6;
%         %     w = waitbar(x, ' Computing......');
%         ILManualCompDesign_PFC(hObject,0);
%         OLManualCompDesign_PFC(hObject,0);
%         %     waitbar(1, w, 'Done');
%     end
%     PlotGeneration(hObject,0);
% end
