function ILManualCompDesign_PFC(hObject,~)
handles=guidata(hObject);
% if (hObject.Style=="edit" && isnan(str2double(hObject.String)) && (isempty(hObject.String)==0) || isreal(str2double(hObject.String))==0)
%     hObject.BackgroundColor=[1 0.8 0.8];
%     return;
% elseif  (hObject.Style=="edit" || isempty(hObject.String))
%     hObject.BackgroundColor=[1 1 1];
% end
handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual.Value = 1;
ILManualPlacement = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual;
handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='off';

IL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String);
IL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String);
OL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String);
OL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String);

s=tf('s');
%% Inner Loop Sampling Frequency in manual mode
% PWMFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String)*1e3;
% SampRatio=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String);
% PWMSamplFreqIL=PWMFreq/SampRatio;
% PWMSamplFreqIL(isnan(PWMSamplFreqIL))=PWMFreq;
% PWMSamplFreqILP = PWMSamplFreqIL * 1e-3;
% set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String',PWMSamplFreqILP);
FsampIL=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String)*1e3;
Tsi=1/FsampIL;
PWMSamplFreqILP= FsampIL * 1e-3;
PTPERCalculation(hObject);
%% Controller Types Dropdown Value
ILControllerType=handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value;
% FreqUnits=handles.ControllerDesignTab.FreqUnitsSelection.Value;
ILPZData=handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData;

%% Inner Loop Data
p1=str2double(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1.String);
p2=str2double(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2.String);
z1=str2double(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1.String);
z2=str2double(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2.String);
CompGain=str2double(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain.String);
CompGain(isnan(CompGain))=1;
Wp1=p1*2*pi;
Wp2=p2*2*pi;
Wz1=z1*2*pi;
Wz2=z2*2*pi;

%% If Controller choice is 2P2Z
if ILManualPlacement.Value == 1
    if (ILControllerType==1)
        if (isnan(p1) || isnan(z1) || isnan(CompGain))
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='off';
            CMCLoopGainComputation_PFC(hObject,0);
            return;
        else
            %         if (FreqUnits==1)
            ILCATF=CompGain*(1+s/Wz1)/(s*(1+s/Wp1));
            %         else
            %             ILCATF=CompGain*(1+s/z1)/(s*(1+s/p1));
            %         end
        end
        
        %% If COntroller choice is 3P3Z
    else
        if (isnan(p1) || isnan(p2) || isnan(z2) || isnan(z1) || isnan(CompGain))
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='off';
            CMCLoopGainComputation_PFC(hObject,0);
            return;
        else
            %          if (FreqUnits==1)
            ILCATF=CompGain*(1+s/Wz1)*(1+s/Wz2)/(s*(1+s/Wp1)*(1+s/Wp2));
            %         else
            %             ILCATF=CompGain*(1+s/z1)*(1+s/z2)/(s*(1+s/p1)*(1+s/p2));
            %         end
        end
    end
end

% [Gm,Pm,Wgm,Wpm] = margin(ILCATF);
% handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String = Wpm;
% handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String = Pm;

handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog=ILCATF;
handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='on';
guidata(hObject,handles);


if (isnan(Tsi)==1 || (isreal(Tsi)==0))
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';
    set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq,'String','NaN');
else
    ILCDTF = c2d(ILCATF,Tsi,'tustin');    % Inner loop Digital Compensator T/F
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='on';
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital=ILCDTF;
    set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq,'String',string(PWMSamplFreqILP));
    %% Inner Loop cascaded control
    
    Ki_d_cascaded = cascaded_control_function(ILCDTF, 0, 0, 0, IL_Min_Clamp, IL_Max_Clamp); %  cascaded_control_function(controller, rev_order, gainEnable, hFileVloopCloop, minclamp, maxclamp)
    Ki_d_cascaded_sections = Ki_d_cascaded{1};
    Ki_d_cascaded_rshift = Ki_d_cascaded{2};
    % to have the inner loop compensator cascaded T/F is Z^-1 form.
    Ki_c_cascaded = cascaded_continuous_control_function(Ki_d_cascaded_sections, Ki_d_cascaded_rshift);
    
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Digital = Ki_d_cascaded_sections;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.PostShift.Digital = Ki_d_cascaded_rshift;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog = Ki_c_cascaded
    
    %     set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String',PWMSamplFreq)*1e-3;
    guidata(hObject,handles);
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='on';
%     DigitalCompensatorCoefficientsGeneration_PFC(hObject);
%     DigitalCompensatorCoefficientsGeneration_PFC_Cascaded(hObject);
%     AnalogCompensatorCoefficientsGeneration_PFC_Cascaded(hObject);
end
CMCLoopGainComputation_PFC(hObject);
PlotGeneration(hObject);
