function DigitalCompensatorCoefficientsGeneration_Cascaded(hObject)
handles=guidata(hObject);
OLDigitalCompensatorCascaded = handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Digital;
OLDigitalCompensatorCascadedPshift = handles.ControllerDesignTab.ControllerInfo.OuterLoop.PostShift.Digital;
[OLN ,OLD]=tfdata(OLDigitalCompensatorCascaded,'value');
OLZerosNum = length(OLN);
OLPolesNum = length(OLD);

switch OLZerosNum
    case 1
        
        OLN1 = [OLN(1) OLN(2)];
        OLD1 = [OLD(1) OLD(2)];
        
        OLN2 = [1 0];
        OLD2 = [1 0];
        
        OLN3 = [1 0];
        OLD3 = [1 0];
        
    case 2
        
        OLN1 = [OLN{1}(1) OLN{1}(2)];
        OLD1 = [OLD{1}(1) OLD{1}(2)];
        
        OLN2 = [OLN{2}(1) OLN{2}(2)];
        OLD2 = [OLD{2}(1) OLD{2}(2)];
        
        OLN3 =[1 0];
        OLD3 =[1 0];
        
    case 3
        OLN1 = [OLN{1}(1) OLN{1}(2)];
        OLD1 = [OLD{1}(1) OLD{1}(2)];
        
        OLN2 = [OLN{2}(1) OLN{2}(2)];
        OLD2 = [OLD{2}(1) OLD{2}(2)];
        
        OLN3 = [OLN{3}(1) OLN{3}(2)];
        OLD3 = [OLD{3}(1) OLD{3}(2)];
end

OLCascaded1AbsCoeff.B10 = OLN1(1);
OLCascaded1AbsCoeff.B11 = OLN1(2);
OLCascaded1AbsCoeff.A10 = -1.*OLD1(1);
OLCascaded1AbsCoeff.A11 = -1.*OLD1(2);
OLCascaded1AbsCoeff.PostShift = OLDigitalCompensatorCascadedPshift;

OLCascaded2AbsCoeff.B20 = OLN2(1);
OLCascaded2AbsCoeff.B21 = OLN2(2);
OLCascaded2AbsCoeff.A20 = -1.*OLD2(1);
OLCascaded2AbsCoeff.A21 = -1.*OLD2(2);

OLCascaded3AbsCoeff.B30 = OLN3(1);
OLCascaded3AbsCoeff.B31 = OLN3(2);
OLCascaded3AbsCoeff.A30 = -1.*OLD3(1);
OLCascaded3AbsCoeff.A31 = -1.*OLD3(2);


handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs = OLCascaded1AbsCoeff;
handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs = OLCascaded2AbsCoeff;
handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs = OLCascaded3AbsCoeff;

handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b10.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B10;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.b11.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.B11;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a10.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A10;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.a11.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.A11;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl1.Absolute.PostShift.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded1Abs.PostShift;

handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b20.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B20;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.b21.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.B21;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a20.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A20;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl2.Absolute.a21.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded2Abs.A21;

handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b30.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B30;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.b31.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.B31;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a30.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A30;
handles.CompensatorCoefficientsTab.OLCompensatorCoefficients.CascadedControl3.Absolute.a31.String = handles.ControllerDesignTab.ControllerInfo.OuterLoop.DigitalCoefficientsCascaded3Abs.A31;
guidata(hObject,handles)

%%%Inner Loop

ILDigitalCompensatorCascaded = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Digital;
ILDigitalCompensatorCascadedPshift = handles.ControllerDesignTab.ControllerInfo.InnerLoop.PostShift.Digital;
[ILN ,ILD]=tfdata(ILDigitalCompensatorCascaded,'value');
ILZerosNum = length(ILN);
ILPolesNum = length(ILD);

switch ILZerosNum
    case 1
        
        ILN1 = [ILN(1) ILN(2)];
        ILD1 = [ILD(1) ILD(2)];
        
        ILN2 = [1 0];
        ILD2 = [1 0];
        
        ILN3 = [1 0];
        ILD3 = [1 0];
        
    case 2
        
        ILN1 = [ILN{1}(1) ILN{1}(2)];
        ILD1 = [ILD{1}(1) ILD{1}(2)];
        
        ILN2 = [ILN{2}(1) ILN{2}(2)];
        ILD2 = [ILD{2}(1) ILD{2}(2)];
        
        ILN3 =[1 0];
        ILD3 =[1 0];
        
    case 3
        ILN1 = [ILN{1}(1) ILN{1}(2)];
        ILD1 = [ILD{1}(1) ILD{1}(2)];
        
        ILN2 = [ILN{2}(1) ILN{2}(2)];
        ILD2 = [ILD{2}(1) ILD{2}(2)];
        
        ILN3 = [ILN{3}(1) ILN{3}(2)];
        ILD3 = [ILD{3}(1) ILD{3}(2)];
end

ILCascaded1AbsCoeff.B10 = ILN1(1);
ILCascaded1AbsCoeff.B11 = ILN1(2);
ILCascaded1AbsCoeff.A10 = -1.*ILD1(1);
ILCascaded1AbsCoeff.A11 = -1.*ILD1(2);
ILCascaded1AbsCoeff.PostShift = ILDigitalCompensatorCascadedPshift;

ILCascaded2AbsCoeff.B20 = ILN2(1);
ILCascaded2AbsCoeff.B21 = ILN2(2);
ILCascaded2AbsCoeff.A20 = -1.*ILD2(1);
ILCascaded2AbsCoeff.A21 = -1.*ILD2(2);

ILCascaded3AbsCoeff.B30 = ILN3(1);
ILCascaded3AbsCoeff.B31 = ILN3(2);
ILCascaded3AbsCoeff.A30 = -1.*ILD3(1);
ILCascaded3AbsCoeff.A31 = -1.*ILD3(2);


handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs = ILCascaded1AbsCoeff;
handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs = ILCascaded2AbsCoeff;
handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs = ILCascaded3AbsCoeff;



handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b10.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B10;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.b11.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.B11;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a10.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A10;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.a11.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.A11;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl1.Absolute.PostShift.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded1Abs.PostShift;

handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b20.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B20;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.b21.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.B21;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a20.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A20;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl2.Absolute.a21.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded2Abs.A21;

handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b30.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B30;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.b31.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.B31;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a30.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A30;
handles.CompensatorCoefficientsTab.ILCompensatorCoefficients.CascadedControl3.Absolute.a31.String = handles.ControllerDesignTab.ControllerInfo.InnerLoop.DigitalCoefficientsCascaded3Abs.A31;
guidata(hObject,handles)

OL_F_A11 = OLCascaded1AbsCoeff.A11./32767;
OL_F_B10 = OLCascaded1AbsCoeff.B10./32767;
OL_F_B11 = OLCascaded1AbsCoeff.B11./32767;

OL_F_A21 = OLCascaded2AbsCoeff.A21./32767;
OL_F_B20 = OLCascaded2AbsCoeff.B20./32767;
OL_F_B21 = OLCascaded2AbsCoeff.B21./32767;

OL_F_A31 = OLCascaded3AbsCoeff.A31./32767;
OL_F_B30 = OLCascaded3AbsCoeff.B30./32767;
OL_F_B31 = OLCascaded3AbsCoeff.B31./32767;

if OLCascaded1AbsCoeff.A11<0
OL_H_A11 = -1.*OLCascaded1AbsCoeff.A11;
else
    OL_H_A11 = OLCascaded1AbsCoeff.A11;
end

if OLCascaded1AbsCoeff.B10<0
OL_H_B10 = -1.*OLCascaded1AbsCoeff.B10;
else
    OL_H_B10 = OLCascaded1AbsCoeff.B10;
end

if OLCascaded1AbsCoeff.B11<0
OL_H_B11 = -1.*OLCascaded1AbsCoeff.B11;
else
    OL_H_B11 = OLCascaded1AbsCoeff.B11;
end

if OLCascaded2AbsCoeff.A21<0
OL_H_A21 = -1.*OLCascaded2AbsCoeff.A21;
else
    OL_H_A21 = OLCascaded2AbsCoeff.A21;
end

if OLCascaded2AbsCoeff.B20<0
OL_H_B20 = -1.*OLCascaded2AbsCoeff.B20;
else
    OL_H_B20 = OLCascaded2AbsCoeff.B20;
end

if OLCascaded2AbsCoeff.B21<0
OL_H_B21 = -1.*OLCascaded2AbsCoeff.B21;
else
    OL_H_B21 = OLCascaded2AbsCoeff.B21;
end

if OLCascaded3AbsCoeff.A31<0
OL_H_A31 = -1.*OLCascaded3AbsCoeff.A31;
else
    OL_H_A31 = OLCascaded3AbsCoeff.A31;
end

if OLCascaded3AbsCoeff.B30<0
OL_H_B30 = -1.*OLCascaded3AbsCoeff.B30;
else
    OL_H_B30 = OLCascaded3AbsCoeff.B30;
end

if OLCascaded3AbsCoeff.B31<0
OL_H_B31 = -1.*OLCascaded3AbsCoeff.B31;
else
    OL_H_B31 = OLCascaded3AbsCoeff.B31;
end


OL_H_A11 = dec2hex(OL_H_A11);
OL_H_B10 = dec2hex(OL_H_B10);
OL_H_B11 = dec2hex(OL_H_B11);

OL_H_A21 = dec2hex(OL_H_A21);
OL_H_B20 = dec2hex(OL_H_B20);
OL_H_B21 = dec2hex(OL_H_B21);

OL_H_A31 = dec2hex(OL_H_A31);
OL_H_B30 = dec2hex(OL_H_B30);
OL_H_B31 = dec2hex(OL_H_B31);


% pathName = cd;
% fileName = 'DigitalCoefficientsCascaded.h';
% file_path=fullfile(pathName,fileName);
% 
% fid1 = fopen(file_path, 'wt');
% fprintf(fid1,'\n/* Digital Cascaded Compensator Coefficients */  \n/*\n#define OL_D_A11\t\t\t %d\n#define OL_D_B10\t\t\t %d\n#define OL_D_B11\t\t\t %d\n#define OL_D_A21\t\t\t %d\n#define OL_D_B20\t\t\t %d\n#define OL_D_B21\t\t\t %d\n#define OL_D_A31\t\t\t %d\n#define OL_D_B30\t\t\t %d\n#define OL_D_A31\t\t\t %d\n#define OL_D_POST_SHIFT1\t %d\n\n\n#define OL_H_A11\t\t\t %d\n#define OL_H_B10\t\t\t %d\n#define OL_H_B11\t\t\t %d\n#define OL_H_A21\t\t\t %d\n#define OL_H_B20\t\t\t %d\n#define OL_H_B21\t\t\t %d\n#define OL_H_A31\t\t\t %d\n#define OL_H_B30\t\t\t %d\n#define OL_H_B31\t\t\t %d */\n\n\n#define OL_F_A11\t\t\t %d\n#define OL_F_B10\t\t\t %d\n#define OL_F_B11\t\t\t %d\n#define OL_F_A21\t\t\t %d\n#define OL_F_B20\t\t\t %d\n#define OL_F_B21\t\t\t %d\n#define OL_F_A31\t\t\t %d\n#define OL_F_B30\t\t\t %d\n#define OL_F_B31\t\t\t %d',OLCascaded1AbsCoeff.A11,OLCascaded1AbsCoeff.B10,OLCascaded1AbsCoeff.B11,OLCascaded2AbsCoeff.A21,OLCascaded2AbsCoeff.B20,OLCascaded2AbsCoeff.B21,OLCascaded3AbsCoeff.A31,OLCascaded3AbsCoeff.B30,OLCascaded3AbsCoeff.B31,OLCascaded1AbsCoeff.PostShift,OL_H_A11,OL_H_B10,OL_H_B11,OL_H_A21,OL_H_B20,OL_H_B21,OL_H_A31,OL_H_B30,OL_H_B31,OL_F_A11,OL_F_B10,OL_F_B11,OL_F_A21,OL_F_B20,OL_F_B21,OL_F_A31,OL_F_B30,OL_F_B31);
% fclose(fid1);


