function OLManualCompDesign(hObject,varargin)
% if (hObject.Style=="edit" && isnan(str2double(hObject.String)) && (isempty(hObject.String)==0) || isreal(str2double(hObject.String))==0)
%     hObject.BackgroundColor=[1 0.8 0.8];
%     return;
% elseif  (hObject.Style=="edit" || isempty(hObject.String))
%     hObject.BackgroundColor=[1 1 1];
% end
handles=guidata(hObject);
handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual.Value=1;
ILManualPlacement = handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Manual;
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';

IL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String);
IL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String);
OL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String);
OL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String);

s=tf('s');

% PWMFreq = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String)*1e3;
% % set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency, 'String', handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String)*1e-3;
% SampRatioOL = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String);
% SampRatioOL(isnan(SampRatioOL)) = 1;
% PWMSamplFreqOL = (PWMFreq / SampRatioOL);
% PWMSamplFreqOL(isnan(PWMSamplFreqOL))=PWMFreq;
% PWMSamplFreqOLP = PWMSamplFreqOL * 1e-3;
% set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq, 'String',PWMSamplFreqOLP);
% Tsv = 1/PWMSamplFreqOL;                      % OL manual Sampling time

FsampOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String)*1e3;
Tsv=1/FsampOL;
PWMSamplFreqOLP = FsampOL * 1e-3;

PTPERCalculation(hObject);
% SampRatioIL = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String);
% SampRatioIL(isnan(SampRatioIL)) = 1;
% PWMSamplFreqIL = string(PWMFreq/SampRatioIL);
%
% if (ismissing(PWMSamplFreqIL)~=1)
%     set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String', PWMSamplFreqIL);
% end
%
% try
%     handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String = string(PWMSamplFreq);
% catch
%     handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String = 'NaN';
% end

%% Controller Types Dropdown Value
OLControllerType=handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value;
% FreqUnits=handles.ControllerDesignTab.FreqUnitsSelection.Value;

%% Outer Loop Compensator Data
p1=str2double(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1.String);
p2=str2double(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2.String);
z1=str2double(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1.String);
z2=str2double(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2.String);

CompGain=str2double(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain.String);
CompGain(isnan(CompGain))=1;
Wp1=p1*2*pi;
Wp2=p2*2*pi;
Wz1=z1*2*pi;
Wz2=z2*2*pi;

%% If Controller choice is 2P2Z
if ILManualPlacement.Value == 1
    if (OLControllerType==1)
        if (isnan(p1) || isnan(z1) || isnan(CompGain))
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
            CMCLoopGainComputation_PFC(hObject,0);
            return;
        else
            %         if (FreqUnits==1)
            OLCATF=CompGain*(1+s/Wz1)/(s*(1+s/Wp1));
            %         else
            %             OLCATF=CompGain*(1+s/z1)/(s*(1+s/p1));
            %         end
        end
        
        %% If COntroller choice is 3P3Z
        
    else
        
        if (isnan(p1) || isnan(p2) ||isnan(z2) || isnan(z1) || isnan(CompGain))
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
            handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
            CMCLoopGainComputation_PFC(hObject,0);
            return;
        else
            %          if (FreqUnits==1)
            OLCATF=CompGain*(1+s/Wz1)*(1+s/Wz2)/(s*(1+s/Wp1)*(1+s/Wp2));
            %         else
            %             OLCATF=CompGain*(1+s/z1)*(1+s/z2)/(s*(1+s/p1)*(1+s/p2));
            %         end
        end
        
    end
end

% [Gm,Pm,Wgm,Wpm] = margin(OLCATF);
% handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String = Pm;
% handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String = Wpm;

handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog = OLCATF;
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable='on';
guidata(hObject,handles);

if (isnan(Tsv)==1 || (isreal(Tsv)==0))
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';
    set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq,'String','NaN');
    
else
    OLCDTF = c2d(OLCATF,Tsv,'tustin');
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='on';
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital=OLCDTF;
    set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq,'String',string(PWMSamplFreqOLP));
    %% Outer Loop cascaded control
    
    Kv_d_cascaded = cascaded_control_function(OLCDTF, 0, 0, 1, OL_Min_Clamp, OL_Max_Clamp); %  cascaded_control_function(controller, rev_order, gainEnable, hFileVloopCloop, minclamp, maxclamp)
    
    Kv_d_cascaded_sections = Kv_d_cascaded{1};
    Kv_d_cascaded_rshift = Kv_d_cascaded{2};
    
    Kv_c_cascaded = cascaded_continuous_control_function(Kv_d_cascaded_sections, Kv_d_cascaded_rshift);
    
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Digital = Kv_d_cascaded_sections;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.PostShift.Digital = Kv_d_cascaded_rshift;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Analog = Kv_c_cascaded
    
    guidata(hObject,handles);
    DigitalCompensatorCoefficientsGeneration_PFC(hObject);
    DigitalCompensatorCoefficientsGeneration_PFC_Cascaded(hObject);
    AnalogCompensatorCoefficientsGeneration_PFC_Cascaded(hObject);
end
CMCLoopGainComputation_PFC(hObject,0);