function BLPFCAutoCompensatorDesign(hObject, varargin)

handles=guidata(hObject);

handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='off';
try
    Gid = handles.General_test.PlantInfo.IL.PlantTF;                   % Inner loop Plant T/F
catch
    opts='model';
    errordlg("Enter Specifications for Auto-Compensator Design","Error",opts);
    return
end

s=tf('s');
ILFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Enable;
OLFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable;

Fswitching = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String)*1e3;     % Switching frequency in Hz
Ws = 2*pi*Fswitching;                                                                                 % Switching frequency in radians/sec
handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequencys.String = Fswitching;
% set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency, 'String', handles.ControllerDesignTab.PWMConfiguration.IL.PWMFrequency.String);
% SampRatioOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String);
% SampRatioIL = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.SamplingRatio.String);
% SampRatioIL(isnan(SampRatioIL)) = 1;
% SampRatioOL = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.SamplingRatio.String);
% SampRatioOL(isnan(SampRatioOL)) = 8;
% FsampIL = Fswitching/SampRatioIL;
% FsampOL = Fswitching/SampRatioOL;
% PWMSamplFreqIL = string(FsampIL/1000);
% PWMSamplFreqOL = string(FsampOL/1000);


FsampIL=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String)*1e3;
FsampOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String)*1e3;


% if (ismissing(PWMSamplFreqIL)~=1)
%     set(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq, 'String', PWMSamplFreqIL);
%     set(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq, 'String', PWMSamplFreqOL);
% end

% PWMSampling_Freq=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String)*1e3;
% CrossOver_Frequency=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String);
% Ratio=PWMSampling_Freq/CrossOver_Frequency;
% if (Ratio) < 5     
% errordlg('Recommended to choose Crossover Frequency less than 1/5 th of the PWM Sampling Frequency','Warning'); 
% end
% 
% OL_CrossOver_Frequency=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String);
% if OL_CrossOver_Frequency> 20
% errordlg('Recommended to choose Crossover Frequency less than 1/5 th of the rectified AC line frequency ','Warning');
% end

PTPERCalculation(hObject);

Tsi = 1/(FsampIL);                             % Sampling time in sec for Current Loop
Tsv = 1/(FsampOL);                             % Sampling time in sec for Voltage Loop                               
GateDriverDelay = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String)*1e-9;
GateDriverDelay(isnan(GateDriverDelay))=0;
ADClatency = str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.Latency.String)*1e-9;  % ADC conversion latency 
ADClatency(isnan(ADClatency))=0;
ILComputationaldelay = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String)*1e-9;
ILComputationaldelay(isnan(ILComputationaldelay))=0;           
OLComputationaldelay = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String)*1e-9;
OLComputationaldelay(isnan(OLComputationaldelay))=0;  

IL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MinControlOutput.String);
IL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.MaxControlOutput.String);
OL_Min_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MinControlOutput.String);
OL_Max_Clamp = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.MaxControlOutput.String);

OLPZControllerParametersPoles=findobj(handles.ControllerDesignTab.OuterLoop.PZEditBoxes.OLPolesPanel,'Style','edit');
OLPZControllerParametersZeros=findobj(handles.ControllerDesignTab.OuterLoop.PZEditBoxes.OLZerosAndGainPanel,'Style','edit');
ILPZControllerParametersPoles=findobj(handles.ControllerDesignTab.InnerLoop.PZEditBoxes.ILPolesPanel,'Style','edit');
ILPZControllerParametersZeros=findobj(handles.ControllerDesignTab.InnerLoop.PZEditBoxes.ILZerosAndGainPanel,'Style','edit');

set(OLPZControllerParametersPoles,'Enable','off', 'String','');
set(OLPZControllerParametersZeros,'Enable','off', 'String','');
set(ILPZControllerParametersPoles,'Enable','off', 'String','');
set(ILPZControllerParametersZeros,'Enable','off', 'String','');
%% Delays Inner loop
PWMshold = ((1-(1-(s*Tsi)/2)/(1+(s*Tsi)/2))/(s*Tsi));
Delay_innerloop_Forwardpath = GateDriverDelay + ILComputationaldelay;
Delay_innerloop_Feedbackpath = ADClatency;
Delay_innerloop = Delay_innerloop_Forwardpath + Delay_innerloop_Feedbackpath;
GdelayIL =(1-s*(Delay_innerloop/2))/(1+s*(Delay_innerloop/2)); 
H_Delay_innerloop_Forwardpath = (1-s*(Delay_innerloop_Forwardpath/2))/(1+s*(Delay_innerloop_Forwardpath/2));
H_Delay_innerloop_Feedbackpath = (1-s*(Delay_innerloop_Feedbackpath/2))/(1+s*(Delay_innerloop_Feedbackpath/2));

%% Delays Outer Loop
Delay_outerloop_Forwardpath =  OLComputationaldelay;
Delay_outerloop_Feedbackpath = ADClatency;
Delay_outerloop = Delay_outerloop_Forwardpath + Delay_outerloop_Feedbackpath;
GdelayOL =(1-s*(Delay_outerloop/2))/(1+s*(Delay_outerloop/2));
%% Feedback Networks
if (isequal(ILFBEntered,'off')||isequal(OLFBEntered,'off'))
    return    
else
    ADCVolt = str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String);
    Vadc = ADCVolt;
    CMSel = (handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio);
    %% CT values
    Rfb7=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String)*1e3;            % Burden resistor
    Rfb8 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String)*1e3;          % LPF Res
    Cfb5 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String)*1e-12;        % LPF cap
    Ns=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String);
    Ns(isnan(Ns))=100;
    Np=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String);
    Np(isnan(Np))=1; 
    
    %% Shunt Values
    Rfb9 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String)*1e3;
    Rfb10 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String)*1e3;
    Rfb11 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String)*1e3;
    Cfb6 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String)*1e-12;
    Rfb12 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String)*1e3;
    Cfb7 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String)*1e-12;

    %% Current measurement feedback calculations
    if (CMSel.CurrentTransformer.Value == 1)&& (isequal(isnan([Rfb7 Rfb8 Cfb5 Ns Np]),zeros(1,5))) 
    n=Ns/Np;                   
    Kcfilter = Rfb7 /n ;                       
    Ibase = Vadc / Kcfilter;
    Gcfilter=handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;
    CS_LPF=Gcfilter/Kcfilter;
    Gvfilter=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
    
    elseif(CMSel.ShuntResistor.Value == 1)
        Kcfilter = (Rfb9 * (1 + (Rfb11 / Rfb10)));
        Ibase = Vadc / Kcfilter; 
        Gcfilter=handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;
        CS_LPF=Gcfilter/Kcfilter;                     % LPF T/F
        Gvfilter=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;          
    end
       
    
 %% Input Voltage measurement 
    Rfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb1.String)*1e3;
    Rfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb2.String)*1e3;
    Rfb3 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Rfb3.String)*1e3;
    Cfb1 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb1.String)*1e-12;
    Cfb2 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.InputVoltageMeasurementNetwork.Cfb2.String)*1e-12;
    
%     Vin_sense = Rfb2/(Rfb1+Rfb2+s*Cfb1*Rfb2*Rfb1);       % Sensing network gain calculation
     Vinbase = Vadc/(Rfb2/(Rfb2+Rfb1));                   % Vbase input feedback network
%     IPFilter = 1 /(1+s*Rfb3*Cfb2);                       % Input Filter T/F
%     Gvifilter = Vin_sense * IPFilter;                    % Sensing network overall transfer function
 %% Output Voltage measurement 
    Rfb4 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb4.String)*1e3;
    Rfb5 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb5.String)*1e3;
    Rfb6 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Rfb6.String)*1e3;
    Cfb3 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb3.String)*1e-12;
    Cfb4 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.VoltageMeasurementNetwork.Cfb4.String)*1e-12;
    
%     Vout_sense = Rfb5/(Rfb4+Rfb5+s*Cfb3*Rfb4*Rfb5);    % Sensing network gain calculation CHECK
     Voutbase = Vadc /(Rfb5/(Rfb4+Rfb5));               % Vbase Output feedback network
     OPfilter = 1 /(1+s*Rfb6*Cfb4);                     % LPF T/F
%     Gvofilter = Vout_sense * OPfilter;                 % Sensing network overall transfer function

    Vbase  = Vadc / (Rfb5/(Rfb4+Rfb5));
%     Ybase = Ibase / Vbase;
    
end
%% Current Loop Controller Design and Loop-Gain 
fc_i = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency.String);     % Desired crossover frequency in Hz    
pm_i = str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin.String);            % Desired Phase Margin
fc_i(isnan(fc_i))=20000;
pm_i(isnan(pm_i))=60;
set(handles.ControllerDesignTab.PWMConfiguration.IL.CrossOverFrequency, 'String',string(fc_i));
set(handles.ControllerDesignTab.PWMConfiguration.IL.PhaseMargin, 'String',string(pm_i));
%% Inner Loop T/F
GidN = (Gid / Ibase);                        % Current loop plant normalized
Gi = GidN * GdelayIL * PWMshold * CS_LPF;      % Current loop pant normalized with delays; 

Ki = k_factor_function(Gi, fc_i, pm_i);      % Inner loop compensator in continious domain
handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog=Ki;
handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='on';

Li = Gi*Ki;                                                          %  Loop-Gain in continuious domain
handles.General_test.PlantInfo.IL.LoopGainAnalogTF=Li;
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='on';

zIL = (-1/(2*pi))*zero(Ki);
zIL  = round(real(zIL),0);
hic1 = zpk(Ki);                               % Inner loop compensator in pole Zero form only for display
hic1.DisplayFormat = 'frequency';             % Inner loop compensator in pole Zero form
KIL = evalfr(minreal(zpk((Ki*s))),0);          % to find the gain of the equation https://in.mathworks.com/help/control/ref/evalfr.html, 
                                              % (Ki*s), here 's' is multiplied to nullify the  pole at origin, and '0'
                                             % substituted where ever s is and finally gain is obtained
pIL = (-1/(2*pi))*pole(hic1);
pIL = round(real(pIL),0);
% test = minreal(zpk((Ki*s)));
% zIL = (-1/(2*pi))*zero(test);
% [zIL] = zero(hic1);
% k = dcgain(sys)
% [zIL,KIL]=zero(hic1);
% zIL = (-1/(2*pi))*zero(hic1*s);
% zIL = (-1/(2*pi))*zIL;
ILCompPolesNum = length(pIL);
ILZerosNum  =length(zIL);

handles.ControllerDesignTab.ControllerInfo.InnerLoop.ControllerType.Value = ILCompPolesNum-1;

set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Gain,'String',string(KIL));

switch(ILCompPolesNum)
    case 2
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1,'String',string(pIL(2)));
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.IL.ThreeP3Z.Visible='off';
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.IL.TwoP2Z.Visible='on';
    case 3
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole1,'String',string(pIL(2)));
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Pole2,'String',string(pIL(3)));
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.IL.TwoP2Z.Visible='off';
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.IL.ThreeP3Z.Visible='on';

end
switch(ILZerosNum)
    case 1
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1,'String',string(zIL(1)));

    case 2
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1,'String',string(zIL(1)));
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2,'String',string(zIL(2)));
    case 3
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero1,'String',string(zIL(1)));
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2,'String',string(zIL(2)));
        set(handles.ControllerDesignTab.ControllerInfo.InnerLoop.PZData.Zero2,'String',string(zIL(3)));
end

GCLI_A = minreal(feedback((Li/CS_LPF),(CS_LPF)));                        % closed loop T/F Inner current loop Analog
handles.General_test.PlantInfo.IL.ILCLTFAnalog=GCLI_A;

if isnan(Tsi)==0
    Ki_d = c2d(Ki, Tsi, 'tustin');
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Digital=Ki_d;
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='on';
    Li_d = c2d(Li,Tsi,'tustin');
    handles.General_test.PlantInfo.IL.LoopGainDigitalTF=Li_d;
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='on';
    Ki_d_cascaded = cascaded_control_function(Ki_d, 0, 0, 0, IL_Min_Clamp, IL_Max_Clamp); %  cascaded_control_function(controller, rev_order, gainEnable, hFileVloopCloop, minclamp, maxclamp)
    Ki_d_cascaded_sections = Ki_d_cascaded{1};
    Ki_d_cascaded_rshift = Ki_d_cascaded{2};
    % to have the inner loop compensator cascaded T/F is Z^-1 form.
    Ki_c_cascaded = cascaded_continuous_control_function(Ki_d_cascaded_sections, Ki_d_cascaded_rshift); 
    
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Digital = Ki_d_cascaded_sections;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.PostShift.Digital = Ki_d_cascaded_rshift;
    handles.ControllerDesignTab.ControllerInfo.InnerLoop.CascadedCompensatorTF.Analog = Ki_c_cascaded;

else
    opts='modal';
    warndlg("Enter PWM Configuration Parameters","Warning",opts);
    return
end

%% Closed Loop T/F Digital 
% GCLI_D_fwd = (Ki*(Gid / Ibase)*H_Delay_innerloop_Forwardpath*PWMshold);
% GCLI_D_fdbk = (CS_LPF*H_Delay_innerloop_Feedbackpath);
% GCLI_D = minreal(GCLI_D_fwd/(1+(GCLI_D_fwd*GCLI_D_fdbk)));    % Inner current loop closed loop transfer function Digital
% 
% handles.General_test.PlantInfo.IL.ILCLTFDigital=GCLI_D;

%% Voltage Loop Control (Control-to-Output Voltage Transfer Function)[ Vo / d]
% Rc=str2double(handles.General_test.CommonSpecs.Capacitor.ESR.String)*1e-3;
% C=str2double(handles.General_test.CommonSpecs.Capacitor.Capacitance.String)*1e-6;
% Vout=str2double(handles.General_test.CommonSpecs.Vout.String);
% Gc = (1/Vout);                                              % DC gain of Control-to-output transfer function
% Gvc = Gc*(1+Rc*C*s)/(s*C);                                  % Control-to-output transfer function with C and ESR, This is Gvc
% GcN = Gvc * Ibase * GCLI_A * Vinbase / Voutbase;            % Normalized plant
% Gvcp = GcN * GdelayOL * OPfilter ;                          % Gvcp plant transfer function with all delays
Gvc= handles.General_test.PlantInfo.OL.PlantTF;
handles.General_test.PlantInfo.Gvc.PlantTF = Gvc;
 GcN = Gvc * Ibase * GCLI_A * Vinbase / Voutbase;            
 Gvcp = GcN * GdelayOL * OPfilter ; 
%% Compensator design for Voltage Loop 
fc_v = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency.String);      % Cross over frequency in Hz
pm_v = str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin.String);              % Desired Phase Margin
fc_v(isnan(fc_v))=10;
pm_v(isnan(pm_v))=40;
set(handles.ControllerDesignTab.PWMConfiguration.OL.CrossOverFrequency, 'String',string(fc_v));
set(handles.ControllerDesignTab.PWMConfiguration.OL.PhaseMargin, 'String',string(pm_v));

Kv = k_factor_function(Gvcp, fc_v, pm_v);                         % Outer loop compensator in pole Zero form
handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog = Kv;
handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable = 'on';
Gvl_A = Gvcp*Kv;
handles.General_test.PlantInfo.OL.LoopGainAnalogTF = Gvl_A;
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable = 'on';

hic2 = zpk(Kv);                               % Outer loop compensator in pole Zero form only for display
hic2.DisplayFormat = 'frequency';             % Outer loop compensator in pole Zero form
KOL = evalfr(minreal(zpk((Kv*s))),0);          % to find the gain of the equation
pOL=round((-1/(2*pi))*pole(Kv),0);
[zOL]=zero(Kv);
zOL= round((-1/(2*pi))*zOL,0);
OLCompPolesNum=length(pOL);
OLZerosNum=length(zOL);

handles.ControllerDesignTab.ControllerInfo.OuterLoop.ControllerType.Value=OLCompPolesNum-1;

set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Gain,'String',string(KOL));

switch(OLCompPolesNum)
    case 2
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1,'String',string(pOL(2)));
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.OL.ThreeP3Z.Visible='off';
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.OL.TwoP2Z.Visible='on';
    case 3
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole1,'String',string(pOL(2)));
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Pole2,'String',string(pOL(3)));
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.OL.TwoP2Z.Visible='off';
        handles.ControllerDesignTab.Panes.VariablePanes.ControllerImagePanes.OL.ThreeP3Z.Visible='on';
end
switch(OLZerosNum)
    case 1
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1,'String',string(zOL(1)));

    case 2
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1,'String',string(zOL(1)));
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2,'String',string(zOL(2)));
    case 3
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero1,'String',string(zOL(1)));
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2,'String',string(zOL(2)));
        set(handles.ControllerDesignTab.ControllerInfo.OuterLoop.PZData.Zero2,'String',string(zOL(3)));
end

if isnan(Tsv)== 0
    Kv_d = c2d(Kv, Tsv, 'Tustin');
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Digital=Kv_d;
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotDigital.Enable='on';
    Gvl_D = c2d(Gvl_A,Tsv,'tustin'); 
    handles.General_test.PlantInfo.OL.LoopGainDigitalTF=Gvl_D;
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='on';
    Kv_d_cascaded = cascaded_control_function(Kv_d, 0, 0, 1, OL_Min_Clamp, OL_Max_Clamp); %  cascaded_control_function(controller, rev_order, gainEnable, hFileVloopCloop, minclamp, maxclamp)

    Kv_d_cascaded_sections = Kv_d_cascaded{1};
    Kv_d_cascaded_rshift = Kv_d_cascaded{2};

    Kv_c_cascaded = cascaded_continuous_control_function(Kv_d_cascaded_sections, Kv_d_cascaded_rshift);
   
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Digital = Kv_d_cascaded_sections;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.PostShift.Digital = Kv_d_cascaded_rshift;
    handles.ControllerDesignTab.ControllerInfo.OuterLoop.CascadedCompensatorTF.Analog = Kv_c_cascaded;
end

Gvloop = (Gvl_A / OPfilter)/(1+Gvl_A) ;                     % total system Closed Loop
handles.General_test.CLTF.Analog_with_Delay=Gvloop;
guidata(hObject,handles);

 DigitalCompensatorCoefficientsGeneration_PFC(hObject);
 DigitalCompensatorCoefficientsGeneration_PFC_Cascaded(hObject);
 AnalogCompensatorCoefficientsGeneration_PFC_Cascaded(hObject); 
PlotGeneration(hObject,0);