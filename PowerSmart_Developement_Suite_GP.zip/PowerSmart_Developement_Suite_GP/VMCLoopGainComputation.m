function VMCLoopGainComputation(hObject)
handles=guidata(hObject);
handles.Menu.OutputReport.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
OLPlantEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Enable;
OLCompensatorEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable;
OLFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable;
if (isequal(OLPlantEntered,'off') || isequal(OLCompensatorEntered,'off') || isequal(OLFBEntered,'off'))
    PlotGeneration(hObject);
    return;
end
OLFBTF=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
[N,~]=tfdata(OLFBTF,'v');
OLFBGain=N(length(N));
Vbase=3.3/OLFBGain;

Fs=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
Ts=1/Fs;
ADCLat=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.ADCLatency.String);
OLCompDelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String);
GateDriveDelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String);
PWMRes=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMResolution.String);
fwdDelay=(GateDriveDelay+OLCompDelay)*1e-9;
fbDelay=ADCLat*1e-9;
Td=fwdDelay+fbDelay;
%Td=(ADCLat+GateDriveDelay+OLCompDelay+ILCompDelay)*1e-9;

if (isnan(Ts) || (isreal(Td)==0)|| isnan(Td))
    PlotGeneration(hObject);
    return;
else % If Control method chosen is VMC
    %     System Delays
    % 2nd Order Pade's Approximation for delays
    s=tf('s');
    x=s*Td/2;
    H_outDelay=(1-x+(x^2)/2)/(1+x+(x^2)/2); % Second order approximation for delays for computing loop gain
    PWMshold=((1-(1-(s*Ts)/2)/(1+(s*Ts)/2))/(s*Ts));
    GDelay=H_outDelay*PWMshold;
    Hforwardpath_Delay =(1-s*(fwdDelay/2))/(1+s*(fwdDelay/2));
    Hfeedbackpath_Delay =(1-s*(fbDelay/2))/(1+s*(fbDelay/2));
        
    %Getting TFs
    OLPlantTF=handles.General_test.PlantInfo.OL.PlantTF;
    OLCompensatorTF=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog;
    OLLGAnalog=OLPlantTF*Vbase*OLCompensatorTF*OLFBTF;
    OLLGA2D=OLPlantTF*Vbase*OLCompensatorTF*OLFBTF*GDelay;
    OLLGDigital=c2d(OLLGA2D,Ts,'tustin');
    CLTFAnalog=feedback(OLPlantTF*Vbase*OLCompensatorTF,OLFBTF);
    CLTF_Delays=feedback((OLPlantTF*Vbase*OLCompensatorTF*Hforwardpath_Delay*PWMshold),(OLFBTF*Hfeedbackpath_Delay));
    handles.General_test.CLTF.Analog=CLTFAnalog;
    handles.General_test.CLTF.Analog_with_Delay=CLTF_Delays;
    handles.General_test.PlantInfo.OL.LoopGainAnalogTF=OLLGAnalog;
    handles.General_test.PlantInfo.OL.LoopGainDigitalTF=OLLGA2D;
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='on';
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='on';
end
handles.Menu.OutputReport.Enable='on';
guidata(hObject,handles)
PlotGeneration(hObject);