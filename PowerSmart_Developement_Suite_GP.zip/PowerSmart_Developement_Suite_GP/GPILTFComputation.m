function GPILTFComputation(hObject,~)
handles=guidata(hObject);
if (hObject.Style=="edit" && (isnan(str2double(hObject.String)) || isreal(str2double(hObject.String))==0) && isempty(hObject.String)==0)    
    hObject.BackgroundColor=[1 0.8 0.8];
   % return;
elseif  (hObject.Style=="edit" || isempty(hObject.String))
    hObject.BackgroundColor=[1 1 1];
end
s=tf('s');
GPILUDPFChoice=handles.General_test.SelectionDropdowns.ILPlantTopologySelection.Value;

if GPILUDPFChoice==2
    ILPZData=handles.General_test.PlantInfo.IL.UDPPZForm.PZData;
    p(1)=str2double(ILPZData.p1.String);
    p(2)=str2double(ILPZData.p2.String);
    p(3)=str2double(ILPZData.p3.String);
    p(4)=str2double(ILPZData.p4.String);
    p(5)=str2double(ILPZData.p5.String);
	 m=str2double(ILPZData.PolesAtOrigin.String);
     if p(1)==0 || p(2)==0 || p(3)==0 || p(4)==0 || p(5)==0 
             hObject.BackgroundColor=[1 0.8 0.8];
             return;
else
     hObject.BackgroundColor=[1 1 1];
end
    if isnan(m)
        m=0;
       handles.General_test.PlantInfo.IL.UDPPZForm.PZData.PolesAtOrigin.String ='0';
       handles.General_test.PlantInfo.IL.UDPPZForm.PZData.PolesAtOrigin.BackgroundColor=[1 1 1];
    end 
    z(1)=str2double(ILPZData.z1.String);
    z(2)=str2double(ILPZData.z2.String);
    z(3)=str2double(ILPZData.z3.String);
    z(4)=str2double(ILPZData.z4.String);
    z(5)=str2double(ILPZData.z5.String);
    Kdc=str2double(ILPZData.Kdc.String);
     if isnan(Kdc)
        Kdc=1;
      handles.General_test.PlantInfo.IL.UDPPZForm.PZData.Kdc.String ='1';
        handles.General_test.PlantInfo.IL.UDPPZForm.PZData.Kdc.BackgroundColor=[1 1 1];
     end 
     if z(1)==0 || z(2)==0 || z(3)==0 || z(4)==0 || z(5)==0 ||Kdc==0
             hObject.BackgroundColor=[1 0.8 0.8];
             return;
else
     hObject.BackgroundColor=[1 1 1];
end
    Gid=Kdc;
    PmultiFactor=zeros(1,5);
    ZmultiFactor=zeros(1,5);
    for i=1:5
 for i=1:5
        if (p(i)==0 ||z(i)==0)
             hObject.BackgroundColor=[1 0.8 0.8];
              else 
            hObject.BackgroundColor=[1 1 1];
        end
        PmultiFactor(i)=double(~isnan(p(i)));
        ZmultiFactor(i)=double(~isnan(z(i)));

       Gid=Gid*(1+s*ZmultiFactor(i)/(2*pi*z(i)))/(1+s*PmultiFactor(i)/(2*pi*p(i)));
       handles.General_test.PlantInfo.IL.PlantTF=Gid;
   hip = zpk(Gid);
 hip.DisplayFormat = 'frequency';
 end
 % display(hip);
    end
else
    ILPolyData=handles.General_test.PlantInfo.IL.UDPPolynomialForm.Coefficients;
    a(1)=str2double(ILPolyData.a0.String);
    a(2)=str2double(ILPolyData.a1.String);
    a(3)=str2double(ILPolyData.a2.String);
    a(4)=str2double(ILPolyData.a3.String);
    a(5)=str2double(ILPolyData.a4.String);
    a(6)=str2double(ILPolyData.a5.String);
    b(1)=str2double(ILPolyData.b0.String);
    if isnan(b(1))==1
        b(1)=1;
    end
    b(2)=str2double(ILPolyData.b1.String);
    b(3)=str2double(ILPolyData.b2.String);
    b(4)=str2double(ILPolyData.b3.String);
    b(5)=str2double(ILPolyData.b4.String);
    b(6)=str2double(ILPolyData.b5.String);
    ACoeff=zeros(1,6);
    BCoeff=zeros(1,6);
    for i=1:6
        if (isnan(a(i))==1)
            ACoeff(i)=0; 
        else 
            ACoeff(i)=a(i); 
        end
        
        if (isnan(b(i))==1)
            BCoeff(i)=0; 
        else 
            BCoeff(i)=b(i); 
        end
    end
    
    Gid=tf([ACoeff(6) ACoeff(5) ACoeff(4) ACoeff(3) ACoeff(2) ACoeff(1)],[BCoeff(6) BCoeff(5) BCoeff(4) BCoeff(3) BCoeff(2) BCoeff(1)]);
handles.General_test.PlantInfo.IL.PlantTF=Gid;
%display(GInnerLoopPlant);
end

handles.PlotsTab.Configuration.PlotDisplaySelections.ILPlantPlot.Enable='on'; % Enabling Inner Loop Bode plot display checkbox

%CMCLoopGainComputation(hObject);

