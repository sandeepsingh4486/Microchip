function CMCLoopGainComputation(hObject,~)
handles=guidata(hObject);
handles.Menu.OutputReport.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='off';
handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='off';

ILFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Enable;
ILPlantEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILPlantPlot.Enable;
ILCompensatorEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable;
ControlMethod=handles.General_test.SelectionDropdowns.ControlMethodSelection.Value;
             
if (isequal(ILFBEntered,'off') || isequal(ILPlantEntered,'off') || (ControlMethod==2 && isequal(ILCompensatorEntered,'off')) )
    PlotGeneration(hObject);
    return;
end
ILFBGain=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.FixedGainNetwork.Gain.String);
ILFBGain(isnan(ILFBGain))=1;
Ibase = 3.3 / ILFBGain;

OLPlantEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Enable;
OLCompensatorEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLCompensatorPlotAnalog.Enable;
OLFBEntered=handles.PlotsTab.Configuration.PlotDisplaySelections.OLFBPlot.Enable;
s=tf('s');


GateDriverDelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.GateDriveDelay.String);
GateDriverDelay(isnan(GateDriverDelay))=0;
Fsw=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMFrequency.String);
Tsw=1/Fsw;
FsOL=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.PWMSamplingFreq.String);
TsOL=1/FsOL;
FsIL=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.PWMSamplingFreq.String);
FsIL(isnan(FsIL))= Fsw;
TsIL=1/FsIL;
OLADClatency=str2double(handles.FeedbackNetworkTab.FeedbackParameters.OL.ADCLatency.String);
OLADClatency(isnan(OLADClatency))=0;
OLComputationaldelay=str2double(handles.ControllerDesignTab.PWMConfiguration.OL.ComputationalDelay.String);
OLComputationaldelay(isnan(OLComputationaldelay))=0;
ILComputationaldelay=str2double(handles.ControllerDesignTab.PWMConfiguration.IL.ComputationalDelay.String);
ILComputationaldelay(isnan(ILComputationaldelay)|| isequal(ControlMethod,3))=0;
ComparatorDelay=str2double(handles.ControllerDesignTab.ControllerInfo.PCMCInnerLoop.ComparatorSettings.LatencyDelay);
ComparatorDelay(isnan(ComparatorDelay) || isequal(ControlMethod,2))=0;
DACSettlingTime=str2double(handles.ControllerDesignTab.ControllerInfo.PCMCInnerLoop.DACSettings.SettlingTime.String);
DACSettlingTime(isnan(DACSettlingTime) || isequal(ControlMethod,2))=0; % 0 for ACMC
Delay_InnerLoop = (GateDriverDelay + ILComputationaldelay + ComparatorDelay + DACSettlingTime)*1e-9;     % Gate Driver Delay + ComparatorDelay
Delay_Total_OuterLoop = Delay_InnerLoop + (OLADClatency + OLComputationaldelay)*1e-9;
Delay_OuterLoop_ForwardPath=Delay_Total_OuterLoop-OLADClatency*1e-9;
Delay_InnerLoop_FeedbackPath=OLADClatency*1e-9;

% Second order approximation of Delay
v=s*Delay_InnerLoop/2;
H_InnerLoopDelay=(1-v+(v^2)/2)/(1+v+(v^2)/2);
w=s*Delay_InnerLoop_FeedbackPath/2;
H_InnerLoopDelay_Feedback=(1-w+(w^2)/2)/(1+w+(w^2)/2);


if (isnan(TsOL) || isnan(TsIL) || (isreal(Delay_Total_OuterLoop)==0)|| isnan(Delay_Total_OuterLoop))
    PlotGeneration(hObject);
    return;
    
elseif (ControlMethod==2 && isequal(ILCompensatorEntered,'on'))
    
    ILFBTF=handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF;
    PWMshold = ((1-(1-(s*TsIL)/2)/(1+(s*TsIL)/2))/(s*TsIL));
    ILCompensatorTF=handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorTF.Analog;
    ILPlantTF=handles.General_test.PlantInfo.IL.PlantTF;
    ILLGAnalog=(ILPlantTF / Ibase)*ILCompensatorTF*ILFBTF ;  
    ILLGDigital=(ILPlantTF / Ibase)*ILCompensatorTF*H_InnerLoopDelay*PWMshold*ILFBTF*H_InnerLoopDelay_Feedback;  
    ILCLTFAnalog=feedback((ILCompensatorTF*(ILPlantTF / Ibase)),ILFBTF); 
    ILCLTFDigital=feedback((ILCompensatorTF*(ILPlantTF / Ibase)*H_InnerLoopDelay*PWMshold),(ILFBTF*H_InnerLoopDelay_Feedback));
    
    Delay_Total_OuterLoop=Delay_Total_OuterLoop-Delay_InnerLoop;
    Delay_OuterLoop_ForwardPath=Delay_Total_OuterLoop-OLADClatency*1e-9;

    handles.General_test.PlantInfo.IL.LoopGainAnalogTF=ILLGAnalog;
    handles.General_test.PlantInfo.IL.LoopGainDigitalTF=ILLGDigital;
    handles.General_test.PlantInfo.IL.ILCLTFAnalog=ILCLTFAnalog;
    handles.General_test.PlantInfo.IL.ILCLTFDigital=ILCLTFDigital;
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='on';
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotDigital.Enable='on';

    guidata(hObject,handles); % Even if the Outer Loop parameters are not enetered, after this line inner loop parameters can be plotted
    
elseif (ControlMethod==3)
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotAnalog.Enable='off';
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILCompensatorPlotDigital.Enable='off';
    Kr=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.FixedGainNetwork.Kr.String);
    Kr(isnan(Kr))=1;
    Fm=str2double(handles.ControllerDesignTab.ControllerInfo.PCMCInnerLoop.ComparatorSettings.ModulatorGain.String);
    Fm(isnan(Fm))=1;    
    
      
    % He, Sampling Gain
    wn = pi/Tsw ;
    Q = -2/pi ;
    He = (1+(s/(Q*wn))+(s^2/wn^2));  % Calculate Sampling Gain
    %     System Delays
    % ***********************Delays Inner loop********************************
    % Delay_innerloop=exp(Delay_innerloop);
    % 2nd Order Pade's Approximation for delays



    %***************Inner Loop Delays are considered all in outer loop*****

    % ***********************Delays Outer Loop*********************************
    % Delay_outloop=exp(-s*Delay_outloop);
    % H_outDelay=ss(Delay_outloop);
    % PWMshold=ss((1-exp(-s*Ts))/(s*Ts));
    % 1st Order Pade's Approximation for delays
    % ADClatency = 310e-9;                    % ADC conversion latency 21.5*14.28n = 3.0702e-7 ~ = 310nSec
    % Computationaldelay = 600e-9;            % 3p3Z approx delay, same is used for all.


    %Getting TFs for Gid and Gfb
    ILPlantTF=handles.General_test.PlantInfo.IL.PlantTF;
    ILLGAnalog = Fm * ILPlantTF * He * ILFBGain ;               % inner loop gain
    ILLGDigital= Fm * ILPlantTF * He * ILFBGain * H_InnerLoopDelay ; 

    ILCLTFAnalog=feedback(Fm ,(He*ILFBGain*ILPlantTF));

    %*********Doubt******************************************************
    %ILCLTFDigital=feedback((Fm*H_InnerLoopDelay),(He*ILFBTF*ILPlantTF));
    %********************************************************************
    handles.General_test.PlantInfo.IL.LoopGainAnalogTF=ILLGAnalog;
    handles.General_test.PlantInfo.IL.LoopGainDigitalTF=ILLGDigital;
    handles.General_test.PlantInfo.IL.ILCLTFAnalog=ILCLTFAnalog;
    handles.PlotsTab.Configuration.PlotDisplaySelections.ILLoopGainPlotAnalog.Enable='on';
    guidata(hObject,handles); % Even if the Outer Loop parameters are not enetered, after this line inner loop parameters can be plotted

else
    PlotGeneration(hObject);
    return;
    
end


if (isequal(OLPlantEntered,'off') || isequal(OLCompensatorEntered,'off') || isequal(OLFBEntered,'off'))
    PlotGeneration(hObject);
    return;
else
    %Outer Loop Delay calculation
    x=s*Delay_OuterLoop_ForwardPath/2;
    y=s*Delay_Total_OuterLoop/2;
    H_fwdPath=(1-x+(x^2)/2)/(1+x+(x^2)/2);
    H_outDelay=(1-y+(y^2)/2)/(1+y+(y^2)/2); % Second order approximation for delays for computing loop gain
    PWMshold =((1-(1-(s*TsOL)/2)/(1+(s*TsOL)/2))/(s*TsOL));
    OLPlantTF=handles.General_test.PlantInfo.OL.PlantTF;
    OLCompensatorTF=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog;
    OLFBTF=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
    [N,~]=tfdata(OLFBTF,'v');
    OLFBGain=N(length(N));
    Vbase=3.3/OLFBGain;
   
    % Control-to-Output Transfer Function Computation
    %***********************************************************************
    % Switch Case statement to be used here during ACMC implementation
    % because control to output T will be different for both of PCMC and ACMC
    if (ControlMethod==2)
        Ybase=Ibase/Vbase;
        Gvc=ILCLTFAnalog*((OLPlantTF/ILPlantTF)*Ybase);
        Gvcd=ILCLTFDigital*((OLPlantTF/ILPlantTF)*Ybase); % Gvc with delays
    else
        
        Gvc=ILFBGain*feedback((ILCLTFAnalog*OLPlantTF/Vbase),-Kr);
        Gvcd=ILFBGain*feedback((ILCLTFAnalog*OLPlantTF/Vbase),-Kr); % All delays for PCMC have been considered in outer loop only, so Analog and digital Gvc is same here
    end
        %***********************************************************************
    OLLGAnalog=OLCompensatorTF*Gvc*OLFBTF;
    OLLGDigital=OLCompensatorTF*Gvcd*OLFBTF*H_outDelay*PWMshold;
    CLTFDigital=Gvcd*OLCompensatorTF*H_fwdPath*PWMshold/(1+OLLGDigital);
    CLTFAnalog=Gvc*OLCompensatorTF/(1+OLLGAnalog);
    handles.General_test.CLTF.Analog=CLTFAnalog;
    handles.General_test.CLTF.Analog_with_Delay=CLTFDigital;
    handles.General_test.PlantInfo.OL.LoopGainAnalogTF=OLLGAnalog;
    handles.General_test.PlantInfo.OL.LoopGainDigitalTF=OLLGDigital;
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='on';
    handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='on';   
    guidata(hObject,handles);
end
handles.Menu.OutputReport.Enable='on';
PlotGeneration(hObject);


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
%     
%     fwdDelay=(GateDriveDelay+ILCompDelay+OLCompDelay)*1e-9;
%     fbDelay=ADCLat*1e-9;
%     Td=fwdDelay+fbDelay;
%     
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % elseif (handles.General_test.SelectionDropdowns.ControlMethodSelection.Value==2) % Control Mode is Dual Loop Control
% %     handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='off';
% %     handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='off';
% %     if (isequal(ILPlantEntered,'off') || isequal(ILCompensatorEntered,'off') || isnan(Ts) || isnan (Td)) % To check for whether Inner loop parameters have been entered
% %         return;    
% %     else
% %         %     System Delays
% %         % 1st Order Pade's Approximation for delays
% %         H_outDelay=(1-s*(Td/2))/(1+s*(Td/2));
% %         PWMshold=((1-(1-(s*Ts)/2)/(1+(s*Ts)/2))/(s*Ts));
% %         GDelay=H_outDelay*PWMshold;
% %         
% %         %Getting TFs
% %         OLPlantTF=handles.General_test.PlantInfo.OL.PlantTF;
% %         OLCompensatorTF=handles.ControllerDesignTab.ControllerInfo.OuterLoop.CompensatorTF.Analog;
% %         OLFBTF=handles.FeedbackNetworkTab.FeedbackParameters.OL.FilterTF;
% %         ILPlantTF=handles.General_test.PlantInfo.IL.PlantTF;
% %         OLLGA2D=OLPlantTF*OLCompensatorTF*OLFBTF*GDelay*ILPlantTF;
%         OLLGDigital=c2d(OLLGA2D,Ts,'tustin');
%         handles.General_test.PlantInfo.OL.LoopGainAnalogTF=OLLGA2D;
%         handles.General_test.PlantInfo.OL.LoopGainDigitalTF=OLLGDigital;   
%         handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotAnalog.Enable='on';
%         handles.PlotsTab.Configuration.PlotDisplaySelections.OLLoopGainPlotDigital.Enable='on';
%     end
%     
% else
% handles.ControllerDesignTab.PWMConfiguration.IL.GateDriveDelay.String=string(GateDriveDelay);
% handles.ControllerDesignTab.PWMConfiguration.IL.PWMResolution.String=string(PWMRes);
% end