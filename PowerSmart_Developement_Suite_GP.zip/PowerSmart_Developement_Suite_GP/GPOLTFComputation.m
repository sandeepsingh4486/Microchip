function GPOLTFComputation(hObject,~)
handles=guidata(hObject);
if (hObject.Style=="edit" && (isnan(str2double(hObject.String)) || isreal(str2double(hObject.String))==0) && isempty(hObject.String)==0) 
    hObject.BackgroundColor=[1 0.8 0.8];
   % return;
elseif  (hObject.Style=="edit" || isempty(hObject.String))
    hObject.BackgroundColor=[1 1 1];
end
s=tf('s');
handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Enable='off';
%User Defined Plant Form Choice
OLUDPFChoice=handles.General_test.SelectionDropdowns.TopologySelection.Value;
%OLUDPFChoice=handles.General_test.SelectionDropdowns.TopologySelection.Value;
if OLUDPFChoice==2  % if Plant form choice is Pole Zero Form
    OLPZData=handles.General_test.PlantInfo.OL.UDPPZForm.PZData;
    p(1)=str2double(OLPZData.p1.String);
    p(2)=str2double(OLPZData.p2.String);
    p(3)=str2double(OLPZData.p3.String);
    p(4)=str2double(OLPZData.p4.String);
    p(5)=str2double(OLPZData.p5.String);
    m=str2double(OLPZData.PolesAtOrigin.String);
    if p(1)==0 || p(2)==0 || p(3)==0 || p(4)==0 || p(5)==0 
             hObject.BackgroundColor=[1 0.8 0.8];
             return;
else
     hObject.BackgroundColor=[1 1 1];
end
     if isnan(m)
        m=0;
      handles.General_test.PlantInfo.OL.UDPPZForm.PZData.PolesAtOrigin.String ='0';
      handles.General_test.PlantInfo.OL.UDPPZForm.PZData.PolesAtOrigin.BackgroundColor=[1 1 1];
    end 
    z(1)=str2double(OLPZData.z1.String);
    z(2)=str2double(OLPZData.z2.String);
    z(3)=str2double(OLPZData.z3.String);
    z(4)=str2double(OLPZData.z4.String);
    z(5)=str2double(OLPZData.z5.String);
     Kdc=str2double(OLPZData.Kdc.String);
    %Kdc(isnan(Kdc))=1;
    if isnan(Kdc)
        Kdc=1;
      handles.General_test.PlantInfo.OL.UDPPZForm.PZData.Kdc.String ='1';
      handles.General_test.PlantInfo.OL.UDPPZForm.PZData.Kdc.BackgroundColor=[1 1 1];
    end 
    if z(1)==0 || z(2)==0 || z(3)==0 || z(4)==0 || z(5)==0 ||Kdc==0
             hObject.BackgroundColor=[1 0.8 0.8];
             return;
else
     hObject.BackgroundColor=[1 1 1];
end
    Gvd=Kdc/((s/(2*pi))^m);
    PmultiFactor=zeros(1,5);
    ZmultiFactor=zeros(1,5);
    for i=1:5
        PmultiFactor(i)=double(~isnan(p(i)));
   ZmultiFactor(i)=double(~isnan(z(i)));
        Gvd=Gvd*(1+s*ZmultiFactor(i)/(2*pi*z(i)))/(1+s*PmultiFactor(i)/(2*pi*p(i)));
                hip = zpk(Gvd);
 hip.DisplayFormat = 'frequency';
  %PlotGeneration(hObject);
  end
 %display(hip);
      
  else %Plant form choice is Polynomial Form
    OLPolyData=handles.General_test.PlantInfo.OL.UDPPolynomialForm.Coefficients;
    a(1)=str2double(OLPolyData.a0.String);
    a(2)=str2double(OLPolyData.a1.String);
    a(3)=str2double(OLPolyData.a2.String);
    a(4)=str2double(OLPolyData.a3.String);
    a(5)=str2double(OLPolyData.a4.String);
    a(6)=str2double(OLPolyData.a5.String);
    b(1)=str2double(OLPolyData.b0.String);
  
    if isnan(b(1))==1
        b(1)=1;
    end
    b(2)=str2double(OLPolyData.b1.String);
    b(3)=str2double(OLPolyData.b2.String);
    b(4)=str2double(OLPolyData.b3.String);
    b(5)=str2double(OLPolyData.b4.String);
    b(6)=str2double(OLPolyData.b5.String);
    
    ACoeff=zeros(1,6);
    BCoeff=zeros(1,6);
    
        for i=1:6
        if (isnan(a(i)==1))
            ACoeff(i)=0; 
        else 
            ACoeff(i)=a(i); 
        end
        if (isnan(b(i))==1)
            BCoeff(i)=0; 
        else 
            BCoeff(i)=b(i); 
        end
        end
        
         Gvd=tf([ACoeff(6) ACoeff(5) ACoeff(4) ACoeff(3) ACoeff(2) ACoeff(1)],[BCoeff(6) BCoeff(5) BCoeff(4) BCoeff(3) BCoeff(2) BCoeff(1)]);
        handles.General_test.PlantInfo.OL.PlantTF=Gvd;
end
handles.PlotsTab.Configuration.PlotDisplaySelections.OLPlantPlot.Enable='on'; % Enabling Outer Loop Bode plot display checkbox
guidata(hObject,handles);
if (handles.General_test.SelectionDropdowns.ControlMethodSelection.Value==1)
    VMCLoopGainComputation(hObject);
else
    CMCLoopGainComputation(hObject);
end
