function ILFBTFComputation(hObject,~)
if (hObject.Style=="edit" && isnan(str2double(hObject.String)) && (isempty(hObject.String)==0) || isreal(str2double(hObject.String))==0 || (str2double(hObject.String)<0)) 
    hObject.BackgroundColor=[1 0.8 0.8];
    return;
elseif  (hObject.Style=="edit" || isempty(hObject.String))
    hObject.BackgroundColor=[1 1 1];
end
handles=guidata(hObject);
%% CT values
Rfb7=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb7.String)*1e3;       % Burden resistor
Rfb8=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Rfb8.String)*1e3;       % LPF resistor
Cfb5=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Cfb5.String)*1e-12;     % LPF cap
Ns=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.SecondaryTurnsRatioNs.String);
Ns(isnan(Ns))=100;
Np=str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.PrimaryTurnsRatioNp.String);
Np(isnan(Np))=1;

%% Shunt Values
Rfb9 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb9.String)*1e3;
Rfb10 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb10.String)*1e3;
Rfb11 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb11.String)*1e3;
Cfb6 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb6.String)*1e-12;
Rfb12 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Rfb12.String)*1e3;
Cfb7 = str2double(handles.FeedbackNetworkTab.FeedbackParameters.IL.ShuntCurrentMeasurementNetwork.Cfb7.String)*1e-12;

%%
ADCVolt = str2double(handles.FeedbackNetworkTab.FeedbackParameters.ADCParameters.ADCVoltage.String);
Vadc = ADCVolt;

% DAC_Calculation_PFC(hObject);

CMSel = (handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Radio);

s=tf('s');

%% Current measurement feedback calculations
if (CMSel.CurrentTransformer.Value == 1)&& (isequal(isnan([Rfb7 Rfb8 Cfb5 Ns Np]),zeros(1,5)))
        n=Ns/Np;                   
        Kcfilter = Rfb7 /n ;                       
        CS_LPF = 1/((Rfb7+Rfb8)*Cfb5*s+1);
        GInnerLoopFilter =  Kcfilter*CS_LPF;                  % Current sense filter T/F
        Ibase = Vadc / Kcfilter;
%         handles.FeedbackNetworkTab.FeedbackParameters.IL.CurrentMeasurementNetwork.Ibase = Ibase;
        handles.FeedbackNetworkTab.Ibase = Ibase;
        handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Enable='on'; 
        
elseif (CMSel.ShuntResistor.Value == 1) && (isequal(isnan([Rfb9 Rfb10 Rfb11 Cfb6 Rfb12 Cfb7]),zeros(1,6)))
        Kcfilter = (Rfb9 * (1 + (Rfb11 / Rfb10)));
        CS_LPF = 1 /(1+s*Rfb12*Cfb7);                     % LPF T/F
        GInnerLoopFilter =  Kcfilter*CS_LPF; 
        Ibase = Vadc / Kcfilter;    
        
       handles.PlotsTab.Configuration.PlotDisplaySelections.ILFBPlot.Enable='on'; 
else
        PlotGeneration(hObject,0);
        return
end
try
   handles.FeedbackNetworkTab.FeedbackParameters.IL.FilterTF = GInnerLoopFilter;
     
   guidata(hObject,handles);
end

% XCapCompenCalc(hObject);
% if all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.IVMPanel,'Style','edit'),'String'))))&&all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.OL.OVMPanel,'Style','edit'),'String'))))&& all(~isnan(str2double(get(findobj(handles.SpecificationsTab.PowerStageParametersPanel,'Style','edit'),'String'))))&&all( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.OL.PWMConfigPanel,'Style','edit'),'String'))))&&all( ~isnan(str2double(get(findobj(handles.ControllerDesignTab.Panes.IL.PWMConfigPanel,'Style','edit'),'String'))))&&(all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMSRPanel,'Style','edit'),'String'))))|| all(~isnan(str2double(get(findobj(handles.FeedbackNetworkTab.FeedbackParameters.IL.CMPanel,'Style','edit'),'String')))))
%     
%     if handles.ControllerDesignTab.ControllerInfo.InnerLoop.CompensatorPZPlacementMethod.Auto.Value==1
%         BLPFCAutoCompensatorDesign(hObject);
%     else
%         ILManualCompDesign_PFC(hObject,0);
%         OLManualCompDesign_PFC(hObject,0);
%     end
%     
%     PlotGeneration(hObject,0);
%     
% end
